"""Streamlit entry point for the TravelGenie home and itinerary pages."""
from __future__ import annotations

import os
from pathlib import Path
import sys
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from auth_ui import render_auth_gate

st.set_page_config(page_title="TravelGenie AI", page_icon="✈️", layout="wide")

user = render_auth_gate()
if not user:
    st.stop()

st.session_state.setdefault("api_url", os.getenv("VOYAGE_API_URL", "http://127.0.0.1:8000"))
st.session_state.setdefault("result", None)
st.session_state.setdefault("assistant_open", False)
st.session_state.setdefault("destination_input", "")
st.session_state.setdefault("trip_query", "")
st.session_state.setdefault("trip_budget", 30000)
st.session_state.setdefault("trip_interests", "")
st.session_state.setdefault("route_mode", False)
st.session_state.setdefault("quick_plan_destination", None)

with st.sidebar:
    st.markdown(f"**{user['name']}**")
    st.caption(user["email"])
    if st.button("Log out", icon=":material/logout:", width="stretch"):
        st.session_state.pop("auth_user_id", None)
        st.session_state.pop("active_conversation_id", None)
        st.rerun()

pages = [
    st.Page("app_pages/home.py", title="Explore", icon=":material/home:", default=True),
    st.Page("app_pages/chat.py", title="Travel chat", icon=":material/chat:"),
    st.Page("app_pages/itinerary.py", title="Your itinerary", icon=":material/luggage:")
]
if user["role"] == "admin":
    pages.append(st.Page("app_pages/admin.py", title="Admin portal", icon=":material/admin_panel_settings:"))
page = st.navigation(pages, position="sidebar")
page.run()
