"""Streamlit CCv2 browser speech recognition control."""
import streamlit.components.v2 as components_v2

VOICE = components_v2.component(
    "voyage_voice_input",
    html="<div class='voice-control'><button id='listen' type='button'>Start voice input</button><button id='speak' type='button'>Read plan aloud</button><span id='voice-status'>Browser speech features</span></div>",
    css=".voice-control{display:flex;align-items:center;gap:12px;font:13px system-ui;color:#5b6d82}.voice-control button{border:1px solid #c6dcf5;border-radius:9px;background:#fff;color:#075ecb;padding:9px 12px;cursor:pointer;font-weight:600}.voice-control button:hover{background:#edf5ff}.voice-control span{font-size:12px}",
    js="""
export default function(component) {
  const {parentElement, setStateValue, data} = component
  const button = parentElement.querySelector('#listen')
  const speakButton = parentElement.querySelector('#speak')
  const status = parentElement.querySelector('#voice-status')
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
  if (!button || !speakButton || !status) return
  const recognition = SpeechRecognition ? new SpeechRecognition() : null
  if (!recognition) { button.disabled = true; status.textContent = 'Speech recognition is not available in this browser' }
  if (recognition) { recognition.lang = navigator.language || 'en-US'; recognition.interimResults = false; recognition.maxAlternatives = 1 }
  const click = () => { if (!recognition) return; status.textContent = 'Listening…'; button.disabled = true; recognition.start() }
  const speak = () => { const text = data?.speak_text || ''; if (!text) { status.textContent = 'A plan is not ready to read aloud'; return }; window.speechSynthesis.cancel(); window.speechSynthesis.speak(new SpeechSynthesisUtterance(text)); status.textContent = 'Reading the plan aloud' }
  if (recognition) { recognition.onresult = event => { const transcript = event.results[0][0].transcript; setStateValue('transcript', transcript); status.textContent = 'Transcript added to your trip request' }; recognition.onerror = () => { status.textContent = 'Voice input stopped. You can type your request instead' }; recognition.onend = () => { button.disabled = false }; button.addEventListener('click', click) }
  speakButton.addEventListener('click', speak)
  return () => { if (recognition) { button.removeEventListener('click', click); recognition.abort() }; speakButton.removeEventListener('click', speak) }
}
""",
)

def voice_input(key:str="voice_input", speak_text:str=""):
    return VOICE(key=key, data={"speak_text":speak_text}, on_transcript_change=lambda:None)
