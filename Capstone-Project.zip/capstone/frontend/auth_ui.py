"""Sign-up/sign-in UI backed by verified local accounts and SMTP email."""
from __future__ import annotations

import base64
from html import escape
from pathlib import Path

import streamlit as st

from src.auth_store import AuthError, get_pending_user, get_user, init_db, login_user, register_user, resend_verification, verify_email
from src.email_service import EmailConfigurationError, send_confirmation, send_welcome


@st.cache_data(show_spinner=False)
def _auth_background_data_uri() -> str:
    image_path = Path(__file__).resolve().parent / "assets" / "travel_auth_bg.jpg"
    encoded = base64.b64encode(image_path.read_bytes()).decode("ascii")
    return f"data:image/jpeg;base64,{encoded}"


def _render_auth_theme() -> None:
    background = _auth_background_data_uri()
    st.markdown(f"""
    <style>
    [data-testid="stAppViewContainer"] {{
      background-image: linear-gradient(90deg, rgba(2,18,39,.58), rgba(3,20,43,.20) 52%, rgba(1,15,30,.38)), url('{background}');
      background-size: cover; background-position: center; background-attachment: fixed;
    }}
    [data-testid="stHeader"] {{ display: none; }}
    [data-testid="stMain"] {{ background: transparent; }}
    [data-testid="stVerticalBlockBorderWrapper"] {{
      background: rgba(5, 24, 46, .73); border: 1px solid rgba(220,238,255,.28);
      border-radius: 26px; box-shadow: 0 24px 70px rgba(0,0,0,.30);
      backdrop-filter: blur(18px); -webkit-backdrop-filter: blur(18px);
    }}
    .stApp, .stApp p, .stApp label, .stApp [data-testid="stWidgetLabel"] {{ color: #f4f8ff; }}
    .stApp h1, .stApp h2, .stApp h3 {{ color: #fff; }}
    .stApp [data-testid="stCaptionContainer"] {{ color: #c0d2e7; }}
    .stApp .tg-mail-note {{ color: #52677e; }}
    .stApp .tg-mail-card h1 {{ color: #102c48; }}
    .stApp [data-baseweb="tab-list"] {{ gap: .35rem; }}
    .stApp [data-baseweb="tab"] {{ color: #d5e4f7; }}
    .stApp [data-baseweb="tab-highlight"] {{ background-color: #27a4ff; }}
    .stApp input {{ background: rgba(255,255,255,.10); color: #fff; border-color: rgba(225,239,255,.30); }}
    .stApp input::placeholder {{ color: #bac9dc; }}
    .stApp button[aria-label="Show password"], .stApp button[aria-label="Hide password"],
    .stApp [role="checkbox"][aria-label="Show password"], .stApp [role="checkbox"][aria-label="Hide password"],
    .stApp [aria-label*="password" i], .stApp [title*="password" i], .stApp [data-testid*="password" i],
    .stApp [data-testid="stTextInput"] button, .stApp [data-testid="stTextInput"] [role="checkbox"] {{
      color: #075bb8 !important; opacity: 1 !important; background: #d9efff !important;
      border: 1px solid #2991ed !important; border-radius: 999px !important;
      box-shadow: 0 0 0 3px rgba(41,145,237,.16);
    }}
    .stApp button[aria-label="Show password"] svg, .stApp button[aria-label="Hide password"] svg,
    .stApp [role="checkbox"][aria-label="Show password"] svg, .stApp [role="checkbox"][aria-label="Hide password"] svg,
    .stApp [data-testid="stTextInput"] button svg, .stApp [data-testid="stTextInput"] [role="checkbox"] svg {{
      color: #075bb8 !important; fill: currentColor !important; opacity: 1 !important;
    }}
    .stApp svg {{
      color: #075bb8 !important; filter: brightness(.48) saturate(2.6) contrast(1.45) !important;
      opacity: 1 !important;
    }}
    .stApp button[aria-label="Show password"]:focus-visible, .stApp button[aria-label="Hide password"]:focus-visible,
    .stApp [aria-label*="password" i]:focus-visible, .stApp [title*="password" i]:focus-visible,
    .stApp [role="checkbox"][aria-label="Show password"]:focus-visible, .stApp [role="checkbox"][aria-label="Hide password"]:focus-visible {{
      outline: 3px solid #5bc3ff !important; outline-offset: 2px;
    }}
    .stApp button[kind="primary"] {{ background: linear-gradient(105deg,#27a9ff,#0865f5); border: 0; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,110,255,.35); }}
    .tg-brand {{ font-size: 1.25rem; font-weight: 800; letter-spacing: .01em; color:#fff; margin: .5rem 0 4.8rem; }}
    .tg-eyebrow {{ color:#8fd1ff; letter-spacing:.20em; font-size:.78rem; font-weight:800; text-transform:uppercase; }}
    .tg-headline {{ color:#fff; font-family:Georgia,serif; font-size:clamp(3.2rem,6vw,5.4rem); line-height:.98; font-weight:700; margin:.7rem 0 1.1rem; }}
    .tg-headline span {{ color:#39a5ff; }}
    .tg-copy {{ color:#edf5ff; font-size:1.1rem; line-height:1.65; max-width:34rem; }}
    .tg-features {{ margin-top:2rem; color:#f7fbff; font-weight:700; line-height:1.4; }}
    .tg-features small {{ color:#c5d7ed; font-weight:400; }}
    .tg-login-title {{ text-align:center; font-family:Georgia,serif; font-size:2.2rem; color:#fff; margin:.25rem 0 .3rem; }}
    .tg-login-subtitle {{ text-align:center; color:#c3d2e4; margin-bottom:1.4rem; }}
    @media (max-width: 900px) {{ .tg-brand {{ margin-bottom:1.2rem; }} .tg-headline {{ font-size:3.1rem; }} }}
    </style>
    """, unsafe_allow_html=True)


def _deliver_confirmation(email: str, name: str, token: str) -> None:
    send_confirmation(email, name, token)


def _render_email_check(email: str) -> None:
    """Show a focused, colorful confirmation screen after sending the email."""
    safe_email = escape(email)
    st.markdown("""
    <style>
    .tg-mail-card {
      padding: 2.2rem 2.4rem; border-radius: 28px; color: #102c48;
      background: linear-gradient(125deg, #dff7ff 0%, #e8e6ff 48%, #fff0dc 100%);
      border: 1px solid rgba(37, 99, 235, .16);
      box-shadow: 0 24px 65px rgba(39, 74, 125, .14);
      margin: 1.5rem auto 1rem; max-width: 820px;
    }
    .tg-mail-icon { font-size: 2.4rem; }
    .tg-mail-eyebrow { color: #1266d6; font-size: .78rem; font-weight: 800;
      letter-spacing: .16em; text-transform: uppercase; }
    .tg-mail-card h1 { color: #102c48; font-size: clamp(2rem, 4vw, 3rem);
      margin: .45rem 0 .65rem; }
    .tg-mail-address { display: inline-block; padding: .65rem 1rem; border-radius: 14px;
      background: rgba(255,255,255,.78); color: #1558ad; font-weight: 700; }
    .tg-mail-note { color: #52677e; font-size: 1rem; line-height: 1.7; }
    </style>
    """, unsafe_allow_html=True)
    st.markdown(f"""
    <section class="tg-mail-card">
      <div class="tg-mail-icon">✉️ ✨</div>
      <div class="tg-mail-eyebrow">One quick stop before takeoff</div>
      <h1>Check your inbox</h1>
      <p class="tg-mail-note">We sent a confirmation link to:</p>
      <div class="tg-mail-address">{safe_email}</div>
      <p class="tg-mail-note">Open the email and confirm your address to unlock your TravelGenie account. If it’s missing, check spam or request another link.</p>
    </section>
    """, unsafe_allow_html=True)
    left, right = st.columns(2)
    with left:
        if st.button("Back to sign in", type="primary", width="stretch", key="email_check_login"):
            st.session_state.pop("pending_confirmation_email", None)
            st.rerun()
    with right:
        if st.button("Send a fresh link", width="stretch", key="email_check_resend"):
            try:
                pending = resend_verification(email)
                if pending:
                    account = get_pending_user(pending[0])
                    if account:
                        _deliver_confirmation(email, account["name"], pending[1])
                st.success("If your account is still awaiting confirmation, a fresh link is on its way.")
            except EmailConfigurationError as exc:
                st.error(str(exc))


def render_auth_gate() -> dict | None:
    """Return the verified account or render the public account screens."""
    init_db()
    token = st.query_params.get("verify")
    if token:
        account = verify_email(str(token))
        st.query_params.clear()
        if account:
            try:
                send_welcome(account["email"], account["name"])
                st.session_state.auth_notice = "Your email is confirmed. You’re now signed up for TravelGenie AI. Sign in below."
            except EmailConfigurationError:
                st.session_state.auth_notice = "Your email is confirmed. Your account is ready; the welcome email could not be delivered."
        else:
            st.session_state.auth_notice = "That confirmation link is invalid or expired. Request a new one below."
        st.rerun()

    user_id = st.session_state.get("auth_user_id")
    if user_id:
        account = get_user(user_id)
        if account:
            return account
        st.session_state.pop("auth_user_id", None)

    _render_auth_theme()
    pending_email = st.session_state.get("pending_confirmation_email")
    if pending_email:
        _render_email_check(pending_email)
        return None

    left, right = st.columns([1.05, 0.95], gap="large")
    with left:
        st.markdown('<div class="tg-brand">🌴 TravelGenie <span style="color:#38a5ff">AI</span></div>', unsafe_allow_html=True)
        st.markdown('<div class="tg-eyebrow">Welcome to TravelGenie</div>', unsafe_allow_html=True)
        st.markdown('<div class="tg-headline">Discover<br>The <span>World</span></div>', unsafe_allow_html=True)
        st.markdown('<div class="tg-copy">Plan smarter, travel better with AI-powered recommendations, personalized itineraries and unforgettable experiences.</div>', unsafe_allow_html=True)
        f1, f2 = st.columns(2)
        with f1:
            st.markdown('<div class="tg-features">🗺️ &nbsp; AI itinerary planner<br><small>Personalized trips in seconds</small></div>', unsafe_allow_html=True)
            st.markdown('<div class="tg-features">✈️ &nbsp; Explore destinations<br><small>Handpicked places and experiences</small></div>', unsafe_allow_html=True)
        with f2:
            st.markdown('<div class="tg-features">🛏️ &nbsp; Flexible stays<br><small>Find stays for your trip</small></div>', unsafe_allow_html=True)
            st.markdown('<div class="tg-features">₹ &nbsp; Budget friendly<br><small>Get the most from your trip</small></div>', unsafe_allow_html=True)

    with right:
        with st.container(border=True):
            st.markdown('<div class="tg-login-title">Welcome back</div><div class="tg-login-subtitle">Log in to continue your travel journey</div>', unsafe_allow_html=True)
            notice = st.session_state.pop("auth_notice", None)
            if notice:
                st.success(notice)

            login_tab, signup_tab = st.tabs(["Log in", "Sign up"])
            with login_tab:
                with st.form("account_login", clear_on_submit=False):
                    email = st.text_input("Email", key="login_email", autocomplete="email")
                    password = st.text_input("Password", type="password", key="login_password", autocomplete="current-password")
                    submitted = st.form_submit_button("Log in", type="primary", width="stretch")
                if submitted:
                    try:
                        account = login_user(email, password)
                        st.session_state.auth_user_id = account["id"]
                        st.rerun()
                    except AuthError as exc:
                        st.error(str(exc))

            with signup_tab:
                st.caption("Create an account with your email. We’ll send a confirmation link, then a welcome email.")
                with st.form("account_signup", clear_on_submit=True):
                    name = st.text_input("Your name", key="signup_name", autocomplete="name")
                    email = st.text_input("Email address", key="signup_email", autocomplete="email")
                    password = st.text_input("Create password", type="password", key="signup_password", autocomplete="new-password")
                    confirm = st.text_input("Confirm password", type="password", key="signup_confirm", autocomplete="new-password")
                    submitted = st.form_submit_button("Create account", type="primary", width="stretch")
                if submitted:
                    if password != confirm:
                        st.error("The passwords do not match.")
                    else:
                        try:
                            _user_id, token = register_user(name, email, password)
                            try:
                                _deliver_confirmation(email.strip(), name.strip(), token)
                                st.session_state.pending_confirmation_email = email.strip()
                                st.rerun()
                            except EmailConfigurationError as exc:
                                st.warning(f"Your account is saved but not verified. {exc} Configure email, then use Resend confirmation.")
                        except AuthError as exc:
                            st.error(str(exc))

    return None

