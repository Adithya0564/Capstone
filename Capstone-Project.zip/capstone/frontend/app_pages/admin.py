"""Admin-only account and usage overview; private chat message text is hidden."""
from datetime import datetime
from pathlib import Path
import sys

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from auth_helpers import require_admin
from src.auth_store import admin_summary

require_admin()
st.title("Admin portal")
st.caption("Account and usage overview. Chat contents are private and are not displayed here.")
summary = admin_summary()
totals = summary["totals"]
metrics = st.columns(4)
metrics[0].metric("Registered accounts", totals["users"])
metrics[1].metric("Email verified", totals["verified_users"])
metrics[2].metric("Conversations", totals["conversations"])
metrics[3].metric("Messages", totals["messages"])

def _format_time(value: float | None) -> str:
    return datetime.fromtimestamp(value).strftime("%Y-%m-%d %H:%M") if value else "—"

st.subheader("Accounts")
if summary["users"]:
    users = [{**row, "created_at": _format_time(row["created_at"]),
              "verified": "Yes" if row["verified"] else "No"} for row in summary["users"]]
    st.dataframe(pd.DataFrame(users).drop(columns=["id"]), hide_index=True, width="stretch")
else:
    st.info("No accounts have signed up yet.")

st.subheader("Recent conversation activity")
if summary["recent_conversations"]:
    recent = [{**row, "updated_at": _format_time(row["updated_at"])} for row in summary["recent_conversations"]]
    st.dataframe(pd.DataFrame(recent), hide_index=True, width="stretch")
else:
    st.info("No conversations have been started yet.")
