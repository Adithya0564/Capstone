"""TravelGenie AI: a polished travel-planning homepage backed by FastAPI."""
from __future__ import annotations

import os
from html import escape
from pathlib import Path
import sys
import requests
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from auth_helpers import require_user
from voice_input import voice_input

require_user()

st.markdown(r"""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700;800&display=swap');
:root{--blue:#0866df;--navy:#092944;--ink:#102033;--muted:#63748a;--line:#e3eaf2}
.stApp{background:#f7f9fc;color:var(--ink);font-family:'DM Sans',sans-serif}
.block-container{max-width:1480px;padding:0 2.1rem 3rem!important}
header[data-testid="stHeader"]{background:transparent}
[data-testid="stToolbar"]{right:1rem}
h1,h2,h3{font-family:'Playfair Display',Georgia,serif!important;color:var(--ink);letter-spacing:-.025em}
.brandbar{height:76px;display:flex;align-items:center;justify-content:space-between;gap:20px;color:#12243a}
.brand{display:flex;align-items:center;gap:11px;min-width:245px}
.brand-mark{font-size:34px;line-height:1}.brand-name{font-size:24px;font-weight:800;letter-spacing:-1px}.brand-name span{color:var(--blue)}
.brand-tag{font-size:10px;color:#5d7188;letter-spacing:.13em;margin-top:-2px}
.navlinks{display:flex;justify-content:center;align-items:center;gap:36px;flex:1}
.navlinks a{color:#192a40;text-decoration:none;font-weight:600;font-size:14px;padding:12px 0;border-bottom:2px solid transparent}
.navlinks a:hover,.navlinks a.active{color:var(--blue);border-color:var(--blue)}
.nav-actions{display:flex;align-items:center;gap:12px;color:#14263b;font-size:23px;white-space:nowrap}
.nav-actions a{color:inherit;text-decoration:none}
.hero{height:465px;margin:0 -2.1rem;background-image:linear-gradient(90deg,rgba(4,34,57,.88) 0%,rgba(5,41,67,.64) 39%,rgba(7,43,62,.05) 76%),linear-gradient(0deg,rgba(0,19,34,.28),transparent 40%),url('https://images.unsplash.com/photo-1530789253388-582c481c54b0?auto=format&fit=crop&w=2200&q=88');background-position:center 48%;background-size:cover;position:relative;color:#fff;padding:54px max(5vw,4rem) 0;box-sizing:border-box}
.hero-kicker{color:#a7d4ff;letter-spacing:.2em;text-transform:uppercase;font-size:12px;font-weight:700;margin-bottom:12px}
.hero h1{font-family:'Playfair Display',Georgia,serif!important;color:#fff;font-size:clamp(42px,5.2vw,68px);font-weight:700;line-height:1.02;max-width:660px;margin:0 0 10px;text-shadow:0 2px 18px rgba(0,0,0,.22)}
.hero-copy{font-size:17px;line-height:1.55;max-width:560px;color:#f2f6fb}
.flight-path{position:absolute;left:42%;top:150px;color:#ff922e;font-size:35px;transform:rotate(-16deg);opacity:.95}
.hero-note{position:absolute;right:5%;top:190px;color:#fff;font:italic 26px 'Playfair Display',serif;text-align:center;transform:rotate(-7deg);text-shadow:0 2px 12px #16334a}
.st-key-trip_search{position:relative;z-index:5;margin:-126px 0 0!important;padding:18px 20px 14px!important;background:rgba(255,255,255,.92);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.7);border-radius:19px;box-shadow:0 15px 45px rgba(5,29,51,.25)}
.st-key-trip_search [data-testid="stWidgetLabel"] label{font-size:12px!important;font-weight:700;color:#24364d!important}
.st-key-trip_search input,.st-key-trip_search textarea,.st-key-trip_search [data-baseweb="select"]>div{background:#fff!important;border-color:#e1e8f0!important;border-radius:10px!important;color:#21344c!important}
.stButton>button[kind="primary"],.stFormSubmitButton>button[kind="primary"]{background:var(--blue)!important;border:0!important;border-radius:11px!important;color:white!important;font-weight:700!important;min-height:47px;box-shadow:0 5px 15px rgba(8,102,223,.2)}
.stButton>button:not([kind="primary"]),.stFormSubmitButton>button:not([kind="primary"]){border-radius:10px!important;border-color:#ccdbec!important;color:#1f4774!important;background:white!important}
.st-key-feature_strip{position:relative;z-index:3;margin:18px 0 35px;padding:12px;background:#fff;border:1px solid #edf1f5;border-radius:15px;box-shadow:0 8px 24px rgba(21,48,76,.08)}
.st-key-feature_strip .stButton>button{height:68px;border:0!important;border-radius:12px!important;background:#fff!important;color:#172b43!important;font-weight:700!important;white-space:normal!important;line-height:1.25!important;box-shadow:none!important}
.st-key-feature_strip .stButton>button:hover{background:#f2f7ff!important;color:var(--blue)!important;transform:translateY(-1px)}
.section-kicker{font-size:11px;font-weight:800;color:var(--blue);letter-spacing:.16em;text-transform:uppercase;margin-bottom:4px}
.section-title{font-family:'Playfair Display',Georgia,serif;font-size:30px;font-weight:700;color:#10243a;line-height:1.2}
.section-sub{color:#64758b;font-size:14px;margin-top:3px}
.dest-card{height:190px;border-radius:15px;background-size:cover;background-position:center;position:relative;overflow:hidden;box-shadow:0 5px 16px rgba(16,37,59,.17);margin:8px 0 3px}
.dest-card:before{content:'';position:absolute;inset:0;background:linear-gradient(0deg,rgba(4,23,38,.8),transparent 65%)}
.dest-copy{position:absolute;left:15px;right:12px;bottom:13px;color:white;z-index:1}.dest-name{font:700 23px 'Playfair Display',serif}.dest-meta{font-size:12px;color:#f3f7fa}
.cta-band{margin:42px -2.1rem 0;padding:29px max(5vw,4rem);background:linear-gradient(110deg,#052746,#064b76);color:white;display:flex;justify-content:space-between;align-items:center;gap:25px}
.cta-band h3{font-family:'Playfair Display',serif!important;color:white;margin:2px 0 4px;font-size:25px}.cta-band p{margin:0;color:#c4d8e9;font-size:13px}.cta-kicker{font-size:10px;letter-spacing:.17em;text-transform:uppercase;color:#80c3ff;font-weight:700}
.plan-panel{background:white;border:1px solid #e5ebf2;border-radius:18px;padding:22px 24px;box-shadow:0 8px 24px rgba(18,46,76,.05);margin:28px 0}
.evidence-card{border:1px solid #e8edf3;border-radius:12px;padding:13px 15px;margin:9px 0;background:#fbfcfe}
.place-card{height:100%;border:1px solid #e5ebf2;border-radius:14px;padding:12px;background:#fff;box-shadow:0 5px 16px rgba(18,46,76,.06)}
.place-title{font-weight:800;color:#10243a;font-size:15px;margin:4px 0}.place-rating{color:#a96900;font-weight:700;font-size:13px}.place-address{font-size:12px;color:#64758b;min-height:32px}
.stCaption{color:#60738a}
@media(max-width:900px){.navlinks{gap:13px}.navlinks a{font-size:12px}.nav-actions{font-size:18px}.brand{min-width:auto}.brand-tag{display:none}.hero{height:430px;padding-left:1.5rem;padding-right:1.5rem}.hero-note,.flight-path{display:none}}
@media(max-width:650px){.block-container{padding-left:1rem!important;padding-right:1rem!important}.brand-name{font-size:20px}.navlinks{display:none}.hero{height:430px;margin:0 -1rem;padding-top:48px;background-position:58% center}.hero h1{font-size:43px}.hero-copy{font-size:15px}.st-key-trip_search{margin-top:-90px!important;padding:14px!important}.st-key-feature_strip [data-testid="stHorizontalBlock"]{flex-wrap:wrap}.st-key-feature_strip [data-testid="column"]{min-width:44%!important}.cta-band{margin-left:-1rem;margin-right:-1rem;padding:25px 1rem;display:block}.section-title{font-size:26px}}
</style>
""", unsafe_allow_html=True)

if "trip_query" not in st.session_state:
    st.session_state.trip_query = ""
if "destination_input" not in st.session_state:
    st.session_state.destination_input = ""
if "result" not in st.session_state:
    st.session_state.result = None
if "route_mode" not in st.session_state:
    st.session_state.route_mode = False
if "route_stops" not in st.session_state:
    st.session_state.route_stops = ""
if "trip_interests" not in st.session_state:
    st.session_state.trip_interests = ""
if "trip_budget" not in st.session_state:
    st.session_state.trip_budget = 30000
if "assistant_default_applied" not in st.session_state:
    st.session_state.assistant_open = False
    st.session_state.assistant_default_applied = True

def _choose_destination(destination: str) -> None:
    st.session_state.destination_input = destination
    st.session_state.quick_plan_destination = destination
    if st.session_state.get("experience_duration"):
        st.session_state.quick_days = int(st.session_state.experience_duration)
    if st.session_state.get("experience_interests"):
        st.session_state.quick_interests = ", ".join(st.session_state.experience_interests)

def _close_assistant() -> None:
    st.session_state.assistant_open = False

def _close_budget_helper() -> None:
    st.session_state.budget_helper_open = False

def _select_feature(action: str) -> None:
    st.session_state.feature_action = action
    if action == "planner":
        st.session_state.trip_query = "Plan a relaxed 5-day trip with time to explore and unwind."
    elif action == "assistant":
        st.session_state.assistant_open = True
    elif action == "budget":
        st.session_state.budget_helper_open = True
        st.session_state.pop("budget_place_context", None)
        st.session_state.pop("osm_budget_places", None)
    elif action == "stays":
        if not (st.session_state.get("result") or {}).get("destination"):
            st.session_state.trip_query = "Plan a trip and suggest well-rated places to stay."
    elif action == "experiences":
        st.session_state.experience_query = "A trip around local food, sightseeing, and nature."
    elif action == "multi_stop":
        st.session_state.route_mode = True
        if not st.session_state.route_stops:
            st.session_state.route_stops = "Hyderabad, Goa, Mumbai"
        st.session_state.trip_query = "Plan a multi-stop trip in the order listed, allowing time to travel between stops."

def _send_plan(query: str, destination: str, days: int, budget: int, travelers: int, interests: str, travel_type: str | None, multi_stop: bool = False) -> tuple[bool, dict | None]:
    if travel_type not in {"Solo", "Couple", "Family", "Friends"}:
        st.session_state.plan_error = "Choose who you are traveling with before creating your itinerary."
        return False, None
    query = query.strip()
    if len(query) < 8:
        if destination.strip():
            route_or_trip = "multi-stop trip through" if multi_stop else "trip to"
            query = f"Plan a {days}-day {route_or_trip} {destination.strip()} for {travelers} traveler(s)."
            if interests.strip():
                query += f" Interests: {interests.strip()}."
        else:
            st.session_state.plan_error = "Describe your trip or choose a destination to get started."
            return False, None
    body = {
        "query": query,
        "destination": destination.strip() or None,
        "duration_days": int(days),
        "budget": float(budget) if budget else None,
        "travelers": int(travelers),
        "group_size": int(travelers),
        "travel_type": travel_type,
        "interests": [item.strip() for item in interests.split(",") if item.strip()],
        "multi_stop": bool(multi_stop),
    }
    try:
        response = requests.post(st.session_state.api_url + "/itinerary", json=body, timeout=45)
        if not response.ok:
            try:
                detail = response.json().get("detail", "The trip request could not be processed.")
            except (ValueError, requests.RequestException):
                detail = "The trip request could not be processed."
            st.session_state.plan_error = detail if isinstance(detail, str) else "Check the trip details and try again."
            return False, None
        st.session_state.result = response.json()
        st.session_state.last_request = body
        st.session_state.plan_error = ""
        return True, None
    except requests.RequestException:
        st.session_state.plan_error = "The planning service is unavailable. Start FastAPI and try again."
        return False, None

@st.dialog("Plan your trip", width="large")
def _quick_plan_dialog(destination: str) -> None:
    st.markdown(f"### A trip to {escape(destination)}")
    st.write("Choose your trip length, budget, group size, and who is traveling. I’ll tailor the stops to your group.")
    with st.form("quick_plan_form"):
        q1, q2, q3 = st.columns(3)
        with q1:
            quick_days = st.number_input("How many days?", min_value=1, max_value=30, value=5, key="quick_days")
        with q2:
            quick_budget = st.number_input("Total budget (₹)", min_value=0, value=30000, step=5000, key="quick_budget")
        with q3:
            quick_travelers = st.number_input("Travelers", min_value=1, max_value=20, value=2, key="quick_travelers")
        quick_travel_type = st.selectbox("Who are you traveling with?", ["Choose your group…", "Solo", "Couple", "Family", "Friends"], key="quick_travel_type")
        quick_interests = st.text_input("What would you enjoy?", placeholder="Food, beaches, history…", key="quick_interests")
        submitted = st.form_submit_button("Create my trip plan", type="primary", icon=":material/auto_awesome:", width="stretch")
    if submitted:
        query = f"Plan a {quick_days}-day trip to {destination} for {quick_travelers} traveler(s)."
        if quick_interests.strip():
            query += f" Interests: {quick_interests.strip()}."
        with st.spinner("Creating your itinerary…"):
            selected_type = None if quick_travel_type == "Choose your group…" else quick_travel_type
            success, _ = _send_plan(query, destination, quick_days, quick_budget, quick_travelers, quick_interests, selected_type)
        if success:
            st.session_state.quick_plan_destination = None
            st.switch_page("app_pages/itinerary.py")
        else:
            st.error(st.session_state.get("plan_error", "The plan could not be generated."))
    if st.button("Cancel", key="quick_plan_cancel"):
        st.session_state.quick_plan_destination = None

api = os.getenv("VOYAGE_API_URL", "http://127.0.0.1:8000")
st.session_state.api_url = api

# Header/navigation
st.markdown("""
<div class="brandbar">
  <div class="brand"><div class="brand-mark">🌴</div><div><div class="brand-name">Travel<span>Genie</span></div><div class="brand-tag">EXPLORE · PLAN · WANDER</div></div></div>
  <nav class="navlinks"><a class="active" href="#home">Home</a><a href="#destinations">Destinations</a><a href="#planner">Itineraries</a><a href="#experiences">Experiences</a><a href="#about">About</a></nav>
  <div class="nav-actions"><a href="#planner" aria-label="Search">⌕</a><a href="#destinations" aria-label="Saved destinations">♡</a></div>
</div>
<div id="home" class="hero">
  <div class="hero-kicker">Explore the world</div>
  <h1>Find experiences<br>that fit you</h1>
  <div class="hero-copy">Tell us what matters on your trip. We’ll retrieve similar traveler rating profiles, show what they rated highly, and suggest destinations to explore.</div>
  <div class="flight-path">﹏﹏﹏ ✈</div><div class="hero-note">Collect<br>moments,<br>not things</div>
</div>
""", unsafe_allow_html=True)

previous_result = st.session_state.get("result") or {}
spoken_plan = previous_result.get("narrative") or previous_result.get("message") or previous_result.get("explanation", "")
if previous_result.get("itinerary"):
    spoken_plan = " ".join(f"Day {day['day']}. Morning: {day['morning']} Afternoon: {day['afternoon']} Evening: {day['evening']}" for day in previous_result["itinerary"])
voice_result = voice_input(key="travel_voice", speak_text=spoken_plan)
transcript = getattr(voice_result, "transcript", None)
if transcript and transcript != st.session_state.get("last_voice_transcript"):
    st.session_state.experience_query = (st.session_state.get("experience_query", "") + " " + transcript).strip()
    st.session_state.last_voice_transcript = transcript

# Make preference retrieval the primary journey. Trip budget and itinerary inputs
# are collected only after the traveler picks a destination idea.
with st.container(key="trip_search"):
    with st.form("experience_search_form", border=False):
        experience_query = st.text_area(
            "Describe what you want from this trip",
            placeholder="A 5-day trip focused on beaches, sightseeing, and local food…",
            height=94,
            key="experience_query",
        )
        experience_clicked = st.form_submit_button(
            "Find similar traveler ratings", type="primary", icon=":material/search:", width="stretch"
        )

if experience_clicked:
    query = experience_query.strip()
    if len(query) < 8:
        st.session_state.experience_search_error = "Describe at least one travel priority so we can find similar ratings."
    else:
        try:
            with st.spinner("Searching traveler ratings for similar priorities…"):
                response = requests.post(
                    st.session_state.api_url + "/recommendations/search",
                    json={"query": query, "top_k": 5},
                    timeout=90,
                )
                response.raise_for_status()
                st.session_state.experience_result = response.json()
                st.session_state.experience_search_error = ""
        except (requests.RequestException, ValueError) as exc:
            st.session_state.experience_search_error = f"Experience search is unavailable right now: {exc}"

if st.session_state.get("experience_search_error"):
    st.error(st.session_state.experience_search_error)

experience_result = st.session_state.get("experience_result")
if experience_result:
    st.markdown("<div class='section-kicker'>Based on traveler ratings</div>", unsafe_allow_html=True)
    st.markdown("## Similar traveler ratings")
    if experience_result.get("query"):
        st.caption(f"Matched to your request: {experience_result['query']}")
    st.caption("Source data contains average ratings for place categories, not trip diaries or city-level scores. Destination ideas use curated interest matches.")
    if experience_result.get("answer"):
        st.info(experience_result["answer"], icon=":material/auto_awesome:")
    if experience_result.get("duration_days"):
        st.info(f"We noted your {experience_result['duration_days']}-day trip. The ratings dataset does not record trip duration, so duration is not used as a filter.")
    st.session_state.experience_duration = experience_result.get("duration_days")
    st.session_state.experience_interests = experience_result.get("matched_interests", [])

    category_evidence = experience_result.get("matched_categories", [])
    interest_highlights = experience_result.get("interest_highlights", [])
    if interest_highlights:
        st.markdown("### How similar travelers rated these interests")
        st.caption("These are place-category rating averages across the similar profiles, not ratings for destinations or individual venues.")
        rating_cols = st.columns(min(3, len(interest_highlights)))
        for index, item in enumerate(interest_highlights):
            with rating_cols[index % len(rating_cols)]:
                with st.container(border=True):
                    st.markdown(f"**{item['interest'].title()}**")
                    if item["top_categories"]:
                        for category in item["top_categories"]:
                            st.write(f"{category['category'].title()} · **{category['similar_profile_average']:.2f} / 5**")
                            st.caption(f"Based on {category['profiles_with_rating']} similar profile(s)")
                    else:
                        st.write("No recorded ratings for this interest in the retrieved profiles.")
    elif not experience_result.get("matched_interests"):
        st.warning("I couldn’t map those priorities to a rating category yet. Try beaches, sightseeing, local food, nightlife, relaxation, or shopping.")

    profiles_found = experience_result.get("similar_profiles", [])
    if profiles_found:
        with st.expander(f"See the {len(profiles_found)} similar traveler profiles and full rating evidence"):
            profile_cols = st.columns(min(3, len(profiles_found)))
            for index, profile in enumerate(profiles_found):
                with profile_cols[index % len(profile_cols)]:
                    with st.container(border=True):
                        st.markdown(f"**{profile['profile_label']}**")
                        st.caption(f"Overall average across rated categories: {profile['average_rating']:.2f} / 5")
                        for rating in profile.get("matched_category_ratings", []):
                            st.write(f"{rating['category'].title()}: **{rating['rating']:.2f} / 5**")
                        other_high = [item for item in profile.get("highly_rated_categories", [])
                                      if item["category"].casefold() not in {x["category"].casefold() for x in profile.get("matched_category_ratings", [])}]
                        if other_high:
                            st.caption("Also rated highly: " + ", ".join(f"{item['category']} ({item['rating']:.1f})" for item in other_high[:3]))

    suggested_destinations = experience_result.get("destination_suggestions", [])
    if suggested_destinations:
        st.markdown("### Recommended destinations · ranked priorities")
        st.caption("Priority order uses retrieved travelers’ ratings for matching place categories plus curated destination tags. A score is a category-rating average, not a rating of the destination itself.")
        destination_cols = st.columns(min(4, len(suggested_destinations)))
        for index, place in enumerate(suggested_destinations):
            with destination_cols[index % len(destination_cols)]:
                with st.container(border=True):
                    st.caption(f"PRIORITY {place.get('priority', index + 1)}")
                    st.markdown(f"#### {place['name']}")
                    st.caption(place["country"])
                    score = place.get("similar_traveler_category_rating")
                    if score is not None:
                        st.write(f"Similar travelers’ matching category ratings · **{score:.2f} / 5**")
                        st.caption("Not a destination rating")
                    st.write(f"Matches {place['match_count']} interest priorities")
                    st.caption(", ".join(tag.title() for tag in place["matched_interests"]))
                    st.button(
                        f"Choose {place['name']}", key=f"choose_suggested_{place['name']}",
                        on_click=_choose_destination, args=(place["name"],), width="stretch",
                    )

with st.container(key="feature_strip"):
    feature_cols = st.columns(6, gap="small")
    feature_buttons = (
        ("planner", "AI itinerary planner", ":material/map:"),
        ("assistant", "Travel assistant anytime", ":material/auto_awesome:"),
        ("budget", "Budget-aware planning", ":material/currency_rupee:"),
        ("stays", "Flexible stays", ":material/hotel:"),
        ("experiences", "Experiences you choose", ":material/local_activity:"),
        ("multi_stop", "Multi-stop journeys", ":material/route:"),
    )
    for col, (action, label, icon) in zip(feature_cols, feature_buttons):
        with col:
            st.button(label, key=f"feature_{action}", icon=icon, help=f"Open {label.lower()} options", on_click=_select_feature, args=(action,), width="stretch")

feature_action = st.session_state.get("feature_action")
if feature_action == "planner":
    st.info("Your travel-priority prompt is ready. Search similar traveler ratings first, then choose a destination to plan the details.")
elif feature_action == "budget":
    pass
elif feature_action == "stays" and not (st.session_state.get("result") or {}).get("destination"):
    st.info("Create a trip plan, then request nearby stays and food. Free OpenStreetMap listings include map links; ratings and photos require an enabled Google Places key.")
elif feature_action == "experiences":
    st.info("Your experience-search prompt is ready. Edit your priorities and search the traveler ratings above.")
elif feature_action == "multi_stop":
    st.info("Multi-stop mode is on. Enter the stops in travel order, then generate your route draft.")

if st.session_state.get("assistant_open"):
    with st.container(border=True):
        assistant_title, assistant_close = st.columns([8, 1])
        with assistant_title:
            st.subheader("🧭 Travel assistant: famous places")
            st.caption("Tell me where you’re going and who’s traveling. I’ll show mapped sights that fit your group.")
        with assistant_close:
            st.button("×", key="assistant_close_inline", on_click=_close_assistant, help="Close travel assistant")
        with st.form("assistant_discovery_form"):
            assistant_destination = st.text_input("Where are you visiting?", placeholder="For example, Goa or Kyoto", key="assistant_destination")
            assistant_group = st.selectbox("Who are you traveling with?", ["Couple", "Family", "Friends"], key="assistant_group")
            assistant_search = st.form_submit_button("Show famous places", type="primary", icon=":material/travel_explore:")
        if assistant_search:
            if len(assistant_destination.strip()) < 2:
                st.error("Enter a destination to find places.")
            else:
                try:
                    st.session_state.pop("assistant_sights", None)
                    with st.spinner(f"Finding popular mapped sights in {assistant_destination.strip()}…"):
                        response = requests.post(
                            st.session_state.api_url + "/api/travel/attractions",
                            json={"destination": assistant_destination.strip(), "group_type": assistant_group.casefold()},
                            timeout=50,
                        )
                        response.raise_for_status()
                        st.session_state.assistant_sights = response.json()
                except (requests.RequestException, ValueError) as exc:
                    st.error(f"Place search is unavailable right now: {exc}")
        sights = st.session_state.get("assistant_sights")
        if sights:
            st.markdown(f"#### Popular sights in {escape(sights.get('destination', 'your destination'))} for {escape(sights.get('group_type', 'your group'))}")
            st.caption(sights.get("notice", ""))
            places = sights.get("places", [])
            if not places:
                st.info("No named sights were found nearby. Try a city or region name.")
            else:
                sight_cols = st.columns(3, gap="medium")
                for index, place in enumerate(places):
                    title = escape(str(place.get("name", "Popular place")))
                    category = escape(str(place.get("category", "Sight")))
                    description = escape(str(place.get("description") or place.get("address") or "A popular mapped place to explore."))
                    map_url = escape(str(place.get("maps_url", "")), quote=True)
                    website = escape(str(place.get("website", "")), quote=True)
                    detail_link = f'<br><a href="{website}" target="_blank" rel="noopener">More details ↗</a>' if website else ""
                    with sight_cols[index % 3]:
                        st.markdown(
                            f'<div class="place-card"><div class="place-title">{title}</div><span class="badge">{category}</span><div class="place-address">{description}</div><a href="{map_url}" target="_blank" rel="noopener">Open map ↗</a>{detail_link}</div>',
                            unsafe_allow_html=True,
                        )
            if sights.get("attribution_url"):
                st.caption(f"Data: {sights.get('attribution', 'OpenStreetMap contributors')} · {sights['attribution_url']}")

if st.session_state.get("budget_helper_open"):
    with st.container(border=True):
        budget_title, budget_close = st.columns([8, 1])
        with budget_title:
            st.subheader("💸 Budget-aware stays & restaurants")
            st.caption("Set your total trip budget. I’ll prioritize budget-oriented or premium options for your trip size.")
        with budget_close:
            st.button("×", key="budget_helper_close", on_click=_close_budget_helper, help="Close budget options")
        with st.form("budget_place_form"):
            bp1, bp2 = st.columns([2, 1])
            with bp1:
                budget_destination = st.text_input("Destination", value=st.session_state.get("destination_input", ""), key="budget_destination")
            with bp2:
                budget_total = st.number_input("Total budget (₹)", min_value=0, value=int(st.session_state.get("trip_budget", 30000)), step=5000, key="budget_total")
            bp3, bp4 = st.columns(2)
            with bp3:
                budget_days = st.number_input("Days", min_value=1, max_value=30, value=int(st.session_state.get("trip_days", 5)), key="budget_days")
            with bp4:
                budget_travelers = st.number_input("Travelers", min_value=1, max_value=20, value=int(st.session_state.get("trip_travelers", 2)), key="budget_travelers")
            budget_search = st.form_submit_button("Find stays & restaurants", type="primary", icon=":material/search:")
        budget_places = None
        if budget_search:
            if len(budget_destination.strip()) < 2:
                st.error("Enter a destination first.")
            elif budget_total <= 0:
                st.error("Enter a trip budget greater than ₹0.")
            else:
                per_person_day = budget_total / budget_days / budget_travelers
                tier = "premium" if per_person_day >= 8000 else "budget-friendly"
                st.session_state.budget_place_tier = tier
                st.session_state.budget_place_context = {
                    "destination": budget_destination.strip(), "budget": int(budget_total),
                    "days": int(budget_days), "travelers": int(budget_travelers),
                    "per_person_day": per_person_day,
                }
                try:
                    st.session_state.pop("osm_budget_places", None)
                    with st.spinner(f"Finding {tier} options in {budget_destination.strip()}…"):
                        response = requests.post(
                            st.session_state.api_url + "/api/travel/places",
                            json={"destination": budget_destination.strip(), "multi_stop": False},
                            timeout=50,
                        )
                        response.raise_for_status()
                        budget_places = response.json()
                    if budget_places.get("source") == "OpenStreetMap":
                        st.session_state.osm_budget_places = budget_places
                except (requests.RequestException, ValueError) as exc:
                    st.error(f"Stay and restaurant search is unavailable right now: {exc}")
        budget_places = budget_places or st.session_state.get("osm_budget_places")
        budget_context = st.session_state.get("budget_place_context")
        tier = st.session_state.get("budget_place_tier", "budget-friendly")
        if budget_places and budget_context:
            st.markdown(
                f"#### {('✨ Premium' if tier == 'premium' else '🌿 Budget-friendly')} picks for {escape(budget_context['destination'])}"
            )
            st.caption(
                f"₹{budget_context['budget']:,} total · {budget_context['days']} days · {budget_context['travelers']} traveler(s) · "
                f"about ₹{budget_context['per_person_day']:,.0f} per person/day. Premium suggestions start at ₹8,000 per person/day."
            )
            st.info("Free map listings do not consistently include prices or verified luxury classifications. These are prioritized by available accommodation type, class, or price tags; confirm current rates directly.")
            for section_key, section_title in (("stays", "🏨 Stays"), ("food", "🍽️ Restaurants & cafes")):
                entries = list(budget_places.get(section_key, []))
                def budget_score(place):
                    category = str(place.get("category", "")).casefold().replace(" ", "_")
                    stars = float(place.get("stars") or 0) if str(place.get("stars") or "").replace(".", "", 1).isdigit() else 0
                    price = str(place.get("price_level", place.get("price_range", ""))).casefold()
                    expensive = price in {"price_level_expensive", "price_level_very_expensive", "expensive", "very_expensive", "$$$", "$$$$"}
                    if tier == "premium":
                        return (3 if price in {"price_level_very_expensive", "very_expensive", "$$$$"} else 2 if expensive else 0) + stars + (2 if category in {"hotel", "resort", "restaurant"} else 0)
                    return (4 if category in {"hostel", "guest_house", "fast_food"} else 3 if category in {"cafe", "apartment"} else 0) - stars - (2 if expensive else 0)
                entries.sort(key=budget_score, reverse=True)
                st.markdown(f"##### {section_title}")
                if not entries:
                    st.write("No mapped listings found for this category.")
                    continue
                option_cols = st.columns(3)
                for index, place in enumerate(entries[:9]):
                    place_name = escape(str(place.get("name", "Local option")))
                    category = escape(str(place.get("category") or place.get("cuisine") or section_key.title()))
                    address = escape(str(place.get("address") or "Address not listed"))
                    extra_details = []
                    if place.get("cuisine"):
                        extra_details.append(str(place["cuisine"]).replace(";", ", "))
                    if place.get("stars"):
                        extra_details.append(f"{place['stars']} stars listed")
                    extra_details.append(str(place.get("price_level") or place.get("price_range") or "Price not listed"))
                    detail_text = escape(" · ".join(extra_details))
                    map_url = escape(str(place.get("maps_url") or ""), quote=True)
                    category_key = str(place.get("category") or "").casefold().replace(" ", "_")
                    stars_text = str(place.get("stars") or "")
                    has_star_data = stars_text.replace(".", "", 1).isdigit()
                    has_high_star_tag = has_star_data and float(stars_text) >= 4
                    has_low_star_tag = has_star_data and float(stars_text) <= 2
                    price_key = str(place.get("price_level") or place.get("price_range") or "").casefold()
                    if tier == "premium":
                        recommendation = "Premium-style listing" if has_high_star_tag or category_key == "resort" or price_key in {"price_level_expensive", "price_level_very_expensive", "expensive", "very_expensive", "$$$", "$$$$"} else "Price/class not listed"
                    else:
                        recommendation = "Budget-oriented type" if category_key in {"hostel", "guest_house", "fast_food", "cafe", "apartment"} or has_low_star_tag or price_key in {"price_level_inexpensive", "inexpensive", "$"} else "Price not listed"
                    with option_cols[index % 3]:
                        st.markdown(f"**{place_name}**")
                        st.markdown(f"`{recommendation}`")
                        st.caption(f"{category} · {detail_text}\n{address}")
                        if map_url:
                            st.markdown(f"[Open map ↗]({map_url})")
            if budget_places.get("attribution"):
                st.caption(budget_places["attribution"])

st.markdown('<div id="destinations"><div class="section-kicker">Find your next favourite place</div><div class="section-title">Popular destinations</div><div class="section-sub">A little inspiration for wherever you want to wander.</div></div>', unsafe_allow_html=True)

destinations = [
    ("Goa", "India · Coast & culture", "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=900&q=82"),
    ("Bali", "Indonesia · Island escape", "https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=900&q=82"),
    ("Kyoto", "Japan · Temples & gardens", "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=900&q=82"),
    ("Dubai", "UAE · City & desert", "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=900&q=82"),
]
card_cols = st.columns(4, gap="small")
for col, (place, meta, image_url) in zip(card_cols, destinations):
    with col:
        st.markdown(f'<div class="dest-card" style="background-image:url(\'{image_url}\')"><div class="dest-copy"><div class="dest-name">{place}</div><div class="dest-meta">⌖ &nbsp;{meta}</div></div></div>', unsafe_allow_html=True)
        st.button(f"Plan a trip to {place}", key=f"pick_{place}", on_click=_choose_destination, args=(place,), width="stretch")

if st.session_state.get("quick_plan_destination"):
    _quick_plan_dialog(st.session_state.quick_plan_destination)

st.markdown("""
<div class="cta-band" id="about"><div><div class="cta-kicker">Plan smarter with AI</div><h3>Let your next trip take shape</h3><p>Share what you enjoy and get a flexible itinerary with preference evidence.</p></div><div style="font-size:45px;letter-spacing:9px">✈　▱　▱　▱</div></div>
""", unsafe_allow_html=True)

st.caption("Destination cards are starter ideas. Review ratings describe attraction categories; they are not destination-level ratings or travel diaries.")

