"""Account-scoped assistant conversations with durable chat history."""
from __future__ import annotations

import os
from pathlib import Path
import sys

import requests
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from auth_helpers import require_user
from voice_input import voice_input
from src.auth_store import add_message, create_conversation, get_messages, list_conversations

user = require_user()
st.title("Travel chat")
st.caption("Ask about traveler ratings and destination ideas. Your conversations are saved to your account.")


def _new_chat() -> None:
    st.session_state.active_conversation_id = None
    st.session_state.pop("chat_draft", None)


with st.sidebar:
    st.subheader("Your chats")
    st.button("New conversation", icon=":material/edit_square:", on_click=_new_chat, width="stretch")
    conversation_rows = list_conversations(user["id"])
    conversation_ids = [row["id"] for row in conversation_rows]
    active_id = st.session_state.get("active_conversation_id")
    if active_id not in conversation_ids:
        active_id = conversation_ids[0] if conversation_ids else None
    if conversation_rows:
        start_index = conversation_ids.index(active_id) if active_id in conversation_ids else 0
        selected_id = st.selectbox(
            "Conversation history",
            conversation_ids,
            index=start_index,
            format_func=lambda item: next((row["title"] for row in conversation_rows if row["id"] == item), "Conversation"),
            label_visibility="collapsed",
        )
        st.session_state.active_conversation_id = selected_id
    else:
        selected_id = None
        st.caption("Your saved conversations will appear here.")

history = get_messages(user["id"], selected_id) if selected_id else []
last_reply = next((item["content"] for item in reversed(history) if item["role"] == "assistant"), "")
voice_result = voice_input(key=f"chat_voice_{selected_id or 'new'}", speak_text=last_reply)
transcript = getattr(voice_result, "transcript", None)
if transcript and transcript != st.session_state.get("last_chat_transcript"):
    previous_draft = st.session_state.get("chat_draft", "")
    st.session_state.chat_draft = f"{previous_draft} {transcript}".strip()
    st.session_state.last_chat_transcript = transcript

if history:
    for item in history:
        with st.chat_message(item["role"]):
            st.markdown(item["content"])
else:
    st.info("Start a conversation by typing or using voice input. For example: ‘I want a five-day trip focused on beaches, sightseeing, and local food. What did similar travelers rate highly?’")

with st.form("travel_chat_form", clear_on_submit=True):
    prompt = st.text_area(
        "Ask TravelGenie",
        key="chat_draft",
        height=84,
        placeholder="Ask a travel question or describe your priorities…",
    )
    send = st.form_submit_button("Send", type="primary", icon=":material/send:")

if send and prompt.strip():
    conversation_id = selected_id or create_conversation(user["id"], prompt.strip()[:90])
    add_message(user["id"], conversation_id, "user", prompt.strip())
    try:
        response = requests.post(
            os.getenv("VOYAGE_API_URL", "http://127.0.0.1:8000") + "/recommendations/search",
            json={"query": prompt.strip(), "top_k": 5},
            timeout=75,
        )
        response.raise_for_status()
        result = response.json()
        reply = result.get("answer") or "I found related traveler rating profiles. Review their category evidence below."
        destinations = result.get("destination_suggestions", [])
        if destinations:
            rows = ["", "**Destination ideas, ranked by matching category evidence:**"]
            for place in destinations[:3]:
                rating = place.get("similar_traveler_category_rating")
                score = f" Similar travelers’ matching category average: **{rating:.2f}/5** (not a destination rating)." if rating is not None else ""
                rows.append(f"- **Priority {place.get('priority', 0)}: {place['name']}, {place['country']}** — matches {', '.join(place.get('matched_interests', []))}.{score}")
            reply += "\n".join(rows)
        category_rows = [item for item in result.get("matched_categories", []) if item.get("similar_profile_average") is not None]
        if category_rows:
            reply += "\n\n**Category evidence:** " + "; ".join(
                f"{item['category']} {item['similar_profile_average']:.2f}/5 ({item['profiles_with_rating']} profiles)"
                for item in category_rows[:6]
            )
    except (requests.RequestException, ValueError):
        reply = "I couldn’t reach the travel recommendation service. Your question is saved; please try again when the API is running."
    add_message(user["id"], conversation_id, "assistant", reply)
    st.session_state.active_conversation_id = conversation_id
    st.rerun()
elif send:
    st.warning("Enter or dictate a question before sending.")
