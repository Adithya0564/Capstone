"""Colorful, dedicated itinerary and optional nearby places page."""
from __future__ import annotations

import html
import os
from pathlib import Path
import sys

import requests
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from auth_helpers import require_user

require_user()

st.markdown(r"""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700;800&display=swap');
.stApp{background:radial-gradient(ellipse at 8% 10%,#d6eaff 0,transparent 31%),radial-gradient(ellipse at 92% 25%,#ffe5d6 0,transparent 30%),linear-gradient(135deg,#e6eef8,#f4efe9 56%,#dcf1ed);color:#172b43;font-family:'DM Sans',sans-serif}
.block-container{max-width:1180px;padding-top:1.3rem!important;padding-bottom:4rem!important}
h1,h2,h3{font-family:'Playfair Display',Georgia,serif!important;color:#10243a}
.trip-hero{padding:38px 42px;border-radius:27px;color:white;background:linear-gradient(115deg,rgba(4,38,73,.96),rgba(9,111,159,.85)),url('https://images.unsplash.com/photo-1530789253388-582c481c54b0?auto=format&fit=crop&w=1800&q=85') center/cover;box-shadow:0 18px 44px #153d6040}
.trip-hero h1{color:white;font-size:clamp(38px,5vw,60px);margin:4px 0 6px}.trip-hero p{color:#e2f4ff;margin:0}.eyebrow{text-transform:uppercase;letter-spacing:.17em;font-size:11px;font-weight:800;color:#7dd3fc}
.stat{border-radius:17px;padding:17px 18px;border:1px solid #ffffffaa;box-shadow:0 9px 25px #24456920;min-height:88px}.stat-blue{background:linear-gradient(135deg,#d5eaff,#edf5ff)}.stat-teal{background:linear-gradient(135deg,#c9f2eb,#e7fbf4)}.stat-coral{background:linear-gradient(135deg,#ffe0d2,#fff0e8)}.stat-violet{background:linear-gradient(135deg,#e6dcff,#f5f0ff)}.stat-label{color:#516984;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em}.stat-value{font-size:21px;font-weight:800;color:#142a44;margin-top:5px}
.day-card{background:linear-gradient(115deg,#e2f0ff,#f0ecff 58%,#fff0e4);border:1px solid #ffffff;border-radius:20px;padding:20px 22px;margin:14px 0;box-shadow:0 12px 30px #173e6020;border-left:6px solid #3289e9}.day-title{font:700 24px 'Playfair Display',serif;color:#122a47;margin-bottom:13px}.slot{background:linear-gradient(145deg,#fafdff,#e7f2ff);border:1px solid #d9e9fa;border-radius:13px;padding:13px 15px;height:100%;color:#31465e;font-size:14px;line-height:1.55}.slot.afternoon{background:linear-gradient(145deg,#fffdf6,#fff0d5);border-color:#f5dfb2}.slot.evening{background:linear-gradient(145deg,#f4fffd,#dff5ef);border-color:#ccebe2}.slot b{display:block;color:#1264c5;font-size:11px;text-transform:uppercase;letter-spacing:.11em;margin-bottom:5px}.place{height:100%;border:1px solid #d7e7f3;border-radius:17px;background:linear-gradient(145deg,#e8f4ff,#f1fbf7);overflow:hidden;box-shadow:0 8px 25px #153d6020}.place img{width:100%;height:150px;object-fit:cover}.place-body{padding:14px}.place-name{font-weight:800;font-size:16px;color:#17304d}.place-meta{color:#506981;font-size:12px;line-height:1.5;margin:6px 0}.badge{display:inline-block;border-radius:999px;background:linear-gradient(100deg,#d8eaff,#d9f5ee);color:#175da8;padding:5px 9px;font-size:11px;font-weight:800;margin:4px 4px 0 0}
.day-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.stop{padding:7px 0;border-bottom:1px solid #d7e6f1}.stop:last-child{border-bottom:0}.stop-action{font-size:11px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:#53718f}.stop a{display:block;color:#075fc1!important;font-size:15px;font-weight:800;text-decoration:none}.stop a:hover{text-decoration:underline}.stop-detail{display:block;color:#536a80;font-size:11px;margin-top:2px}.stop-note{color:#52677d;font-size:13px;padding:7px 0}
@media(max-width:700px){.day-grid{grid-template-columns:1fr}.trip-hero{padding:28px 24px}}
.stAlert{background:linear-gradient(110deg,#e3f2ff,#e4f7f1)!important;border:1px solid #bddcf0!important;color:#173c5c!important;border-radius:15px!important}
.stButton>button[kind="primary"]{background:linear-gradient(100deg,#0875e1,#05a7b5)!important;border:0!important;color:white!important;border-radius:12px!important;font-weight:700!important}
</style>
""",unsafe_allow_html=True)

if "result" not in st.session_state or not st.session_state.result:
    st.info("Your trip plan will appear here after you create one.")
    if st.button("← Back to destinations"):
        st.switch_page("app_pages/home.py")
    st.stop()

result = st.session_state.result
request_data = st.session_state.get("last_request", {})
if result.get("status") == "needs_destination":
    st.warning(result.get("message", "Add a destination to create an itinerary."))
    if st.button("← Choose a destination"):
        st.switch_page("app_pages/home.py")
    st.stop()

destination = result.get("destination") or request_data.get("destination") or "Your trip"
days = result.get("duration_days") or request_data.get("duration_days") or len(result.get("itinerary", []))
travelers = request_data.get("travelers", request_data.get("group_size", 1))
budget = result.get("budget", request_data.get("budget"))
budget_text = f"₹{budget:,.0f}" if isinstance(budget, (int, float)) else "Flexible"
interests = request_data.get("interests") or []

city_key = destination.casefold().strip()
if city_key in {"bangalore", "bengaluru", "banglore", "bengalore"}:
    destination = "Bengaluru"
elif city_key in {"mysore", "mysuru"}:
    destination = "Mysuru"
trip_cities = [destination]
has_mysuru_day_trip = destination == "Bengaluru" and int(days) >= 2
if has_mysuru_day_trip:
    trip_cities.append("Mysuru")
trip_place_key = (tuple(city.casefold() for city in trip_cities), int(days))
named_data = st.session_state.get("named_trip_places")
if st.session_state.get("named_trip_places_key") != trip_place_key:
    named_data = None
if named_data is None:
    try:
        with st.spinner("Finding named cafes, sights, food, and evening activities for your itinerary…"):
            place_response = requests.post(
                st.session_state.api_url + "/api/travel/trip-places",
                json={"destinations": trip_cities},
                timeout=105,
            )
            place_response.raise_for_status()
            named_data = place_response.json().get("results", {})
            st.session_state.named_trip_places = named_data
            st.session_state.named_trip_places_key = trip_place_key
            st.session_state.named_trip_places_error = ""
    except (requests.RequestException, ValueError) as exc:
        st.session_state.named_trip_places = {}
        st.session_state.named_trip_places_key = trip_place_key
        st.session_state.named_trip_places_error = str(exc)
        named_data = {}


def _rank_sights(entries: list[dict], interests: list[str], travel_type: str) -> list[dict]:
    focus = " ".join(interests).casefold()
    group_preferences = {
        "couple": ("viewpoint", "garden", "historic", "museum", "gallery", "beach", "scenic", "waterfront"),
        "family": ("zoo", "aquarium", "theme park", "park", "garden", "museum", "beach", "attraction"),
        "friends": ("theme park", "beach", "viewpoint", "attraction", "arcade", "bowling", "market", "adventure"),
        "solo": ("museum", "gallery", "historic", "market", "garden", "viewpoint", "attraction"),
    }
    group_terms = group_preferences.get(str(travel_type or "").casefold(), ())
    def score(place: dict) -> int:
        category = str(place.get("category", "")).casefold()
        text = f"{place.get('name', '')} {place.get('description', '')} {category}".casefold()
        score_value = 0
        if "museum" in category or "museum" in text:
            score_value += 8
        if any(term in category for term in ("attraction", "viewpoint", "heritage")):
            score_value += 6
        if any(term in category for term in ("historic", "temple", "monument", "palace")):
            score_value += 5
        if any(term in category for term in ("park", "garden", "nature", "waterfall")):
            score_value += 4
        if any(term in focus for term in ("nature", "outdoor", "adventure")) and any(term in text for term in ("park", "garden", "nature", "viewpoint", "waterfall", "peak")):
            score_value += 4
        if any(term in focus for term in ("culture", "history", "art")) and any(term in text for term in ("museum", "historic", "temple", "palace", "gallery", "heritage")):
            score_value += 4
        score_value += sum(4 for term in group_terms if term in text)
        return score_value
    return sorted(entries, key=lambda place: (-score(place), str(place.get("name", "")).casefold()))


def _named_plan(place_data: dict, days: int, interests: list[str], travel_type: str) -> list[dict]:
    primary = place_data.get(destination, {})
    if primary.get("error") or not primary.get("sights") and not primary.get("food"):
        return []
    city_usage: dict[str, set[str]] = {}
    food_usage: dict[str, set[str]] = {}

    def take(entries: list[dict], used: set[str], prefer: str | None = None) -> dict | None:
        ordered = _rank_sights(entries, interests, travel_type)
        if prefer:
            preferred = [p for p in ordered if prefer in str(p.get("category", "")).casefold() or prefer in str(p.get("name", "")).casefold()]
            ordered = preferred + [p for p in ordered if p not in preferred]
        selected = next((p for p in ordered if p.get("id") not in used), None)
        if selected:
            used.add(selected.get("id", selected.get("name", "")))
        return selected

    def take_food(data: dict, used: set[str], prefer_cafe: bool = False) -> dict | None:
        foods = list(data.get("food", []))
        if prefer_cafe:
            foods.sort(key=lambda p: (0 if "cafe" in str(p.get("category", "")).casefold() else 1, str(p.get("name", "")).casefold()))
        selected = next((p for p in foods if p.get("id") not in used), None)
        if selected:
            used.add(selected.get("id", selected.get("name", "")))
        return selected

    plan = []
    for day in range(1, int(days) + 1):
        day_trip = has_mysuru_day_trip and day == 2
        city = "Mysuru" if day_trip else destination
        data = place_data.get(city, {})
        city_usage.setdefault(city, set())
        food_usage.setdefault(city, set())
        if data.get("error") or not data.get("sights") and not data.get("food"):
            plan.append({"day": day, "location": city, "day_trip": day_trip, "morning": [{"text": f"No mapped named places were returned for {city}. Try searching again or choose another destination."}], "afternoon": [], "evening": []})
            continue
        breakfast = take_food(data, food_usage[city], prefer_cafe=True)
        lunch = take_food(data, food_usage[city])
        dinner = take_food(data, food_usage[city])
        museum = take(data.get("sights", []), city_usage[city], prefer="museum")
        other_sight = take(data.get("sights", []), city_usage[city])
        shop = take(data.get("shopping", []), city_usage[city])
        evening_preference = {"couple": "cinema", "family": "cinema", "friends": "arcade", "solo": "arts centre"}.get(str(travel_type or "").casefold())
        late_activity = take(data.get("evening", []), city_usage[city], prefer=evening_preference)
        if not late_activity:
            late_activity = take(data.get("sights", []), city_usage[city], prefer="park")
        morning = []
        if day_trip:
            morning.append({"text": "Start early and confirm current Bengaluru–Mysuru transport and journey time before setting out."})
        morning.append({"action": "Breakfast at", "place": breakfast} if breakfast else {"text": f"No named cafe is mapped in {city}; choose a breakfast stop near your route."})
        morning.append({"action": "Then visit", "place": museum or other_sight} if museum or other_sight else {"text": f"No named sights are currently mapped in {city}."})
        afternoon = [
            {"action": "Lunch at", "place": lunch} if lunch else {"text": f"No named restaurant is mapped for lunch in {city}."},
            {"action": "Explore", "place": shop or take(data.get("sights", []), city_usage[city])} if shop or data.get("sights") else {"text": "No second named stop was found."},
        ]
        evening = [
            {"action": "Dinner at", "place": dinner} if dinner else {"text": f"No named dinner venue is mapped in {city}."},
            {"action": "Then try", "place": late_activity} if late_activity else {"text": "No named game or evening venue is mapped; keep the evening flexible."},
        ]
        plan.append({"day": day, "location": city, "day_trip": day_trip, "morning": morning, "afternoon": afternoon, "evening": evening})
    return plan


classification = result.get("preference_classification") or {}
selected_travel_type = str(request_data.get("travel_type") or classification.get("travel_type") or "").casefold()
named_itinerary = _named_plan(named_data or {}, int(days), interests, selected_travel_type)

top1, top2 = st.columns([1, 5], vertical_alignment="center")
with top1:
    if st.button("← Home"):
        st.switch_page("app_pages/home.py")
with top2:
    st.caption("TRAVELGENIE  /  YOUR ITINERARY")

st.markdown(f'<div class="trip-hero"><div class="eyebrow">Your next adventure</div><h1>{html.escape(destination)}</h1><p>A {days}-day route with named cafes, sights, places to eat, and map links.</p></div>', unsafe_allow_html=True)
st.write("")
cols = st.columns(4)
for col, label, value, tone in zip(cols, ("Trip length", "Travelers", "Trip budget", "Interests"), (f"{days} days", str(travelers), budget_text, ", ".join(interests) or "Explore at your pace"), ("blue", "teal", "coral", "violet")):
    col.markdown(f'<div class="stat stat-{tone}"><div class="stat-label">{label}</div><div class="stat-value">{html.escape(value)}</div></div>', unsafe_allow_html=True)

classification = result.get("preference_classification") or {}
if classification:
    # Show the traveler-entered values as the source of truth. A rating-dataset
    # classification must not replace a supplied budget with "unknown".
    entered_interests = request_data.get("interests") or classification.get("interests", [])
    interest_text = ", ".join(str(value) for value in entered_interests) or "No interests selected"
    relationship = str(classification.get("travel_type") or "").strip()
    if relationship.casefold() in {"group (relationship unspecified)", "solo or unspecified", "unspecified", "none"}:
        group_label = f"{travelers} traveler(s) · relationship unspecified"
    else:
        group_label = f"{relationship} · {travelers} traveler(s)"
    pace_label = str(classification.get("pace") or "balanced").title()
    budget_value = request_data.get("budget", result.get("budget"))
    if isinstance(budget_value, (int, float)) and budget_value > 0:
        budget_label = f"₹{budget_value:,.0f} total"
    else:
        budget_label = "Not provided"
    st.markdown(
        f'<div style="margin:12px 0 20px;padding:13px 17px;border-radius:15px;background:linear-gradient(100deg,#d9ecff,#d8f5eb,#fff0df);color:#173c5c">'
        f'<b>Your trip:</b> {html.escape(group_label)} · '
        f'{html.escape(pace_label)} pace · '
        f'{html.escape(budget_label)} budget · '
        f'{html.escape(interest_text)}</div>', unsafe_allow_html=True,
    )

st.markdown("## ✨ Your day-by-day plan")
st.caption("Each named stop links to its map listing. Confirm opening hours, travel time, and current availability before you go.")
if not named_itinerary:
    st.warning(st.session_state.get("named_trip_places_error") or "No named mapped places were found for this destination, so I can’t make a place-specific schedule yet.")
    if st.button("Try finding named places again", key="retry_named_places"):
        st.session_state.pop("named_trip_places", None)
        st.session_state.pop("named_trip_places_key", None)
        st.rerun()
for item in named_itinerary:
    day = item.get("day", "")
    cards = []
    for label, icon, tint in (("Morning", "🌅", "morning"), ("Afternoon", "🌿", "afternoon"), ("Evening", "🌙", "evening")):
        entries = item.get(label.lower(), [])
        stop_html = []
        for entry in entries:
            place = entry.get("place")
            if place:
                name = html.escape(str(place.get("name", "Mapped place")))
                map_url = html.escape(str(place.get("maps_url", "")), quote=True)
                detail_parts = [str(place.get("category") or "Place")]
                if place.get("cuisine"):
                    detail_parts.append(str(place["cuisine"]).replace(";", ", "))
                if place.get("stars"):
                    detail_parts.append(f"{place['stars']} stars listed")
                if place.get("price_range"):
                    detail_parts.append(str(place["price_range"]))
                details = html.escape(" · ".join(detail_parts))
                stop_html.append(f'<div class="stop"><span class="stop-action">{html.escape(str(entry.get("action", "Visit")))}</span><a href="{map_url}" target="_blank" rel="noopener">{name} ↗</a><span class="stop-detail">{details}</span></div>')
            elif entry.get("text"):
                stop_html.append(f'<div class="stop-note">{html.escape(str(entry["text"]))}</div>')
        if not stop_html:
            stop_html = ['<div class="stop-note">No mapped named stop was returned for this time.</div>']
        cards.append(f'<div class="slot {tint}"><b>{icon} {label}</b>{"".join(stop_html)}</div>')
    location_label = "Mysuru day trip" if item.get("day_trip") else item.get("location", destination)
    st.markdown(f'<div class="day-card"><div class="day-title">☀️ Day {day} <span style="font:600 14px DM Sans,sans-serif;color:#397096">· {html.escape(str(location_label))}</span></div><div class="day-grid">{"".join(cards)}</div></div>', unsafe_allow_html=True)

if result.get("budget_assessment"):
    st.info("💰 " + result["budget_assessment"])

st.markdown("## 🏨 Find stays and food nearby")
st.caption("Place information loads only when requested, so creating your itinerary stays quick.")
place_data = None
if st.button("Show nearby stays & food", type="primary", icon=":material/travel_explore:", key="load_places"):
    try:
        with st.spinner("Looking up nearby options…"):
            response = requests.post(
                st.session_state.api_url + "/api/travel/places",
                json={"destination": destination, "multi_stop": bool(request_data.get("multi_stop", False))},
                timeout=35,
            )
            response.raise_for_status()
            place_data = response.json()
        if place_data.get("source") == "OpenStreetMap":
            st.session_state.osm_place_results = place_data
        else:
            # Google Places content must not be cached beyond this session interaction.
            pass
    except (requests.RequestException, ValueError) as exc:
        st.error(f"Nearby place search is unavailable right now: {exc}")

place_data = place_data or st.session_state.get("osm_place_results")
if place_data:
    st.caption(place_data.get("notice", ""))
    for section_name, label in (("stays", "Places to stay"), ("food", "Food & cafes")):
        entries = place_data.get(section_name, [])
        st.markdown(f"### {label}")
        if not entries:
            st.write("No matching places were returned.")
            continue
        grid = st.columns(3)
        for i, place in enumerate(entries[:9]):
            name = html.escape(str(place.get("name", "Local option")))
            address = html.escape(str(place.get("address", "")))
            rating = place.get("rating")
            rating_line = f"⭐ {rating}" if rating else "Rating not available from this free source"
            image = place.get("photo_url") or place.get("image_url")
            link = place.get("maps_url") or place.get("map_url") or place.get("google_maps_url")
            safe_link = html.escape(str(link), quote=True) if link else ""
            card = '<div class="place">'
            if image:
                card += f'<img src="{html.escape(str(image), quote=True)}" alt="">'
            card += f'<div class="place-body"><div class="place-name">{name}</div><div class="place-meta">⭐ {html.escape(str(rating_line))}<br>{address}</div>'
            if place.get("rating_count"):
                try:
                    rating_count = int(place["rating_count"])
                except (TypeError, ValueError):
                    rating_count = 0
                if rating_count:
                    card += f'<div class="place-meta">{rating_count:,} Google ratings</div>'
            if place.get("category") or place.get("cuisine"):
                card += f'<span class="badge">{html.escape(str(place.get("category") or place.get("cuisine")))}</span>'
            place_details = []
            if place.get("stars"):
                place_details.append(f"{place['stars']} stars (listing detail)")
            if place.get("price_range") or place.get("price_level"):
                place_details.append(str(place.get("price_range") or place.get("price_level")))
            if place_details:
                card += f'<div class="place-meta">{html.escape(" · ".join(place_details))}</div>'
            photo_credits = place.get("photo_attributions") or []
            if photo_credits:
                names = ", ".join(str(item.get("displayName", "")) for item in photo_credits if isinstance(item, dict) and item.get("displayName"))
                if names:
                    card += f'<div class="place-meta">Photo: {html.escape(names)}</div>'
            if safe_link:
                card += f'<p><a href="{safe_link}" target="_blank" rel="noopener">Open map ↗</a></p>'
            card += '</div></div>'
            grid[i % 3].markdown(card, unsafe_allow_html=True)
    if place_data.get("attribution"):
        st.caption(place_data["attribution"])

with st.expander("How this plan was created"):
    st.write(result.get("explanation", "This flexible draft uses the destination and preferences you entered."))
    st.caption(f"Planner: {result.get('provider', 'TravelGenie')}")
    st.info("The supplied ratings file has anonymous, unlabeled category scores. It cannot tell us whether travelers rated these destinations, attractions, or interests, so those scores are not shown or used as place ratings.")
    judge = result.get("llm_judge_validation")
    if judge:
        if judge.get("status") == "evaluated":
            st.success(f"LLM judge: {judge.get('score', 0):.2f}/1 · {'Passed' if judge.get('passed') else 'Needs review'}")
            st.write(judge.get("reason", ""))
            for issue in judge.get("issues", []):
                st.write("• " + str(issue))
        else:
            st.caption("LLM judge status: " + str(judge.get("reason", judge.get("status"))))

st.divider()
st.markdown("### Was this itinerary useful?")
feedback_cols = st.columns([1, 3, 1])
with feedback_cols[0]:
    feedback_rating = st.selectbox("Rating", [5, 4, 3, 2, 1], key="feedback_rating")
with feedback_cols[1]:
    feedback_comment = st.text_input("Comment (optional)", key="feedback_comment")
with feedback_cols[2]:
    st.write("")
    if st.button("Send feedback", key="send_feedback"):
        try:
            requests.post(st.session_state.api_url + "/api/travel/feedback", json={"user_query": request_data.get("query", f"Trip to {destination}"), "rating": feedback_rating, "comment": feedback_comment}, timeout=10).raise_for_status()
            st.success("Thanks for helping improve TravelGenie!")
        except requests.RequestException:
            st.error("Feedback could not be sent right now.")
