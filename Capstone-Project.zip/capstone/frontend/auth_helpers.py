"""Server-side identity and role checks for protected Streamlit pages."""
import streamlit as st

from src.auth_store import get_user


def require_user() -> dict:
    user_id = st.session_state.get("auth_user_id")
    user = get_user(user_id) if user_id else None
    if not user:
        st.error("Sign in with a verified account to view this page.")
        st.stop()
    return user


def require_admin() -> dict:
    user = require_user()
    if user["role"] != "admin":
        st.error("This page is restricted to configured administrators.")
        st.stop()
    return user
