from pathlib import Path
from reportlab.lib import colors
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "architecture" / "Architecture_Diagram.pdf"
W, H = 1400, 1000

NAVY = colors.HexColor("#102B46")
BLUE = colors.HexColor("#1769AA")
CYAN = colors.HexColor("#16A6B6")
TEAL = colors.HexColor("#16806E")
ORANGE = colors.HexColor("#E88632")
INK = colors.HexColor("#243647")
MUTED = colors.HexColor("#5B6F82")
PANEL = colors.HexColor("#F1F6FA")
LINE = colors.HexColor("#A9BAC8")
WHITE = colors.white


def wrap(text, font, size, width):
    words = text.split()
    lines, current = [], ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if stringWidth(candidate, font, size) <= width:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def card(pdf, x, y, w, h, title, names, detail, accent=BLUE):
    pdf.setFillColor(WHITE)
    pdf.setStrokeColor(colors.HexColor("#D4E0E8"))
    pdf.setLineWidth(1)
    pdf.roundRect(x, y, w, h, 12, fill=1, stroke=1)
    pdf.setFillColor(accent)
    pdf.roundRect(x, y + h - 30, w, 30, 12, fill=1, stroke=0)
    pdf.rect(x, y + h - 30, w, 12, fill=1, stroke=0)
    pdf.setFillColor(WHITE)
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(x + 13, y + h - 20, title)

    cursor = y + h - 48
    pdf.setFillColor(NAVY)
    pdf.setFont("Courier-Bold", 9)
    for name in names:
        for line in wrap(name, "Courier-Bold", 9, w - 26):
            pdf.drawString(x + 13, cursor, line)
            cursor -= 12
    cursor -= 2
    pdf.setFillColor(MUTED)
    pdf.setFont("Helvetica", 9)
    for line in wrap(detail, "Helvetica", 9, w - 26):
        if cursor < y + 10:
            break
        pdf.drawString(x + 13, cursor, line)
        cursor -= 12


def arrow(pdf, x1, y1, x2, y2, label=None, label_offset=(0, 7), color=LINE):
    pdf.setStrokeColor(color)
    pdf.setFillColor(color)
    pdf.setLineWidth(2)
    pdf.line(x1, y1, x2, y2)
    if abs(x2 - x1) >= abs(y2 - y1):
        direction = 1 if x2 >= x1 else -1
        path = pdf.beginPath()
        path.moveTo(x2, y2)
        path.lineTo(x2 - direction * 9, y2 + 5)
        path.lineTo(x2 - direction * 9, y2 - 5)
        path.close()
        pdf.drawPath(path, fill=1, stroke=0)
    else:
        direction = 1 if y2 >= y1 else -1
        path = pdf.beginPath()
        path.moveTo(x2, y2)
        path.lineTo(x2 - 5, y2 - direction * 9)
        path.lineTo(x2 + 5, y2 - direction * 9)
        path.close()
        pdf.drawPath(path, fill=1, stroke=0)
    if label:
        pdf.setFont("Helvetica", 8)
        pdf.setFillColor(MUTED)
        pdf.drawCentredString((x1 + x2) / 2 + label_offset[0],
                              (y1 + y2) / 2 + label_offset[1], label)


def elbow_arrow(pdf, points, label, color=BLUE):
    pdf.setStrokeColor(color)
    pdf.setFillColor(color)
    pdf.setLineWidth(2)
    for start, end in zip(points, points[1:]):
        pdf.line(start[0], start[1], end[0], end[1])
    x1, y1 = points[-2]
    x2, y2 = points[-1]
    if x2 >= x1:
        path = pdf.beginPath()
        path.moveTo(x2, y2)
        path.lineTo(x2 - 9, y2 + 5)
        path.lineTo(x2 - 9, y2 - 5)
        path.close()
        pdf.drawPath(path, fill=1, stroke=0)
    pdf.setFillColor(MUTED)
    pdf.setFont("Helvetica", 8)
    pdf.drawCentredString(680, 458, label)


def lane(pdf, x, y, w, h, title, accent):
    pdf.setFillColor(PANEL)
    pdf.setStrokeColor(colors.HexColor("#DFE8EF"))
    pdf.roundRect(x, y, w, h, 16, fill=1, stroke=1)
    pdf.setFillColor(accent)
    pdf.setFont("Helvetica-Bold", 13)
    pdf.drawString(x + 15, y + h - 23, title)


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    pdf = canvas.Canvas(str(OUT), pagesize=(W, H), pageCompression=1)
    pdf.setTitle("TravelGenie AI Architecture with Class Names")
    pdf.setAuthor("TravelGenie AI project")
    pdf.setFillColor(colors.HexColor("#F8FBFD"))
    pdf.rect(0, 0, W, H, fill=1, stroke=0)

    pdf.setFillColor(NAVY)
    pdf.setFont("Helvetica-Bold", 25)
    pdf.drawString(42, 954, "TravelGenie AI | Architecture and Class Map")
    pdf.setFillColor(MUTED)
    pdf.setFont("Helvetica", 11)
    pdf.drawString(43, 931, "Implemented request flow, major classes, modules, data stores, and optional providers")

    top_y, top_h = 485, 420
    xs = [35, 380, 725, 1070]
    lane_w = 295
    lane(pdf, xs[0], top_y, lane_w, top_h, "1  User interface", BLUE)
    lane(pdf, xs[1], top_y, lane_w, top_h, "2  HTTP API", CYAN)
    lane(pdf, xs[2], top_y, lane_w, top_h, "3  Recommendation and planning", TEAL)
    lane(pdf, xs[3], top_y, lane_w, top_h, "4  Retrieval and rating evidence", ORANGE)

    card(pdf, 50, 720, 265, 125, "Streamlit pages",
         ["frontend.app_pages.home", "frontend.app_pages.itinerary", "frontend.app_pages.chat"],
         "Discovery, itinerary setup and display, chat history, voice input, and map cards.", BLUE)
    card(pdf, 50, 555, 265, 115, "Account and admin UI",
         ["frontend.auth_ui.render_auth_gate()", "frontend.app_pages.admin"],
         "Email-confirmed sign-in and account-scoped chat access.", BLUE)

    card(pdf, 395, 710, 265, 135, "Route request models",
         ["PlanRequest", "SearchRequest", "FeedbackRequest", "PlacesRequest", "AttractionsRequest", "TripPlacesRequest"],
         "Defined in src.api.routes.travel; Pydantic validates API inputs.", CYAN)
    card(pdf, 395, 535, 265, 135, "FastAPI application",
         ["src.main.search()", "src.main.itinerary()", "src.main.feedback()", "TravelPlanResponse", "SearchResponse"],
         "Routes call recommendation, planning, feedback, and response-schema logic.", CYAN)

    card(pdf, 740, 735, 265, 110, "Discovery and category mapping",
         ["recommend_from_query()", "requested_categories()", "matched_interests()"],
         "Modules: src.travel_recommendations and src.travel_intent. Maps text to documented UCI categories.", TEAL)
    card(pdf, 740, 570, 265, 130, "Planning models and rules",
         ["TravelRequest", "classify_preferences()", "guard_input()", "deterministic_plan()"],
         "Defined in src.planner; validates trip inputs and creates the offline plan.", TEAL)
    card(pdf, 740, 495, 265, 75, "LangGraph workflow",
         ["PlanState | build_graph() | execute()"],
         "Query understanding, classify, retrieve, plan, and critic.", TEAL)

    card(pdf, 1085, 730, 265, 115, "Hybrid profile retrieval",
         ["src.retrieval.retrieve()", "src.rag.reranker.rerank()"],
         "Combines BM25 keyword search with dense retrieval and reciprocal-rank fusion; reranking is optional.", ORANGE)
    card(pdf, 1085, 565, 265, 135, "Vector store and embeddings",
         ["vector_store.build() / query()", "EmbeddingProvider", "LocalEmbeddingProvider", "OllamaEmbeddingProvider", "GeminiEmbeddingProvider"],
         "ChromaDB stores profile vectors. The provider classes are in src.rag.embeddings.", ORANGE)
    card(pdf, 1085, 490, 265, 70, "Evidence output",
         ["category averages + profile matches"],
         "Scores describe categories, not cities.", ORANGE)

    arrow(pdf, 315, 782, 395, 782, "HTTP request")
    arrow(pdf, 660, 775, 740, 790, "search")
    arrow(pdf, 660, 600, 740, 640, "itinerary")
    arrow(pdf, 1005, 790, 1085, 790, "retrieve")
    arrow(pdf, 1005, 640, 1085, 640, "profile evidence")
    arrow(pdf, 1085, 525, 1005, 535, "results", label_offset=(0, -16), color=TEAL)

    # Supporting systems and their relationships to the main flow.
    support_y, support_h = 175, 235
    support = [
        (35, 310, "Data preparation and profiles", BLUE,
         ["load_and_clean()", "create_profiles()", "read_profiles()"],
         "src.data_pipeline reads data/raw/google_review_ratings.csv and creates traveler profile JSONL. The source has 5,456 profiles × 24 category ratings."),
        (365, 310, "Optional reviewed trip corpus", CYAN,
         ["import_csv()", "search_experiences()"],
         "src.import_experiences and src.experience_retrieval. Destination and budget filters work only after real reviewed records are imported."),
        (695, 330, "Live place services", TEAL,
         ["OSMPlacesError", "search_osm_stays_and_food()", "search_osm_attractions()", "GooglePlacesError", "search_stays_and_food()"],
         "src.services.osm_places_service is the no-key default. Google Places is optional and requires a valid configured API key."),
        (1045, 305, "Persistence and feedback", ORANGE,
         ["AuthError", "register_user()", "login_user()", "verify_email()", "get_user()"],
         "src.auth_store stores accounts and conversations in SQLite. Feedback and operational summaries are separate API paths."),
    ]
    for x, width, title, accent, names, detail in support:
        card(pdf, x, support_y, width, support_h, title, names, detail, accent)

    elbow_arrow(pdf, [(200, 410), (200, 455), (1055, 455), (1055, 630), (1085, 630)],
                "cleaned traveler profiles to indexed vectors")

    pdf.setStrokeColor(colors.HexColor("#CFDBE4"))
    pdf.line(35, 105, 1365, 105)
    pdf.setFillColor(MUTED)
    pdf.setFont("Helvetica-Bold", 9)
    pdf.drawString(42, 82, "IMPORTANT DATA BOUNDARY")
    pdf.setFont("Helvetica", 9)
    pdf.drawString(180, 82,
                   "The ratings CSV has category averages only. It has no city ratings, trip narratives, venue names, or prices.")
    pdf.setFont("Helvetica", 8)
    pdf.drawString(42, 55,
                   "Recommendation evidence comes from similar category-rating profiles. Destination ideas use a curated catalog; live place listings come from a separate map service.")
    pdf.drawRightString(1360, 30, "TravelGenie AI | Implemented architecture | 10 October 2026")
    pdf.save()
    print(OUT)


if __name__ == "__main__":
    main()
