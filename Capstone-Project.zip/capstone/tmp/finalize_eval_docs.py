from pathlib import Path
for name in ['docs/Evaluation_Report.md','tmp/build_project_report.py']:
 p=Path(name); s=p.read_text(encoding='utf-8').replace('70.30%', '73.45%')
 s=s.replace('68.90%, 69.70%, 69.18%, 69.48%, 72.06%, 70.32%, and 72.45%', '83.04%, 70.27%, 69.18%, 72.65%, 72.06%, 70.32%, and 76.60%')
 p.write_text(s,encoding='utf-8')
for name in ['tmp/update_report.py','tmp/sync_eval_docs.py']:
 Path(name).unlink(missing_ok=True)
