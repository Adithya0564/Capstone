from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "TravelGenie_AI_Project_Report.docx"
DIAGRAM = ROOT / "tmp" / "report_architecture.png"

NAVY = "12304A"
BLUE = "1468D4"
TEAL = "19A6A3"
ORANGE = "F28B32"
PALE = "EAF3FB"
INK = "253746"
MUTED = "607487"


def make_architecture_diagram() -> None:
    width, height = 1800, 610
    im = Image.new("RGB", (width, height), "#f5f8fb")
    d = ImageDraw.Draw(im)
    font_path = Path(r"C:\Windows\Fonts\segoeui.ttf")
    bold_path = Path(r"C:\Windows\Fonts\segoeuib.ttf")
    try:
        title = ImageFont.truetype(bold_path, 40)
        label = ImageFont.truetype(bold_path, 24)
        body = ImageFont.truetype(font_path, 19)
        small = ImageFont.truetype(font_path, 17)
    except OSError:
        title = label = body = small = ImageFont.load_default()

    d.text((56, 28), "TravelGenie AI system flow", fill=f"#{NAVY}", font=title)
    d.text((58, 82), "Offline profile preparation and online recommendation path", fill=f"#{MUTED}", font=body)

    prep = [
        (70, "Rating CSV", "5,456 profiles\n24 UCI categories", BLUE),
        (430, "Data pipeline", "Clean values\nBuild profiles", TEAL),
        (790, "Local index", "Sentence vectors\nChromaDB", ORANGE),
    ]
    run = [
        (70, "Traveler query", "Natural language\ninterests and trip", BLUE),
        (430, "Intent mapping", "Map interests to\ndocumented categories", TEAL),
        (790, "Hybrid retrieval", "BM25 + dense search\nRRF + profile scoring", ORANGE),
        (1150, "Evidence and ideas", "Similar profiles\nratings + curated tags", TEAL),
        (1510, "Application", "FastAPI + Streamlit\ntrip tools and chat", BLUE),
    ]

    def box(x, y, heading, lines, color):
        w, h = 285, 130
        d.rounded_rectangle((x, y, x + w, y + h), radius=21, fill="white", outline=f"#{color}", width=3)
        d.rounded_rectangle((x, y, x + w, y + 12), radius=7, fill=f"#{color}")
        d.text((x + 18, y + 28), heading, fill=f"#{NAVY}", font=label)
        for i, line in enumerate(lines.splitlines()):
            d.text((x + 18, y + 69 + 25 * i), line, fill=f"#{INK}", font=small)
        return x + w

    def arrow(x1, y, x2):
        d.line((x1 + 12, y, x2 - 12, y), fill=f"#{MUTED}", width=5)
        d.polygon([(x2 - 12, y), (x2 - 28, y - 10), (x2 - 28, y + 10)], fill=f"#{MUTED}")

    d.text((60, 145), "PROFILE PREPARATION", fill=f"#{BLUE}", font=small)
    for i, (x, head, lines, color) in enumerate(prep):
        right = box(x, 178, head, lines, color)
        if i < len(prep) - 1:
            arrow(right, 243, prep[i + 1][0])

    d.text((60, 340), "QUERY AND RESPONSE", fill=f"#{BLUE}", font=small)
    for i, (x, head, lines, color) in enumerate(run):
        right = box(x, 374, head, lines, color)
        if i < len(run) - 1:
            arrow(right, 439, run[i + 1][0])

    d.line((932, 308, 932, 350), fill=f"#{ORANGE}", width=4)
    d.polygon([(932, 350), (922, 334), (942, 334)], fill=f"#{ORANGE}")
    d.text((958, 316), "Profiles and embeddings", fill=f"#{MUTED}", font=small)
    d.text((72, 542), "Destination ideas use curated interest tags. Dataset ratings are category-level evidence, never destination ratings.", fill=f"#{MUTED}", font=small)
    im.save(DIAGRAM, quality=95)


def shade(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_margins(cell, top=105, start=125, bottom=105, end=125) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    margins = tc_pr.first_child_found_in("w:tcMar")
    if margins is None:
        margins = OxmlElement("w:tcMar")
        tc_pr.append(margins)
    for side, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = margins.find(qn(f"w:{side}"))
        if node is None:
            node = OxmlElement(f"w:{side}")
            margins.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def format_table(table, widths=None) -> None:
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for ri, row in enumerate(table.rows):
        if ri == 0:
            set_repeat_table_header(row)
        for ci, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            if ri == 0:
                shade(cell, NAVY)
            elif ri % 2 == 0:
                shade(cell, "F2F6FA")
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(2)
                p.paragraph_format.space_before = Pt(1)
                for run in p.runs:
                    run.font.name = "Aptos"
                    run.font.size = Pt(9.2)
                    if ri == 0:
                        run.bold = True
                        run.font.color.rgb = RGBColor(255, 255, 255)
                    else:
                        run.font.color.rgb = RGBColor.from_string(INK)
            if widths and ci < len(widths):
                cell.width = Inches(widths[ci])


def add_table(doc, headers, rows, widths=None):
    table = doc.add_table(rows=1, cols=len(headers))
    for cell, text in zip(table.rows[0].cells, headers):
        cell.text = text
    for row in rows:
        cells = table.add_row().cells
        for cell, text in zip(cells, row):
            cell.text = str(text)
    format_table(table, widths)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def add_bullets(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        p.paragraph_format.space_after = Pt(4)
        p.add_run(item)


def add_numbered(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Number")
        p.paragraph_format.space_after = Pt(4)
        p.add_run(item)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("TravelGenie AI  |  Page ")
    run.font.name = "Aptos"
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor.from_string(MUTED)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    paragraph._p.append(field)


def build_report() -> None:
    make_architecture_diagram()
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(.72)
    section.bottom_margin = Inches(.68)
    section.left_margin = Inches(.78)
    section.right_margin = Inches(.78)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Aptos"
    normal.font.size = Pt(10.4)
    normal.font.color.rgb = RGBColor.from_string(INK)
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.line_spacing = 1.11
    for name, size, color in (("Heading 1", 19, NAVY), ("Heading 2", 13, BLUE), ("Heading 3", 11, TEAL)):
        style = styles[name]
        style.font.name = "Aptos Display"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(15 if name == "Heading 1" else 9)
        style.paragraph_format.space_after = Pt(5)
    header = section.header.paragraphs[0]
    header.text = "TRAVELGENIE AI  /  PROJECT REPORT"
    header.runs[0].font.name = "Aptos"
    header.runs[0].font.size = Pt(8)
    header.runs[0].font.bold = True
    header.runs[0].font.color.rgb = RGBColor.from_string(BLUE)
    add_page_number(section.footer.paragraphs[0])

    p = doc.add_paragraph(style="Title")
    p.paragraph_format.space_before = Pt(110)
    p.paragraph_format.space_after = Pt(9)
    run = p.add_run("TravelGenie AI Project Report")
    run.font.name = "Aptos Display"
    run.font.size = Pt(34)
    run.font.bold = True
    run.font.color.rgb = RGBColor.from_string(NAVY)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(17)
    run = p.add_run("AI Powered Travel Interest Retrieval and Personalized Trip Planning")
    run.font.name = "Aptos Display"
    run.font.size = Pt(17)
    run.font.color.rgb = RGBColor.from_string(BLUE)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    r = p.add_run("Prepared from the current project source and recorded evaluation artifacts")
    r.font.size = Pt(11)
    r.font.color.rgb = RGBColor.from_string(MUTED)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(205)
    r = p.add_run("October 2026\nTravel planning capstone")
    r.font.size = Pt(11)
    r.font.color.rgb = RGBColor.from_string(MUTED)
    doc.add_page_break()

    doc.add_heading("Executive Summary", level=1)
    doc.add_paragraph(
        "TravelGenie AI is a local travel recommendation application that turns a natural language request into similar-traveler preference evidence and destination ideas. It addresses a data constraint directly: the supplied UCI Travel Review Ratings file contains category-level rating profiles, not written trip reviews or destination-level scores. The system therefore reports what similar profiles rated in categories such as beaches, museums, restaurants, and hotels, then presents destinations as curated interest matches."
    )
    doc.add_paragraph(
        "The core search path combines BM25 keyword ranking with dense profile retrieval, reciprocal rank fusion, query and preference scoring, and an optional cross-encoder on slower paths. FastAPI exposes the recommendation and planning services. Streamlit provides the user experience, including destination discovery, trip setup, a named-place itinerary view, budget-aware place selection, travel chat, voice input, account history, and an administrator overview. OpenStreetMap is the no-key source for named places and map links; Google Places can be enabled for ratings and photos when the API key and billing permissions are valid."
    )
    doc.add_paragraph(
        "The current deterministic DeepEval RequirementChecklist reports 100% across seven project-authored cases (52 explicit checks). RAGAS SemanticSimilarity reports 73.45% across the same seven cases, using the actual answer and destination ideas against authored references. These are diagnostics, not an overall grade or evidence of traveler satisfaction. LLM-judged GEval and RAGAS metrics have not completed within local time limits."
    )
    add_table(doc, ["Project area", "Current implementation"], [
        ("Primary task", "Natural language travel-interest search and similar rating-profile retrieval"),
        ("Dataset", "5,456 traveler profiles with 24 documented category-rating dimensions"),
        ("Core retrieval", "BM25 plus dense vectors, reciprocal rank fusion, category preference scoring"),
        ("User interface and API", "Streamlit frontend with FastAPI service"),
        ("Recorded diagnostics", "100% checklist and 73.45% RAGAS SemanticSimilarity across seven authored cases"),
    ], [1.5, 5.2])

    doc.add_heading("1 Project Purpose and Requirements", level=1)
    doc.add_paragraph(
        "Travel professionals receive repeated requests that combine interests, travel group, budget, and destination choices. Manually comparing historical ratings can be slow. The project builds a retrieval system that accepts a natural language request, finds similar traveler rating profiles, and summarizes relevant preference evidence."
    )
    doc.add_heading("Core requirements", level=2)
    add_bullets(doc, [
        "Support natural language queries about travel interests and retrieve relevant rating profiles.",
        "Combine lexical matching with semantic retrieval and rank the candidates by preference fit.",
        "Filter profiles using supported rating metadata and return understandable evidence.",
        "Suggest destinations and activities while separating curated destination ideas from dataset ratings.",
        "Expose functionality through API endpoints and a local user interface.",
        "Validate input, report data limits, capture feedback, and provide diagnostic evaluation artifacts.",
    ])
    doc.add_heading("Project boundary", level=2)
    doc.add_paragraph(
        "The project is a recommendation and decision-support prototype. It is not a booking system, a live price comparison service, or a destination-rating model. It does not infer that a profile visited a city or completed a specific itinerary."
    )

    doc.add_heading("2 User Journey", level=1)
    add_numbered(doc, [
        "A traveler enters an open-ended request, such as a five-day trip focused on beaches, sightseeing, and local food. Optional browser speech recognition can turn spoken input into the same query text.",
        "The application maps recognizable interests to UCI category labels, parses stated trip duration for context, and retrieves similar traveler profiles.",
        "The results show category-level averages observed among the retrieved profiles. Destination suggestions are ranked using curated interest tags and matching category evidence; they are not destination ratings.",
        "After a traveler selects a destination, the setup dialog collects duration, budget, group size, relationship type, and interests.",
        "The itinerary view assembles named cafes, sights, food, shopping, and evening stops from map listings when available. Stops include map links. For a multi-day Bengaluru trip, the current itinerary logic may place a Mysuru day trip on day two.",
        "The traveler can request nearby stays and food, use travel chat and saved conversations, and submit explicit itinerary feedback.",
    ])

    doc.add_heading("3 Dataset and Preparation", level=1)
    doc.add_paragraph(
        "The application uses the UCI Travel Review Ratings dataset, UCI repository dataset 485, identified in the project as the Google Review Ratings CSV. The local file is `data/raw/google_review_ratings.csv`. It contains 5,456 user profiles and 24 category-level average ratings on the UCI 1–5 scale. The CSV has 26 raw columns, including the user identifier and two unassigned values in an unnamed column."
    )
    add_table(doc, ["Preparation step", "Behavior"], [
        ("Schema detection", "Identify the user key and Category 1 through Category 24 columns."),
        ("Numeric cleaning", "Normalize rating strings and convert values outside the documented 1–5 range to missing."),
        ("Missing values", "Keep unrated categories missing; do not replace them with a zero rating."),
        ("Unassigned column", "Remove the unnamed column containing two unassigned values."),
        ("Duplicate handling", "Keep the first row for a duplicate user ID; the supplied file reports zero duplicate user rows removed."),
        ("Profile features", "Create rating vectors, means, medians, top and low categories, distributions, and preference strength."),
    ], [1.45, 5.25])
    doc.add_heading("Documented rating categories", level=2)
    categories = [
        ("1", "Churches"), ("2", "Resorts"), ("3", "Beaches"), ("4", "Parks"),
        ("5", "Theatres"), ("6", "Museums"), ("7", "Malls"), ("8", "Zoos"),
        ("9", "Restaurants"), ("10", "Pubs and bars"), ("11", "Local services"),
        ("12", "Burger and pizza shops"), ("13", "Hotels and other lodgings"),
        ("14", "Juice bars"), ("15", "Art galleries"), ("16", "Dance clubs"),
        ("17", "Swimming pools"), ("18", "Gyms"), ("19", "Bakeries"),
        ("20", "Beauty and spas"), ("21", "Cafes"), ("22", "Viewpoints"),
        ("23", "Monuments"), ("24", "Gardens"),
    ]
    add_table(doc, ["Category", "Place type", "Category", "Place type"], [
        (categories[i][0], categories[i][1], categories[i + 12][0], categories[i + 12][1]) for i in range(12)
    ], [.8, 2.45, .8, 2.45])
    doc.add_paragraph(
        "The data does not contain review text, city names, named attractions, dates, trip duration, traveler relationships, or prices. As a result, profile averages support preference matching only. The optional destination-linked experience corpus is a separate schema and is empty until reviewed trip records are imported."
    )

    doc.add_heading("4 Architecture and Data Flow", level=1)
    doc.add_paragraph(
        "Offline preparation converts the CSV into cleaned profiles and a persistent vector index. At request time, the service maps interests, retrieves profiles, summarizes category evidence, ranks curated destination ideas, and returns a structured response to the Streamlit interface. The planning workflow is a separate path that validates trip details and builds an itinerary after the destination is supplied."
    )
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(DIAGRAM), width=Inches(6.75))
    cap = doc.add_paragraph("Figure 1. Profile preparation and runtime recommendation flow.")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.runs[0].italic = True
    cap.runs[0].font.size = Pt(9)
    cap.runs[0].font.color.rgb = RGBColor.from_string(MUTED)
    add_table(doc, ["Layer", "Main responsibility"], [
        ("Data pipeline", "Clean CSV values and create profile features and statistics."),
        ("Embedding index", "Persist profile vectors locally with ChromaDB and configured embeddings."),
        ("Intent mapping", "Map explicit natural-language interests to documented category IDs."),
        ("Hybrid retrieval", "Combine BM25 lexical ranking and dense profile ranking with RRF and preference scoring."),
        ("Recommendation service", "Return profile evidence, category summaries, curated destination ideas, and data-scope notes."),
        ("Planning service", "Validate duration and trip details; create a deterministic offline itinerary by default."),
        ("Places service", "Look up named map listings through OpenStreetMap by default, or optional Google Places."),
        ("Presentation layer", "Render search, itinerary, chat, account, and administration views in Streamlit."),
    ], [1.5, 5.2])

    doc.add_heading("5 Retrieval and Recommendation Method", level=1)
    doc.add_paragraph(
        "Each traveler profile is represented by a document containing its category ratings and summary features. The query is tokenized and matched against profile documents with BM25. When the local vector index is available and the request is not in fast mode, semantic retrieval supplies a second ranked list. Reciprocal rank fusion combines their ranks. Interest-to-category matches then contribute preference evidence to the final ranking."
    )
    add_bullets(doc, [
        "In the standard hybrid score, retrieval uses an RRF component, dense score, query token coverage, and requested-category preference fit.",
        "The optional cross-encoder reranker applies to slower retrieval paths; the primary fast interest-search route skips it to reduce first-search latency.",
        "When reranking is enabled, the final score blends the cross-encoder score, base hybrid score, and category preference fit.",
        "Category means are computed from the retrieved profiles that have a recorded value. Missing values remain missing, and the response includes the number of profiles contributing to an average.",
        "An explicit query for comparing destinations is answered with a limitation notice because no destination IDs exist in the dataset.",
    ])
    doc.add_heading("Destination ranking", level=2)
    doc.add_paragraph(
        "The starter destination catalog contains Goa, Bali, Kyoto, and Dubai with curated interest tags. Suggestions are ordered by the matching category evidence available for the query and by the count of matched interests. The interface labels the ratings as similar-traveler category averages and the destination ordering as a curated match. The system does not claim that Goa, Bali, Kyoto, or Dubai received those ratings."
    )
    doc.add_heading("Separate experience search", level=2)
    doc.add_paragraph(
        "The project also includes a corpus adapter for destination-linked travel records. It supports BM25 and configured embedding ranking, with destination, travel type, minimum rating, and maximum budget filters. It requires a reviewed experience corpus to return historical trip matches. That corpus is distinct from the supplied category-rating dataset and is not populated with invented records."
    )

    doc.add_heading("6 Itinerary and Place Features", level=1)
    doc.add_paragraph(
        "The main experience is preference retrieval and destination discovery. A deterministic itinerary path runs locally by default. It uses the destination and trip parameters entered by the traveler and validates the requested day count. Hosted LLM itinerary generation is optional and disabled in the fast default configuration. The planner explicitly marks budget feasibility as unknown because it has no structured transport, lodging, meal, or activity prices."
    )
    add_table(doc, ["Place mode", "Data returned", "Limit"], [
        ("OpenStreetMap default", "Named stays, food, cafes, sights and map links when listings are available", "No consistent review ratings or photos; public geocoding may throttle requests."),
        ("Google Places optional", "Place ratings, photos, map links and available business fields", "Requires an enabled Places API, billing, and a restricted key; API use may incur charges."),
        ("Named itinerary", "Day sections for breakfast, sights, lunch, shopping or another stop, dinner and an evening activity", "Place coverage and current opening hours are not guaranteed; verify locally."),
    ], [1.55, 2.55, 2.6])
    doc.add_paragraph(
        "The itinerary screen can show stay and food cards on demand so an external place lookup does not delay the initial plan. OSM place cards include map links and attribution. Google fields are used only when the configured provider returns them. Price tags or accommodation classes from a listing are not the same as a verified total-trip budget estimate."
    )

    doc.add_heading("7 Technology Choices", level=1)
    add_table(doc, ["Technology", "Role in the project", "Reason for use"], [
        ("Python", "Application and data pipeline language", "Keeps data processing, retrieval, API, evaluation and UI integration in one ecosystem."),
        ("pandas and NumPy", "CSV cleaning, profile calculations and statistics", "Provide direct tools for tabular processing and numeric summaries."),
        ("FastAPI, Pydantic and Uvicorn", "HTTP API, input validation and ASGI server", "Provide typed request validation, OpenAPI docs, and a local service boundary."),
        ("Streamlit", "Web interface and multi-page navigation", "Supports rapid local UI development in Python."),
        ("BM25 and reciprocal rank fusion", "Lexical ranking and rank-list combination", "Supports exact category terms while combining multiple retrieval signals."),
        ("Sentence Transformers and ChromaDB", "Local dense embeddings and persistent vector search", "Enable semantic profile retrieval without requiring a hosted embedding account."),
        ("Cross-encoder reranker", "Optional candidate reranking", "Can improve query-candidate relevance at additional model startup and inference cost."),
        ("LangGraph", "Preference classification, profile retrieval, planning and critic workflow", "Makes planning steps explicit and keeps the pipeline modular."),
        ("OpenAI-compatible, Gemini and OpenAI provider clients", "Optional hosted model generation and judging", "Allow provider choice while keeping the deterministic offline path usable."),
        ("Ollama and DeepEval", "Local LLM judge and diagnostic evaluation", "Allows local evaluation without sending test examples to a hosted judge by default."),
        ("SQLite", "Local accounts, conversations and messages", "Provides a lightweight persistent store for the capstone deployment."),
        ("SMTP", "Confirmation and welcome emails", "Supports email verification when a provider credential is configured."),
        ("OpenStreetMap or Google Places", "Named current place lookups", "Provides map-linked place discovery separate from historical rating evidence."),
    ], [1.65, 2.25, 2.8])

    doc.add_heading("8 API Surface", level=1)
    doc.add_paragraph("The service exposes interactive OpenAPI documentation at `/docs` when the API is running. Key route groups include:")
    add_table(doc, ["Method and route", "Purpose"], [
        ("GET /health", "Report service, dataset and provider readiness."),
        ("GET /dataset/stats", "Return schema, row counts, invalid values, missingness and category statistics."),
        ("POST /recommendations/search", "Primary natural-language profile retrieval and destination ideas."),
        ("POST /itinerary", "Validate trip details and return a destination request or itinerary draft."),
        ("POST /feedback", "Append explicit user feedback to local JSONL storage."),
        ("GET /observability/summary", "Return local feedback and operational summary information."),
        ("POST /api/travel/places", "Find nearby stays and food using the configured place provider."),
        ("POST /api/travel/attractions", "Return mapped attractions ranked for couple, family, or friends."),
        ("POST /api/travel/trip-places", "Fetch named itinerary stops for one or more destinations."),
        ("POST /api/travel/search", "Search rating profiles and, when present, the separate trip-record corpus."),
        ("GET /api/travel/destinations", "List destinations found in the imported trip-record corpus."),
    ], [2.6, 4.1])

    doc.add_heading("9 Accounts, Chat and Voice", level=1)
    doc.add_paragraph(
        "Email signup creates an unverified account and sends a one-use confirmation token that expires after 24 hours. The first successful verification triggers a welcome email. Passwords are salted and hashed with PBKDF2-HMAC-SHA256 using 600,000 iterations. Repeated failed logins trigger a temporary lockout. Accounts, conversations and messages are stored locally in SQLite. Conversation queries are scoped to the signed-in user."
    )
    doc.add_paragraph(
        "The admin portal is shown only to accounts with an email in the local `ADMIN_EMAILS` configuration after verification. It presents account and aggregate usage information; the current README states it does not expose conversation message contents. Browser speech recognition supports voice input where available. Browser speech synthesis can read a recent assistant response aloud. Neither feature is guaranteed across all browsers, and the app stores the recognized text rather than audio."
    )

    doc.add_heading("10 Evaluation Results", level=1)
    doc.add_paragraph(
        "The project repository contains a seven-case diagnostic dataset covering the three rubric question types: similar experiences, destination comparison, and limited-budget choices, plus related interest searches. The expected behavior checks category mapping, similar-profile retrieval, source-scope disclosure, ranked destination ideas, and the distinction between category evidence and destination ratings. The examples were authored for this project and were not independently reviewed by a travel-domain expert."
    )
    add_table(doc, ["Metric", "Recorded result", "Threshold", "Interpretation"], [
        ("RequirementChecklist", "100% mean; 52/52 checks passed across seven cases", "90%", "Deterministic checklist of explicit requirements."),
        ("RAGAS SemanticSimilarity", "73.45% across seven cases", "Not set", "Local embedding similarity to project-authored references; not factuality or satisfaction."),
        ("AnswerRelevancy and GEval", "Not rerun / not completed", "Not scored", "Local LLM-judge calls exceeded time limits; no current score claimed."),
    ], [1.65, 1.65, .8, 2.6])
    doc.add_paragraph(
        "The 100% checklist result describes only literal checks across seven authored examples; it does not measure city-rating accuracy, traveler satisfaction, place freshness, itinerary factuality, or overall capstone quality. RAGAS SemanticSimilarity measures text-embedding similarity and does not establish factuality. These metrics measure different things and should not be averaged into an overall project score."
    )
    doc.add_heading("Recorded smoke evidence", level=2)
    add_bullets(doc, [
        "The existing evaluation report records a successful prior API search smoke check with HTTP 200, five similar profiles, category evidence, destination ideas, and Chroma embedding retrieval.",
        "The repository includes pytest cases for data processing, profiles, retrieval, guardrails, and API routes; this report does not claim a new test-suite run.",
        "The API and UI should be demonstrated together with the local data available and optional providers clearly identified.",
    ])

    doc.add_heading("11 Limitations and Risks", level=1)
    add_bullets(doc, [
        "The ratings dataset cannot establish which destination received the higher rating because it has no city or venue keys.",
        "It cannot provide historical travel stories, completed trip itineraries, duration-specific ratings, or user-written review explanations.",
        "The destination catalog is small and manually curated; it should not be presented as a comprehensive or independently verified destination database.",
        "The itinerary may use current mapped names, but map coverage, opening hours, route times, availability and price data can be missing or stale.",
        "OpenStreetMap results do not consistently provide user ratings or photos; Google Places use requires a working key and billing permissions.",
        "The budget analysis cannot verify trip feasibility without current prices for travel, lodging, food and activities.",
        "The seven-case evaluation is small and self-authored. Its checklist score reflects explicit expected behaviors rather than broad recommendation quality; RAGAS similarity is not factual accuracy.",
        "The default local auth system has no external OAuth sign-in, password reset flow, managed identity provider, production abuse controls, or managed database.",
        "Provider and embedding startup latency can vary. The fast offline mode avoids hosted generation and skips expensive reranking on the primary search path.",
    ])

    doc.add_heading("12 Recommended Next Steps", level=1)
    add_numbered(doc, [
        "Add a reviewed destination-linked dataset with destination, venue, rating, price, dates, and traveler context. This is the prerequisite for answering which destination similar travelers rated better.",
        "Expand the benchmark with human-reviewed queries and expected categories, destinations, and evidence. Report ranking metrics such as Precision@k and nDCG alongside grounded-answer checks.",
        "Add independent human-labeled cases and run the LLM-judged GEval and RAGAS metrics on a suitable runtime; preserve judge versions, prompts, thresholds, and per-case reasons with the report.",
        "Validate itinerary stops against opening hours, travel time and location clusters; add a freshness timestamp and a visible fallback when map coverage is sparse.",
        "Connect feedback to an explicit, privacy-aware preference update only after consent and evaluation; feedback is currently stored but does not automatically train the recommender.",
        "For any public deployment, move identity and persistence to managed services, enforce HTTPS, add password reset and abuse controls, define data retention, and restrict API keys by application and API.",
    ])

    doc.add_heading("13 Local Run and Configuration", level=1)
    doc.add_paragraph("The documented local run uses two terminals from the project root:")
    for line in ("python -m src.data_pipeline", "uvicorn src.main:app --reload", "streamlit run frontend/frontend.py"):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(.25)
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(line)
        r.font.name = "Cascadia Code"
        r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor.from_string(BLUE)
    doc.add_paragraph(
        "The default planner is deterministic and offline. Build the local vector index with `python -m src.build_index` after installing the project requirements. Local `.env` settings control embeddings, optional LLM providers, place providers and SMTP. Never commit keys or passwords. The no-key map mode uses OpenStreetMap. Google Places requires `PLACES_PROVIDER=google`, a Places API-enabled and appropriately restricted key in `GOOGLE_MAPS_API_KEY`, and billing."
    )

    doc.add_heading("14 Project Files", level=1)
    add_table(doc, ["Path", "Contents"], [
        ("src/data_pipeline.py", "CSV cleaning, statistics and traveler profile generation."),
        ("src/retrieval.py and src/travel_recommendations.py", "Hybrid retrieval, category evidence and interest-ranked destination ideas."),
        ("src/workflow.py and src/planner.py", "LangGraph trip workflow, request extraction and offline planning."),
        ("src/api/routes/travel.py", "Submission API route family."),
        ("src/services/", "Google Places, OpenStreetMap, and optional LLM service clients."),
        ("frontend/", "Streamlit app, itinerary, chat, auth, voice and admin pages."),
        ("evaluation/", "DeepEval and RAGAS runners, seven diagnostic cases, and per-case result artifacts."),
        ("docs/", "API, architecture, dataset, design, evaluation and sample-case documents."),
        ("presentation/", "Presentation deck and presenter script."),
    ], [2.7, 4.0])

    doc.add_heading("Sources and Notes", level=1)
    doc.add_paragraph(
        "Dataset source: UCI Machine Learning Repository, Travel Review Ratings, dataset 485, DOI 10.24432/C5C31Q. The project documents a Creative Commons Attribution 4.0 license for the dataset. Map listings use OpenStreetMap attribution when that provider is active."
    )
    doc.add_paragraph(
        "This report summarizes the source tree and the stored project artifacts present on 10 October 2026. Evaluation results are quoted from `evaluation/deepeval_scores.json`, `evaluation/deepeval_requirement_scores.json`, and `docs/Evaluation_Report.md`; the current results are recorded in the evaluation artifacts."
    )

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(OUT)
    print(DIAGRAM)


if __name__ == "__main__":
    build_report()
