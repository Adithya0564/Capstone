"""Run DeepEval against live offline-planner outputs with a local Ollama judge."""
from __future__ import annotations

import json
import os
import argparse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from src.evaluation import deepeval_available

ROOT = Path(__file__).resolve().parents[1]
DATASET_PATH = Path(__file__).with_name("evaluation_dataset.json")
RESULTS_PATH = Path(__file__).with_name("deepeval_scores.json")
load_dotenv(ROOT / ".env")


def _render_actual(result: dict[str, Any], request: dict[str, Any]) -> str:
    """Keep the evaluated answer focused on user-visible plan content."""
    lines = [f"Status: {result.get('status', 'unknown')}."]
    if result.get("status") == "needs_destination":
        lines.append(str(result.get("message", "The planner asks for a destination.")))
    else:
        classification = result.get("preference_classification") or {}
        lines.append(
            f"Destination: {result.get('destination')}; duration: {result.get('duration_days')} days; "
            f"group: {request.get('travel_type') or classification.get('travel_type', 'unspecified')} with "
            f"{request.get('group_size', 'the requested number of')} travelers; "
            f"budget: {result.get('budget')} {request.get('currency', 'INR')}; "
            f"interests: {', '.join(request.get('interests', [])) or 'none stated'}."
        )
        if result.get("budget_assessment"):
            lines.append(f"Budget assessment: {result['budget_assessment']}")
        for day in result.get("itinerary", []):
            lines.append(
                f"Day {day.get('day')}: morning {day.get('morning')} "
                f"afternoon {day.get('afternoon')} evening {day.get('evening')}"
            )
    if result.get("explanation"):
        lines.append(f"Data limitation: {result['explanation']}")
    return "\n".join(lines)


def _actual_output(example: dict[str, Any]) -> tuple[str, list[str]]:
    if example.get("actual_output"):
        return str(example["actual_output"]), [str(v) for v in example.get("retrieval_context", [])]
    request = example.get("request")
    if not isinstance(request, dict) or not request.get("query"):
        raise ValueError("Each example needs actual_output or a request with query.")
    if example.get("kind") == "experience_search":
        from src.main import profiles
        from src.travel_recommendations import recommend_from_query

        result = recommend_from_query(
            request["query"], profiles(), top_k=int(request.get("top_k", 5)), fast=False
        )
        # Score the concise user-facing evidence rather than sending the entire
        # serialized profile payload to a local LLM judge on every metric call.
        lines = [
            f"For your request: {result.get('query')}.",
            "Answer: " + str(result.get("answer", "")),
            "Matched interests: " + (", ".join(result.get("matched_interests", [])) or "none recognized") + ".",
        ]
        duration_days = request.get("duration_days") or result.get("duration_days")
        if duration_days is not None:
            lines.append(f"This is a {duration_days}-day request; duration does not filter historical ratings.")
        for item in result.get("interest_highlights", []):
            top = item.get("top_categories", [])
            if top:
                ratings = ", ".join(f"{row['category']} {row['similar_profile_average']:.2f}/5 "
                                     f"({row['profiles_with_rating']} profiles)" for row in top)
                lines.append(f"For {item['interest']}, similar travelers rated these relevant place categories: {ratings}.")
            else:
                lines.append(f"{item['interest'].title()}: no recorded category ratings among retrieved profiles.")
        similar = result.get("similar_profiles", [])
        if similar:
            lines.append(f"These summaries use the {len(similar)} similar traveler rating profiles retrieved for this query.")
        destination_groups: dict[int, list[str]] = {}
        for place in result.get("destination_suggestions", []):
            destination_groups.setdefault(place["match_count"], []).append(place["name"])
        if destination_groups:
            match_summary = "; ".join(
                f"{count}/{len(result.get('matched_interests', []))} priorities: {', '.join(names)}"
                for count, names in sorted(destination_groups.items(), reverse=True)
            )
            lines.append("Destination ideas by interest-tag overlap: " + match_summary +
                         ". These are curated interest matches, not destination ratings from the dataset.")
        for place in result.get("destination_suggestions", []):
            rating = place.get("similar_traveler_category_rating")
            lines.append(
                f"Priority {place.get('priority')}: {place.get('name')}; "
                f"matched {', '.join(place.get('matched_interests', []))}; "
                f"similar-profile category rating {rating if rating is not None else 'unavailable'}/5; "
                "not a destination rating."
            )
        lines.append("Data limit: ratings describe place categories, not individual trip narratives or city-level ratings.")
        category_context = "Requested category evidence: " + "; ".join(
            f"{row['category']} {row['similar_profile_average'] if row['similar_profile_average'] is not None else 'no recorded rating'}"
            for row in result.get("matched_categories", [])
        )
        return "\n".join(lines), [category_context,
            "UCI Travel Review Ratings dataset 485 maps Category 3 to beaches, Category 6 to museums, Category 9 to restaurants, Category 21 to cafes, Category 23 to monuments, and Category 24 to gardens.",
            "The source has per-traveler average category ratings, but no trip narratives, trip duration, or city-level ratings.",
        ]
    if example.get("kind") == "profile_search":
        from src.main import profiles
        from src.retrieval import retrieve

        results = retrieve(request["query"], profiles(), top_k=int(request.get("top_k", 3)), fast=True)
        if not results:
            return "No matching anonymous rating profiles were retrieved.", []
        context = [str(row.get("evidence", "")) for row in results]
        top_dimension = request.get("query", "").casefold().replace(" ", "_")
        lines = [f"Retrieved {len(results)} anonymous rating profiles matching {request['query']}."]
        for row in results:
            value = (row.get("category_ratings") or {}).get(top_dimension)
            lines.append(f"{row.get('user_id')}: {top_dimension} rating {value}; profile mean {row.get('average_rating')}.")
        lines.append("Category names are anonymous dimensions and do not identify travel activities, destinations, or places.")
        return "\n".join(lines), context
    from src.planner import TravelRequest
    from src.main import itinerary

    result = itinerary(TravelRequest(**request))
    context = example.get("retrieval_context") or result.get("dataset_evidence") or []
    return _render_actual(result, request), [str(value) for value in context]


def build_cases(examples: list[dict[str, Any]]):
    from deepeval.test_case import LLMTestCase

    cases = []
    for index, example in enumerate(examples, start=1):
        if not example.get("input") or not example.get("expected_output"):
            raise ValueError(f"Example {index} needs an input and a reference expectation.")
        actual, context = _actual_output(example)
        cases.append((str(example.get("id", f"case-{index}")), LLMTestCase(
            input=str(example["input"]),
            actual_output=actual,
            expected_output=str(example["expected_output"]),
            retrieval_context=context,
            metadata={"checklist": _checklist_for(example)},
        )))
    return cases


def _checklist_for(example: dict[str, Any]) -> list[dict[str, Any]]:
    """Objective checks tied to explicit, observable requirements per case."""
    request = example.get("request", {})
    if example.get("kind") == "experience_search":
        checks = [
            {"name": "similar_profiles_returned", "value": "similar traveler rating profiles"},
            {"name": "dataset_scope_disclosed", "value": "trip narratives"},
            {"name": "destination_scores_not_claimed", "value": "not destination ratings"},
        ]
        if request.get("duration_days"):
            checks.append({"name": "duration_not_used_as_filter", "value": str(request["duration_days"])})
        checks.extend({"name": "category_returned", "value": str(category).casefold()}
                      for category in example.get("expected_categories", []))
        if example.get("check_destinations"):
            checks.append({"name": "interest_matched_destinations", "value": "destination idea"})
        if example.get("check_comparison_limit"):
            checks.extend([
                {"name": "comparison_limit_disclosed", "value": "does not link ratings to destinations"},
                {"name": "ranked_destination_options", "value": "priority 1"},
            ])
        if example.get("check_budget_limit"):
            checks.extend([
                {"name": "budget_limit_disclosed", "value": "no hotel names, individual prices, or trip budgets"},
                {"name": "ranked_destination_options", "value": "priority 1"},
            ])
        return checks
    if example.get("kind") == "profile_search":
        return [
            {"name": "category_named", "value": request.get("query", "")},
            {"name": "rating_value_present", "value": "5.0"},
            {"name": "anonymous_limit_disclosed", "value": "anonymous"},
        ]
    if not request.get("destination"):
        return [
            {"name": "asks_for_destination", "value": "which destination"},
            {"name": "relationship_reflected", "value": str(request.get("travel_type", "")).casefold()},
            {"name": "duration_reflected", "value": f"{request.get('duration_days')} day"},
            {"name": "dataset_limit_disclosed", "value": "no destination"},
        ]
    return [
        {"name": "destination_reflected", "value": str(request.get("destination", "")).casefold()},
        {"name": "requested_day_count", "value": str(request.get("duration_days", ""))},
        {"name": "relationship_reflected", "value": str(request.get("travel_type", "")).casefold()},
        {"name": "budget_amount_reflected", "value": str(int(request.get("budget", 0)))},
        {"name": "budget_uncertainty_disclosed", "value": "unknown"},
        {"name": "dataset_limit_disclosed", "value": "no labels"},
    ]


def _requirement_metric_class(base_metric):
    """Return a DeepEval custom metric for transparent literal requirement checks."""
    class RequirementChecklistMetric(base_metric):
        __name__ = "RequirementChecklist"

        def __init__(self):
            self.threshold = 0.9
            self.async_mode = False
            self.strict_mode = False
            self.include_reason = True
            self.score = None
            self.reason = None
            self.success = None
            self.error = None

        def measure(self, test_case, *args, **kwargs):
            output = (test_case.actual_output or "").casefold()
            context = " ".join(test_case.retrieval_context or []).casefold()
            checks = (test_case.metadata or {}).get("checklist", [])
            passed = []
            for check in checks:
                name, value = check["name"], str(check.get("value", "")).casefold()
                if name == "requested_day_count":
                    found = sum(1 for line in output.splitlines()
                                if line.strip().startswith("day ") and ": morning " in line)
                    ok = found == int(value)
                elif name == "duration_not_used_as_filter":
                    ok = f"{value}-day request" in output and "duration does not filter" in output
                elif name == "category_returned":
                    ok = value in output or value in context
                elif name == "similar_profiles_returned":
                    ok = value in output
                elif name == "dataset_scope_disclosed":
                    ok = value in output
                elif name == "destination_scores_not_claimed":
                    ok = value in output
                elif name == "interest_matched_destinations":
                    ok = value in output and ("curated interest tags" in output or "curated interest matches" in output)
                elif name in {"comparison_limit_disclosed", "budget_limit_disclosed"}:
                    ok = value in output
                elif name == "ranked_destination_options":
                    ok = value in output and "priority 2" in output and "priority 3" in output
                elif name == "budget_amount_reflected":
                    ok = value in output or f"{int(value):,}" in output
                elif name == "budget_uncertainty_disclosed":
                    ok = any(word in output for word in ("unknown", "cannot be confirmed", "cannot establish"))
                elif name == "dataset_limit_disclosed":
                    ok = value in output or "no destination or attraction" in output
                elif name == "asks_for_destination":
                    ok = value in output
                elif name == "category_named":
                    ok = value.casefold() in output
                elif name == "rating_value_present":
                    ok = value in output
                elif name == "anonymous_limit_disclosed":
                    ok = "anonymous" in output and any(word in output for word in ("unlabeled", "not identify", "not a rating"))
                else:
                    ok = bool(value) and value in output
                passed.append((name, ok))
            self.score = sum(ok for _, ok in passed) / len(passed) if passed else 0.0
            failed = [name for name, ok in passed if not ok]
            self.reason = (f"Passed {len(passed) - len(failed)}/{len(passed)} explicit checks. "
                           + ("Failed: " + ", ".join(failed) if failed else "All stated checks passed."))
            self.success = self.score >= self.threshold
            return self.score

        async def a_measure(self, test_case, *args, **kwargs):
            return self.measure(test_case, *args, **kwargs)

    return RequirementChecklistMetric


def _judge_model():
    provider = os.getenv("DEEPEVAL_PROVIDER", "ollama").strip().casefold()
    model_name = os.getenv("DEEPEVAL_MODEL", "qwen2.5:3b").strip()
    if provider == "ollama":
        from deepeval.models import OllamaModel
        base_url = os.getenv("DEEPEVAL_BASE_URL", "http://127.0.0.1:11434").strip()
        return OllamaModel(model=model_name, base_url=base_url, temperature=0), f"Ollama / {model_name}"
    if provider == "openai":
        if not os.getenv("OPENAI_API_KEY"):
            raise SystemExit("DEEPEVAL_PROVIDER=openai requires OPENAI_API_KEY.")
        return model_name, f"OpenAI / {model_name}"
    raise SystemExit("DEEPEVAL_PROVIDER must be 'ollama' (local) or 'openai'.")


def run(dataset_path: Path = DATASET_PATH, results_path: Path = RESULTS_PATH,
        checklist_only: bool = False, answer_relevancy_only: bool = False) -> dict[str, Any]:
    data = json.loads(dataset_path.read_text(encoding="utf-8"))
    examples = data.get("examples", [])
    if not examples:
        raise SystemExit("No evaluation run: add benchmark examples with authored expectations first.")
    if not deepeval_available():
        raise SystemExit("Install evaluation dependencies with: pip install -r requirements-evaluation.txt")

    from deepeval.metrics import AnswerRelevancyMetric, BaseMetric, GEval
    from deepeval.test_case import SingleTurnParams

    cases = build_cases(examples)
    RequirementChecklistMetric = _requirement_metric_class(BaseMetric)
    metrics = [("RequirementChecklist", RequirementChecklistMetric())]
    model_label = "DeepEval deterministic explicit-requirement checklist"
    if not checklist_only:
        model, model_label = _judge_model()
        metrics.append(("AnswerRelevancy", AnswerRelevancyMetric(model=model, include_reason=True, async_mode=False)))
        if not answer_relevancy_only:
            metrics.append(("ExperienceRecommendationAdherence", GEval(
            name="ExperienceRecommendationAdherence",
            criteria=(
                "Check whether the answer maps the traveler's stated priorities to the correct documented "
                "UCI Travel Review Ratings categories, retrieves similar profiles, and reports observed "
                "ratings accurately. Reward clear explanations that these are category-level user averages, "
                "not individual trip narratives or city ratings, and that destination ideas are curated "
                "interest matches rather than historical destination recommendations."
            ),
            evaluation_params=[
                SingleTurnParams.INPUT,
                SingleTurnParams.ACTUAL_OUTPUT,
                SingleTurnParams.EXPECTED_OUTPUT,
                SingleTurnParams.RETRIEVAL_CONTEXT,
            ],
            model=model,
            async_mode=False,
            )))
    report: dict[str, Any] = {
        "status": "running",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "deepeval_version": __import__("deepeval").__version__,
        "judge": model_label,
        "dataset": str(dataset_path.name),
        "label_note": data.get("label_note", ""),
        "metrics": {},
        "cases": [],
    }
    _write_report(report, results_path)
    for case_id, test_case in cases:
        case_record: dict[str, Any] = {
            "id": case_id,
            "input": test_case.input,
            "expected_output": test_case.expected_output,
            "actual_output": test_case.actual_output,
            "retrieval_context": test_case.retrieval_context,
            "checklist": (test_case.metadata or {}).get("checklist", []),
            "scores": {},
        }
        report["cases"].append(case_record)
        _write_report(report, results_path)
        for metric_name, metric in metrics:
            metric.measure(test_case)
            score = float(metric.score or 0.0)
            record = {
                "score": score,
                "score_percent": round(score * 100, 2),
                "threshold": float(metric.threshold),
                "passed_threshold": bool(metric.is_successful()),
                "reason": str(metric.reason or ""),
            }
            case_record["scores"][metric_name] = record
            print(f"{case_id} · {metric_name}: {record['score_percent']:.2f}%", flush=True)
            _write_report(report, results_path)

    metric_names = [name for name, _ in metrics]
    report["metrics"] = {
        name: {
            "mean_score": sum(case["scores"][name]["score"] for case in report["cases"]) / len(cases),
            "mean_score_percent": round(sum(case["scores"][name]["score"] for case in report["cases"]) * 100 / len(cases), 2),
            "threshold": float(next(metric.threshold for metric_name, metric in metrics if metric_name == name)),
        }
        for name in metric_names
    }
    all_scores = [case["scores"][name]["score"] for case in report["cases"] for name in metric_names]
    report["overall_mean_score"] = sum(all_scores) / len(all_scores)
    report["overall_mean_score_percent"] = round(report["overall_mean_score"] * 100, 2)
    report["interpretation"] = (
        "RequirementChecklist is a deterministic literal rubric over the authored case checklist. "
        "AnswerRelevancy and ExperienceRecommendationAdherence are local Ollama LLM-judge estimates. "
        "These scores are diagnostic, are not independently human-validated, and do not represent a project grade or traveler satisfaction."
    )
    report["status"] = "complete"
    report["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
    _write_report(report, results_path)
    print(f"Overall DeepEval mean: {report['overall_mean_score_percent']:.2f}% ({len(cases)} cases × {len(metrics)} metrics)")
    print(f"Saved: {results_path}")
    return report


def _write_report(report: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checklist-only", action="store_true",
                        help="Run the transparent deterministic metric without invoking an LLM judge.")
    parser.add_argument("--answer-relevancy-only", action="store_true",
                        help="Run checklist plus DeepEval AnswerRelevancy, omitting the slower GEval judge.")
    parser.add_argument("--output", type=Path, default=RESULTS_PATH,
                        help="JSON output path for this evaluation run.")
    args = parser.parse_args()
    run(results_path=args.output, checklist_only=args.checklist_only,
        answer_relevancy_only=args.answer_relevancy_only)
