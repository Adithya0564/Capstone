"""Run RAGAS metrics against the actual offline travel recommendation flow.

The local judge uses Ollama and local sentence-transformer embeddings. The
four authored cases are diagnostic examples, not independent travel-domain
ground truth or a project-wide accuracy claim.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import types
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
DATASET_PATH = Path(__file__).with_name("evaluation_dataset.json")
RESULTS_PATH = Path(__file__).with_name("ragas_scores.json")
load_dotenv(ROOT / ".env")
os.environ.setdefault("RAGAS_DO_NOT_TRACK", "true")


def _patch_removed_optional_vertex_import() -> None:
    """Bridge RAGAS 0.4's optional legacy import when LangChain 0.4 removed it.

    RAGAS imports this class only to recognize provider integrations. Our local
    Ollama evaluation never instantiates Vertex AI. Keeping the shim process-local
    avoids changing the user's installed LangChain packages.
    """
    try:
        import langchain_community.chat_models.vertexai  # noqa: F401
    except ModuleNotFoundError as exc:
        if exc.name != "langchain_community.chat_models.vertexai":
            raise
        module_name = "langchain_community.chat_models.vertexai"
        shim = types.ModuleType(module_name)
        shim.ChatVertexAI = type("ChatVertexAI", (), {})
        sys.modules[module_name] = shim


def _build_samples() -> list[dict[str, Any]]:
    from src.main import profiles
    from src.travel_recommendations import DESTINATION_CATALOG, recommend_from_query
    from src.travel_intent import category_labels

    source = json.loads(DATASET_PATH.read_text(encoding="utf-8"))
    examples = source.get("examples", [])
    if not examples:
        raise ValueError("evaluation_dataset.json has no authored cases")

    available_profiles = profiles()
    labels = category_labels()
    catalog_evidence = "Curated destination catalog and tags: " + "; ".join(
        f"{item['name']} ({item['country']}): {', '.join(item['tags'])}"
        for item in DESTINATION_CATALOG
    )
    samples = []

    for case in examples:
        request = case.get("request") or {}
        query = str(request.get("query") or case["input"])
        result = recommend_from_query(query, available_profiles,
                                      top_k=int(request.get("top_k", 5)), fast=False)

        lines = [f"Request: {query}"]
        lines.append("Answer: " + str(result.get("answer", "")))
        lines.append("Matched interests: " + (", ".join(result.get("matched_interests", [])) or "none recognized") + ".")
        if result.get("duration_days") is not None:
            lines.append(f"This is a {result['duration_days']}-day request; duration does not filter historical ratings.")
        for group in result.get("interest_highlights", []):
            ratings = group.get("top_categories", [])
            if ratings:
                formatted = ", ".join(
                    f"{row['category']} {row['similar_profile_average']:.2f}/5 "
                    f"({row['profiles_with_rating']} profiles)"
                    for row in ratings
                )
                lines.append(f"For {group['interest']}, retrieved profile category averages: {formatted}.")
        suggestions = result.get("destination_suggestions", [])
        if suggestions:
            summary = "; ".join(
                f"priority {item.get('priority', '?')}: {item['name']} "
                f"(similar-profile category evidence {item.get('similar_traveler_category_rating')}/5; "
                f"{len(item.get('matched_interests', []))} matched priorities: "
                f"{', '.join(item.get('matched_interests', []))})"
                for item in suggestions
            )
            lines.append("Curated destination ideas ranked by interest-tag match: " + summary + ".")
        lines.append("Scope: ratings are category averages, not named-destination or venue ratings, "
                     "and the dataset contains no written reviews or past trip narratives.")
        response = "\n".join(lines)

        contexts = []
        for index, profile in enumerate(result.get("similar_profiles", []), start=1):
            observed = profile.get("matched_category_ratings", [])
            if observed:
                values = ", ".join(f"{row['category']}: {float(row['rating']):.2f}/5" for row in observed)
                contexts.append(f"Retrieved similar traveler profile {index}: {values}.")
        category_rows = result.get("matched_categories", [])
        if category_rows:
            contexts.append("Observed category averages among retrieved profiles: " + "; ".join(
                f"{row['category']}: {row['similar_profile_average'] if row['similar_profile_average'] is not None else 'not rated'}"
                f"/5 from {row.get('profiles_with_rating', 0)} profiles"
                for row in category_rows
            ) + ".")
        contexts.append("UCI Travel Review Ratings category mapping: " + "; ".join(
            f"{category} = {label}" for category, label in labels.items()
        ) + ".")
        contexts.append("Dataset scope: one traveler row contains average ratings across place categories; "
                        "there are no trip narratives, destination IDs, named venues, dates, or prices.")
        contexts.append(catalog_evidence)

        samples.append({
            "user_input": query,
            "retrieved_contexts": contexts,
            "response": response,
            "reference": str(case["expected_output"]),
        })
    return samples


def run(model: str = "qwen2.5:3b", base_url: str = "http://127.0.0.1:11434/v1",
        output: Path = RESULTS_PATH) -> dict[str, Any]:
    _patch_removed_optional_vertex_import()

    from ragas import EvaluationDataset, RunConfig, evaluate
    from langchain_openai import ChatOpenAI
    from langchain_community.embeddings import HuggingFaceEmbeddings as LangchainHuggingFaceEmbeddings
    from ragas.metrics._answer_relevance import AnswerRelevancy
    from ragas.metrics._context_precision import ContextPrecision
    from ragas.metrics._context_recall import ContextRecall
    from ragas.metrics._faithfulness import Faithfulness

    samples = _build_samples()
    judge = ChatOpenAI(model=model, base_url=base_url, api_key="ollama-local",
                       temperature=0.0, timeout=180, max_retries=0)
    embeddings = LangchainHuggingFaceEmbeddings(
        model_name=os.getenv("RAGAS_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"),
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True, "batch_size": 8},
        show_progress=False,
    )
    metrics = [
        Faithfulness(),
        AnswerRelevancy(),
        ContextPrecision(),
        ContextRecall(),
    ]

    run_record: dict[str, Any] = {
        "status": "running",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "ragas_version": __import__("ragas").__version__,
        "judge": f"Ollama / {model}",
        "embedding_model": os.getenv("RAGAS_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"),
        "dataset": DATASET_PATH.name,
        "case_count": len(samples),
        "label_note": "Seven authored diagnostics; expectations are not independently human-reviewed and are not travel-satisfaction ground truth.",
        "metrics": {},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(run_record, indent=2), encoding="utf-8")

    result = evaluate(
        dataset=EvaluationDataset.from_list(samples, name="travelgenie_ragas_diagnostic"),
        metrics=metrics,
        llm=judge,
        embeddings=embeddings,
        run_config=RunConfig(timeout=180, max_retries=1, max_wait=4, max_workers=1),
        raise_exceptions=True,
        show_progress=True,
    )
    frame = result.to_pandas()
    score_columns = [metric.name for metric in metrics if metric.name in frame.columns]
    per_case = []
    for row in frame.to_dict(orient="records"):
        clean = {}
        for key, value in row.items():
            if hasattr(value, "item"):
                value = value.item()
            if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))):
                value = None
            clean[key] = value
        per_case.append(clean)

    metric_summary = {}
    for column in score_columns:
        values = [float(row[column]) for row in per_case if row.get(column) is not None]
        metric_summary[column] = {
            "mean_score": round(sum(values) / len(values), 4) if values else None,
            "mean_score_percent": round(100 * sum(values) / len(values), 2) if values else None,
            "scored_cases": len(values),
            "case_scores": [row.get(column) for row in per_case],
        }
    run_record.update({
        "status": "complete",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "metrics": metric_summary,
        "overall_mean_percent": round(
            100 * sum(item["mean_score"] for item in metric_summary.values() if item["mean_score"] is not None)
            / max(1, sum(item["mean_score"] is not None for item in metric_summary.values())), 2
        ),
        "cases": per_case,
    })
    output.write_text(json.dumps(run_record, indent=2, ensure_ascii=False), encoding="utf-8")
    return run_record


def run_semantic_only(output: Path = RESULTS_PATH) -> dict[str, Any]:
    """Run RAGAS SemanticSimilarity without a slow or hosted LLM judge."""
    _patch_removed_optional_vertex_import()
    from ragas.embeddings import HuggingFaceEmbeddings
    from ragas.metrics.collections import SemanticSimilarity

    samples = _build_samples()
    embedding_model = os.getenv("RAGAS_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    embeddings = HuggingFaceEmbeddings(model=embedding_model, device="cpu")
    metric = SemanticSimilarity(embeddings=embeddings)

    async def score_samples():
        results = []
        for sample in samples:
            score = await metric.ascore(reference=sample["reference"], response=sample["response"])
            results.append(float(score.value))
        return results

    scores = asyncio.run(score_samples())
    mean = sum(scores) / len(scores) if scores else 0.0
    record = {
        "status": "complete",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "ragas_version": __import__("ragas").__version__,
        "judge": "None; embedding-only metric",
        "embedding_model": embedding_model,
        "dataset": DATASET_PATH.name,
        "case_count": len(scores),
        "label_note": "RAGAS SemanticSimilarity only: embedding similarity of actual recommendation responses to project-authored reference expectations. This is not a faithfulness, retrieval-precision, factuality, or traveler-satisfaction score; references are not independently human-reviewed.",
        "metrics": {
            "semantic_similarity": {
                "mean_score": round(mean, 4),
                "mean_score_percent": round(mean * 100, 2),
                "scored_cases": len(scores),
                "case_scores": [round(score, 4) for score in scores],
            }
        },
        "overall_mean_percent": round(mean * 100, 2),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")
    return record


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default=os.getenv("RAGAS_MODEL", "qwen2.5:3b"))
    parser.add_argument("--base-url", default=os.getenv("RAGAS_BASE_URL", "http://127.0.0.1:11434/v1"))
    parser.add_argument("--output", type=Path, default=RESULTS_PATH)
    parser.add_argument("--semantic-only", action="store_true",
                        help="Run local embedding-only SemanticSimilarity; no LLM judge calls.")
    args = parser.parse_args()
    report = run_semantic_only(args.output) if args.semantic_only else run(args.model, args.base_url, args.output)
    print(json.dumps({"status": report["status"], "overall_mean_percent": report.get("overall_mean_percent"),
                      "metrics": report["metrics"], "output": str(args.output)}, indent=2))
