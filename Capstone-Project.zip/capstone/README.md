# AI-Powered Multi-Agent Personalized Travel Planner

**Describe the journey. AI plans the experience.**

TravelGenie AI (legacy interface label: Voyage AI) is a local travel recommendation capstone with hybrid retrieval, an API, and a Streamlit interface. The supplied `google_review_ratings.csv` contains 5,456 traveler profiles with average ratings for 24 documented attraction categories. The official category meanings are restored in `config/category_mapping.json`. It has no written reviews, trip narratives, city-level ratings, trip dates, duration, or prices.

## Problem and solution

Travelers describe priorities in natural language, such as a five-day trip focused on beaches, sightseeing, and local food. The primary flow maps those priorities to the dataset's documented categories, hybrid-retrieves similar traveler rating profiles, and summarizes what those travelers rated highly. It then offers curated destination ideas matching the same interests. After a traveler chooses a destination, the existing itinerary flow asks for trip details and can look up named nearby stays, food, and attractions. Destination ideas are not destination ratings: the source data has no city field or review text.

## Features

- CSV schema detection, cleaning, invalid value and duplicate reporting, statistics, and per-user profiles.
- A LangGraph preference-classification node for interests, traveler type, pace, and budget tier, with field provenance and transparent rule-based behavior.
- BM25 keyword and dense vector retrieval, reciprocal rank fusion, profile filters, cross-encoder reranking, and preference scoring.
- Natural-language interest mapping to the UCI-defined category ratings, similar-profile retrieval, and aggregate rating evidence for the requested interests.
- Two-stage discovery: interest search and destination ideas first; trip length, budget, and traveler group after a destination is selected.
- A destination-linked travel-experience corpus adapter with hybrid ranking and destination, travel-type, minimum-rating, and maximum-budget filters.
- Optional ChromaDB profile index using local Sentence Transformers embeddings by default (with Ollama/Gemini alternatives); text generation uses hosted providers or a deterministic offline fallback.
- FastAPI endpoints for health, statistics, search, itinerary requests, feedback, and operational summary.
- Live OpenStreetMap stay and food listings with map links as the no-key default; optional Google Places ratings and photos when enabled with `PLACES_PROVIDER=google` and a valid `GOOGLE_MAPS_API_KEY`.
- LangGraph query/retrieval/planning workflow with deterministic duration validation and explicit unknown-budget reporting.
- Streamlit destination picker with a days/budget/travelers setup dialog and a dedicated colorful itinerary page; nearby places load on demand so place search does not delay itinerary creation.
- Email-confirmed sign-up, password sign-in, account-scoped chat history, and an administrator usage overview. Passwords are stored as salted PBKDF2 hashes; confirmation tokens are one-use and expire after 24 hours.
- Browser voice dictation is available on the travel search and chatbot pages; browser speech synthesis can read the most recent chat reply aloud.
- Travel assistant focused on destination and group type (couple, family, or friends), returning group-prioritized mapped sights and map links.
- Budget-aware place finder that uses total budget, duration, and party size to prioritize budget-oriented or premium stays and restaurants, exposing available class and price tags.
- A fast deterministic offline itinerary is the default, avoiding hosted model and reranker startup latency. Set `FAST_ITINERARY_MODE=false` to enable hosted model generation; set `FAST_RETRIEVAL_MODE=false` to include semantic vector search and cross-encoder reranking in itinerary requests.
- Optional itinerary LLM-as-judge validation plus reproducible DeepEval and RAGAS diagnostics. Evaluation references are project-authored and disclosed as unreviewed; scores are not a project grade.
- Input validation, feedback capture, and architecture/data documentation.

## Technology

Python, FastAPI, Pydantic, pandas, Streamlit, ChromaDB, Sentence Transformers, Google GenAI, OpenAI, LangGraph, ReportLab, python-pptx.

## Dataset and processing

`data/raw/google_review_ratings.csv` is the UCI Travel Review Ratings dataset (ID 485). UCI defines the 24 category meanings; this project preserves those labels while cleaning values and building per-traveler preference profiles. The pipeline detects `Category N`, drops empty columns, converts ratings to numeric, preserves missingness, marks invalid/out-of-range values missing and reports counts. Duplicate user IDs retain the first row. It writes `data/processed/cleaned_reviews.csv`, `dataset_statistics.json`, and `traveler_profiles.jsonl`. See [Dataset Details](docs/Dataset_Details.md).

Category labels and provenance are recorded in `config/category_mapping.json` and [Dataset Details](docs/Dataset_Details.md). The dataset is useful for matching traveler interests to highly rated attraction categories. It does not contain destination-specific experiences; optional destination/travel-type/rating/budget filters over trip records require a separate reviewed corpus imported with `python -m src.import_experiences path\to\your_reviewed_trips.csv`.

## Installation

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
# Configure the local .env file with the settings documented below.
```

The travel planner works with the deterministic offline path and does not require model-provider keys. Account sign-up does require an SMTP service to send confirmation mail. Configure credentials in your local `.env` file; it is excluded from Git and must not be committed. For OpenRouter or another OpenAI-compatible endpoint, set `LLM_API_KEY`, `LLM_MODEL`, and `LLM_BASE_URL`. This provider is tried first; Gemini and OpenAI settings remain supported as compatibility fallbacks. The project does not print or commit key values.

Optional hosted text generation uses `LLM_TEMPERATURE=0.3` by default for restrained variation. Set a value from `0` to `2` in `.env` to adjust it; the provider/model must support temperature. This setting does not affect the default deterministic offline planner or embeddings.

### Accounts, email, and admin access

Configure SMTP in `.env` to send email verification and welcome messages:

```dotenv
APP_PUBLIC_URL=http://localhost:8501
SMTP_HOST=smtp.your-provider.example
SMTP_PORT=587
SMTP_USER=your-smtp-user
SMTP_PASSWORD=your-smtp-password
SMTP_FROM=TravelGenie AI <no-reply@your-domain.example>
ADMIN_EMAILS=you@your-domain.example
```

Use an SMTP app password or provider credential, not your personal mailbox password. `APP_PUBLIC_URL` must be the address users can open from the confirmation email. Add administrator email addresses as a comma-separated list; an account becomes an admin only after that email is verified. Without SMTP configuration, registration is saved as unverified and the app explains which settings are missing. The first successful verification sends the welcome email.

Accounts and conversations are stored in `data/processed/travelgenie.sqlite3`, which is ignored by Git. Chat history is private to the signed-in account. The admin portal shows account and aggregate conversation activity, not message contents. This is a local capstone implementation; before public production deployment, use a managed identity provider, a managed database, HTTPS, backups, email abuse controls, password reset, and a formal privacy/retention policy.

## Run

```powershell
python -m src.data_pipeline
uvicorn src.main:app --reload
```

In another terminal:

```powershell
streamlit run frontend/frontend.py
```

Swagger UI: `http://127.0.0.1:8000/docs`

The default embedding configuration in `.env` uses free local Sentence Transformers embeddings. Install dependencies and build the persistent Chroma index with `python -m src.build_index`; the first run loads or downloads the model and computes vectors for all traveler profiles. To use Ollama instead, run `ollama pull nomic-embed-text` and set `EMBEDDING_PROVIDER=ollama`; Gemini embeddings are also supported. The optional CrossEncoder reranker downloads its model on first use; clear `RERANKER_MODEL` to use the hybrid ranking fallback. Retrieval remains available from profile data if vector setup fails.

## API

See [API Documentation](docs/API_Documentation.md) and `/docs` for live schemas. Submission routes are available under `/api/travel`: `/plan`, `/recommendations`, `/itinerary`, `/search`, `/feedback`, `/destinations`, and live place routes.

The primary search endpoint returns similar profiles and category-level rating summaries. Destination/trip filters apply only when a reviewed travel-experience corpus is imported. Enable optional online itinerary judging with `LLM_JUDGE_ENABLED=true` and a configured provider key; this adds a model call and does not replace human review. DeepEval runs locally by default using Ollama (`qwen2.5:3b`): install Ollama, run `ollama pull qwen2.5:3b`, install the optional evaluator with `.venv\Scripts\python.exe -m pip install -r requirements-evaluation.txt`, then run `.venv\Scripts\python.exe -m evaluation.deepeval_evaluation`. On slower CPUs, use `--answer-relevancy-only` to run the checklist and AnswerRelevancy without the more expensive GEval, or use `--checklist-only --output evaluation/deepeval_requirement_scores.json` for the deterministic rubric alone. Full runs save per-case scores and judge reasons to `evaluation/deepeval_scores.json`; progress is written incrementally. Set `DEEPEVAL_PROVIDER=openai` only if you deliberately want a hosted judge and have configured its key. References are project-authored diagnostics, not independently human-validated travel-quality labels.

By default, live stay and food cards use the public OpenStreetMap services: listings include names, available addresses and map links, but not user ratings or venue photos. Results show OpenStreetMap attribution. Searches happen only when a user generates a plan or refreshes place options; the public geocoder permits at most one request per second and may throttle use. See the [Nominatim usage policy](https://operations.osmfoundation.org/policies/nominatim/).

Selecting a popular destination on the home page opens a short setup dialog for trip length, total budget, travelers, and interests. Successful submissions navigate to the itinerary page. The default fast path uses the offline planner and lightweight profile retrieval, so responses stay independent of optional model and place-provider latency.

To use Google Places instead, set `PLACES_PROVIDER=google`, enable Places API (New) in Google Maps Platform, configure billing, and set `GOOGLE_MAPS_API_KEY` in `.env`. If Google rejects the key, the app falls back to OpenStreetMap. Google ratings and photo fields can incur additional Places API charges; review current [Google Maps Platform pricing](https://developers.google.com/maps/documentation/places/web-service/usage-and-billing) and [key security guidance](https://developers.google.com/maps/api-security-best-practices).

## Sample queries and expected behavior

1. **â€œA 5-day trip focused on beaches, sightseeing, and local food. What did similar travelers rate highly, and which destinations match these priorities?â€** Maps the query to documented categories; retrieves similar rating profiles; summarizes observed category ratings; and offers curated interest-matched destination ideas. It does not claim the dataset contains five-day narratives or destination-level ratings.
2. **â€œPlan three days in Goa for a family of three who like beaches and local food, budget â‚¹30,000.â€** After selecting Goa, opens the existing itinerary form with destination selected; the form collects duration, budget, party size, and relationship before generating the itinerary.
3. **â€œPlan two days in Bengaluru for a couple interested in culture and food.â€** The optional itinerary flow uses the selected couple and interests; place names come from the separate live map lookup when available.
4. **â€œWho rated museums highly?â€** Retrieves traveler profiles using the official Category 6 = museums mapping and shows the observed ratings.
5. **â€œFind family trips in Goa rated at least 4.â€** Searches the reviewed experience corpus. It returns no matches until that corpus has been imported.

Example API request:

```json
{"query":"Plan 5 relaxing days with local food for two","destination":"Goa","duration_days":5,"budget":50000,"group_size":2,"travel_type":"Couple","interests":["local food"]}
```

If destination is missing, API asks for it. Plans use user-provided destination and interests. Current budget assessment is informational because the dataset has no cost data; it does not claim numerical feasibility.

## Evaluation and testing

`pytest` exercises cleaning, profiles, retrieval, guardrails, and HTTP routes. See [the evaluation report](docs/Evaluation_Report.md) for the seven-case checklist and RAGAS results. A local RAGAS SemanticSimilarity diagnostic is stored in `evaluation/ragas_scores.json` and can be rerun with `.venv\Scripts\python.exe -m evaluation.ragas_evaluation --semantic-only`; it scores embedding similarity against project-authored references, not factuality or traveler satisfaction. Destination suggestions use curated interest tags rather than destination ratings because the source data has no city field.

## Sample outputs

The dataset endpoint reports 5,456 cleaned users and 24 named rating dimensions on UCI's documented 1â€“5 scale. Zero sentinels in the local export are counted as invalid/missing. A search for beaches maps to Category 3; a search for museums maps to Category 6. Results are similar traveler ratings aggregated by category, not review text or destination-level experiences.

## Troubleshooting

- **Dataset unavailable:** place the supplied CSV at `data/raw/google_review_ratings.csv`, then run `python -m src.data_pipeline`.
- **API unavailable in the UI:** start `uvicorn src.main:app --reload` before Streamlit.
- **First vector build takes time:** `python -m src.build_index` downloads the selected embedding model and computes the 5,456 profile vectors.
- **Sentence Transformers import mismatch:** reinstall from `requirements.txt` so the supported Transformers and Hugging Face Hub versions are installed together. For the local Ollama alternative, run `ollama pull nomic-embed-text` and keep Ollama running.
- **CrossEncoder first request is slow:** the example environment selects a model that downloads on first use. Clear `RERANKER_MODEL` to use the hybrid-score fallback.
- **Hosted model falls back offline:** add valid provider keys to local `.env`. Leave model IDs blank for provider model discovery. No keys or API responses are simulated.
- **Voice controls unavailable:** use a browser that supports speech recognition/synthesis; typed trip requests remain available.

## Future enhancements

Add a verified semantic category key, destination and pricing knowledge provider, labeled itinerary suitability dataset, independently reviewed RAGAS/DeepEval/LLM-as-Judge benchmarks, and broader browser speech testing.

## Current limitations

- No verified travel knowledge or activity catalog is supplied, so place facts and prices need manual verification.
- Browser speech support varies. The app receives a transcript and does not store audio.
- Hosted models require valid keys. Model IDs are discovered when blank; missing or failing providers are not simulated.
- LangGraph coordinates query understanding, profile retrieval, and planning. LangSmith traces require a local key and explicit opt-in.

## Project layout

See `docs/architecture.md`. Dataset and API documentation are generated from the implementation and observed data. Run `python generate_deliverables.py` to generate the architecture diagram, design, API, dataset, evaluation, and sample test case PDFs, plus the presentation deck.


