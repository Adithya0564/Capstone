"""Report executable evaluation readiness without inventing quality scores."""
import json
from src.evaluation import ragas_available, deepeval_available

if __name__ == "__main__":
    print(json.dumps({"status":"pending_labeled_outputs", "ragas_installed":ragas_available(), "deepeval_installed":deepeval_available(),
                      "metrics":None, "reason":"No labeled itinerary references and judged model outputs are supplied."}, indent=2))
