"""Run source validation and traveler profile generation."""
import json
from src.data_pipeline import run_pipeline

if __name__ == "__main__":
    print(json.dumps(run_pipeline(), indent=2))
