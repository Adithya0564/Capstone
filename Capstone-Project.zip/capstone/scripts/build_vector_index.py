"""Build the ChromaDB profile vector index."""
from src.build_index import main

if __name__ == "__main__":
    main()
