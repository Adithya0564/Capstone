"""Generate data-grounded PDF documentation and an editable 16-slide deck."""
from pathlib import Path
import json
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from xml.sax.saxutils import escape
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from src.data_pipeline import run_pipeline

ROOT=Path(__file__).parent
stats=run_pipeline()
navy=colors.HexColor("#0B1118"); mint=colors.HexColor("#287A69"); pale=colors.HexColor("#E7F3EF")
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name="Cover",parent=styles["Title"],fontName="Helvetica-Bold",fontSize=25,leading=31,textColor=navy,spaceAfter=15))
styles.add(ParagraphStyle(name="H2x",parent=styles["Heading2"],fontSize=15,leading=19,textColor=mint,spaceBefore=12,spaceAfter=6))
styles.add(ParagraphStyle(name="H3x",parent=styles["Heading3"],fontSize=12,leading=15,textColor=navy,spaceBefore=8,spaceAfter=4))
styles.add(ParagraphStyle(name="Bodyx",parent=styles["BodyText"],fontSize=9.2,leading=13,spaceAfter=6))
styles.add(ParagraphStyle(name="TableHeaderX",parent=styles["Bodyx"],fontName="Helvetica-Bold",textColor=colors.white,spaceAfter=0))
styles.add(ParagraphStyle(name="Codex",parent=styles["Code"],fontName="Courier",fontSize=7.5,leading=10,spaceAfter=1))

def footer(canvas,doc):
    canvas.saveState();w,h=letter;canvas.setFillColor(mint);canvas.rect(0,0,w,7,fill=1,stroke=0)
    canvas.setFont("Helvetica",8);canvas.setFillColor(colors.HexColor("#63717D"));canvas.drawString(42,24,"TRAVELGENIE AI  |  CAPSTONE PROJECT")
    canvas.drawRightString(w-42,24,str(doc.page));canvas.restoreState()

def md_to_story(path):
    story=[];lines=path.read_text(encoding="utf-8").splitlines();i=0;in_code=False
    def parse_row(value):return [escape(cell.strip().replace("`","")) for cell in value.strip().strip("|").split("|")]
    while i<len(lines):
        line=lines[i].strip()
        if line.startswith("```"):
            in_code=not in_code;i+=1;continue
        if not line:story.append(Spacer(1,4));i+=1;continue
        if in_code:
            story.append(Paragraph(escape(line),styles["Codex"]));i+=1;continue
        if line.startswith("|"):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith("|"):
                current=lines[i].strip()
                if not set(current.replace("|","").replace(":","").replace("-","").strip()):rows.append(parse_row(current))
                else:rows.append(parse_row(current))
                i+=1
            rows=[r for r in rows if not all(set(c)<=set(":- ") for c in r)]
            if rows:
                t=Table([[Paragraph(x,styles["TableHeaderX"] if row_index==0 else styles["Bodyx"]) for x in r] for row_index,r in enumerate(rows)],repeatRows=1,hAlign="LEFT")
                t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),navy),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTSIZE",(0,0),(-1,-1),8),("GRID",(0,0),(-1,-1),.3,colors.HexColor("#D1DDD8")),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,pale]),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6)]));story.append(t)
            continue
        if line.startswith("# "):story.append(Paragraph(escape(line[2:].replace("`","")),styles["Cover"]));i+=1;continue
        if line.startswith("### "):story.append(Paragraph(escape(line[4:].replace("`","")),styles["H3x"]));i+=1;continue
        if line.startswith("## "):
            heading=Paragraph(escape(line[3:].replace("`","")),styles["H2x"]);j=i+1
            while j<len(lines) and not lines[j].strip():j+=1
            if j<len(lines) and not lines[j].strip().startswith(("#","|","```")) and not lines[j].strip().startswith("- "):
                story.append(KeepTogether([heading,Paragraph(escape(lines[j].strip().replace("`","")),styles["Bodyx"])]));i=j+1
            else:story.append(heading);i+=1
            continue
        if line.startswith("- "):story.append(Paragraph("-  "+escape(line[2:].replace("`","")),styles["Bodyx"]))
        else:story.append(Paragraph(escape(line.replace("`", "").replace("**","")),styles["Bodyx"]))
        i+=1
    return story

def make_pdf(path,story):
    path.parent.mkdir(parents=True,exist_ok=True)
    SimpleDocTemplate(str(path),pagesize=letter,rightMargin=46,leftMargin=46,topMargin=48,bottomMargin=46,title=path.stem.replace("_"," ")).build(story,onFirstPage=footer,onLaterPages=footer)

# Dataset report: exact, computed source data and category metrics.
story=[Paragraph("Dataset Details",styles["Cover"]),Paragraph("UCI Travel Review Ratings (dataset 485) | computed from the supplied CSV",styles["H2x"]),Spacer(1,10)]
summary=[["Measure","Observed value"],["Source file",stats["dataset_name"]],["Clean rows",f"{stats['rows']:,}"],["Original columns",str(stats["columns_raw"])],["Kept columns",str(len(stats["columns"]))],["Rating dimensions",str(len(stats["category_columns"]))],["Fully empty columns removed",", ".join(stats["empty_columns_removed"]) or "None"],["Unnamed field populated cells excluded",str(stats["unassigned_unnamed_values"])],["Duplicate user rows removed",str(stats["duplicate_user_rows_removed"])],["Malformed/out-of-range rating values",str(sum(stats["invalid_value_counts"].values()))]]
t=Table(summary,colWidths=[205,270],repeatRows=1);t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),navy),("TEXTCOLOR",(0,0),(-1,0),colors.white),("BACKGROUND",(0,1),(-1,-1),pale),("GRID",(0,0),(-1,-1),.35,colors.white),("FONTSIZE",(0,0),(-1,-1),9),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),8),("TOPPADDING",(0,0),(-1,-1),6)]));story +=[t,Spacer(1,12),Paragraph("Observed source schema",styles["H2x"]),Paragraph(", ".join(["User"]+stats["category_columns"]),styles["Bodyx"]),Paragraph(f"The supplied CSV does not include category names. The project restores the official UCI category mapping from the dataset documentation; these labels describe attraction types, not individual destinations or places. The unnamed final column with {stats['unassigned_unnamed_values']} populated cells is excluded from profiles. Rating columns are parsed from strings; invalid and out-of-range values become missing and remain counted.",styles["Bodyx"]),Paragraph("Category statistics",styles["H2x"])]
rows=[["Column","Missing %","Invalid","Min","Max","Mean","Median","Std dev","Unique"]]
for c,d in stats["category_statistics"].items():rows.append([c,str(d["missing_percent"]),str(stats["invalid_value_counts"].get(c,0)),str(d["min"]),str(d["max"]),f"{d['mean']:.3f}" if d["mean"] is not None else "NA",f"{d['median']:.3f}" if d["median"] is not None else "NA",f"{d['std']:.3f}" if d["std"] is not None else "NA",str(d["unique_values"])])
t=Table(rows,colWidths=[74,51,42,39,39,54,54,54,45],repeatRows=1);t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),navy),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTSIZE",(0,0),(-1,-1),6.6),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,pale]),("GRID",(0,0),(-1,-1),.25,colors.HexColor("#D1DDD8")),("ALIGN",(1,1),(-1,-1),"RIGHT"),("VALIGN",(0,0),(-1,-1),"MIDDLE")]));story.append(t)
mapping=json.loads((ROOT/"config/category_mapping.json").read_text(encoding="utf-8"))
category_lines=[f"{key}: {value['name']}" for key,value in mapping.items()]
story += [PageBreak(),Paragraph("Purpose and limits",styles["H2x"]),Paragraph(f"These {stats['rows']:,} user records provide average Google ratings for {len(stats['category_columns'])} officially named attraction categories. The category key is documented by UCI Travel Review Ratings dataset 485 (CC BY 4.0); category labels are restored in this project. The data supports interest-based profile retrieval. It does not contain written reviews, trip narratives, trip duration, or destination-level ratings. The unnamed field includes {stats['unassigned_unnamed_values']} populated cells without a trustworthy category label, so those cells are counted and excluded from preference profiles.",styles["Bodyx"]),Paragraph("Documented category mapping",styles["H2x"]),Paragraph("<br/>".join(escape(line) for line in category_lines),styles["Bodyx"]),Paragraph("Preprocessing and profile generation",styles["H2x"]),Paragraph("UCI documents ratings on a 1–5 scale. Zero and other out-of-range values in the supplied export are treated as missing and included in invalid-value counts. Duplicate user IDs retain their first record. For each traveler, the pipeline calculates mean and median ratings over observed values, high and low category ratings, rating distribution, raw and normalized preference vectors, strength from score dispersion, and number of rated categories.",styles["Bodyx"]),Paragraph("Embedding and storage",styles["H2x"]),Paragraph("Profile documents include the UCI-documented category names, use the local Sentence Transformers model by default (Ollama and Gemini are alternatives), and are stored in ChromaDB. BM25 keyword search and dense vectors are combined with reciprocal rank fusion.",styles["Bodyx"])]
make_pdf(ROOT/"docs/Dataset_Details.pdf",story)
make_pdf(ROOT/"design/Design_Document.pdf",md_to_story(ROOT/"docs/Design_Document.md"))
make_pdf(ROOT/"docs/API_Documentation.pdf",md_to_story(ROOT/"docs/API_Documentation.md"))
make_pdf(ROOT/"docs/Evaluation_Report.pdf",md_to_story(ROOT/"docs/Evaluation_Report.md"))
sample_cases = ROOT/"docs/Sample_Test_Cases.md"
if not sample_cases.exists():
    sample_cases.write_text("""# Sample Test Cases\n\n| Case | Input | Expected behavior |\n|---|---|---|\n| Missing destination | Plan a three-day trip | Ask for destination; do not invent one. |\n| Anonymous category query | Search Category 5 | Return rating-profile evidence without assigning a travel meaning. |\n| Duration validation | Request 2 days | Return exactly two itinerary days. |\n| Invalid short query | `hi` | Return HTTP 422 with a useful validation message. |\n| Budget supplied | Add INR budget | State that feasibility is unknown because the dataset has no cost data. |\n| Provider unavailable | No valid provider key | Return the labeled deterministic offline itinerary. |\n""", encoding="utf-8")
make_pdf(ROOT/"docs/Sample_Test_Cases.pdf",md_to_story(sample_cases))

# One-page architecture artifact, drawn from the actual application flow.
architecture_dir=ROOT/"architecture"; architecture_dir.mkdir(parents=True,exist_ok=True)
pdf=canvas.Canvas(str(architecture_dir/"Architecture_Diagram.pdf"),pagesize=(720,520))
pdf.setTitle("TravelGenie AI Architecture")
pdf.setFillColorRGB(.043,.067,.094); pdf.rect(0,0,720,520,fill=1,stroke=0)
pdf.setFillColorRGB(.49,.88,.77); pdf.setFont("Helvetica-Bold",22); pdf.drawString(36,475,"TravelGenie AI | Implemented Architecture")
blocks=[("Traveler", "Natural-language priorities"),("Streamlit UI", "Retrieve first, plan after choice"),("FastAPI", "Recommendation + plan routes"),("Interest parser", "Query → UCI category IDs"),("Hybrid retrieval", "BM25 + semantic vectors + RRF"),("ChromaDB", "Mapped rating profiles"),("Ranked destination ideas", "Category ratings + curated interest tags"),("Dataset", "5,456 profiles · 24 rated categories")]
positions=[(250,420),(250,355),(250,290),(250,225),(250,160),(250,95),(500,225),(500,95)]
for (title,sub),(x,y) in zip(blocks,positions):
    pdf.setFillColorRGB(.07,.11,.15);pdf.roundRect(x-110,y-23,220,48,8,fill=1,stroke=0)
    pdf.setFillColorRGB(.49,.88,.77);pdf.setFont("Helvetica-Bold",11);pdf.drawCentredString(x,y+7,title)
    pdf.setFillColorRGB(.83,.88,.91);pdf.setFont("Helvetica",8);pdf.drawCentredString(x,y-8,sub)
pdf.setStrokeColorRGB(.49,.88,.77);pdf.setLineWidth(1.5)
for y1,y2 in [(397,378),(332,313),(267,248),(202,183),(137,118)]:pdf.line(360,y1,360,y2)
pdf.line(360,225,390,225);pdf.line(360,95,390,95)
pdf.setFillColorRGB(.78,.82,.86);pdf.setFont("Helvetica",9)
pdf.drawString(36,46,"Evidence scope: priority scores summarize matched category ratings, not destination ratings; no trip narratives, city scores, or prices.")
pdf.save()

# Editable presentation, sized for a 10 minute capstone talk.
slides=[
 ("TravelGenie AI","AI-powered travel planning and itinerary assistant\nDescribe the journey. AI plans the experience."),
 ("The planning problem","Travel plans must balance interests, pace, group size, duration and cost. A generic itinerary ignores personal preference."),
 ("Business need","Reduce planning effort while showing why recommendations fit a traveler and what evidence supports them."),
 ("A preference-aware recommender","Search traveler ratings for the priorities described in natural language. Show profile evidence and interest-matched destinations before asking for trip details."),
 ("What the dataset contains","5,456 traveler profiles\n24 UCI-documented place categories\nAverage Google ratings on a 1–5 scale\nNo written reviews or city-level ratings"),
 ("System architecture","CSV cleaning and profiles\nEmbedding and ChromaDB index\nFastAPI validation and LangGraph workflow\nHybrid retrieval and provider chain\nStreamlit planning studio"),
 ("From ratings to evidence","Map Category 3 to beaches\nMap Category 6 to museums\nMap Category 9 to restaurants\nRetrieve profiles with relevant observed ratings"),
 ("Hybrid profile retrieval","Map natural-language priorities to official category labels. Combine BM25 keyword and Chroma dense-vector rankings with reciprocal rank fusion; use category ratings to prioritize relevant profiles."),
 ("Planning workflow","Start with natural-language priorities. Retrieve similar rating profiles and category evidence; see up to three priority-ranked destination ideas based on matching category ratings and curated interest tags; then provide relationship, group size, duration and budget to continue into the existing itinerary flow. Budget feasibility stays unknown without price data."),
 ("Guardrails and provider fallback","Validate request size and fields. Optional hosted generation tries the configured OpenAI-compatible endpoint, then Gemini, then OpenAI. If hosted generation is disabled or unavailable, use the labeled deterministic offline path."),
 ("Itinerary and budget","The app produces a day-by-day flexible outline. It cannot calculate actual feasibility because no lodging, transport, attraction or meal prices are in the dataset."),
 ("Two-stage travel studio","Search for similar ratings and choose a destination idea first. Then enter trip length, budget, traveler group, and relationship; continue to the existing itinerary and map-place flow."),
 ("Evaluation approach","Four authored experience-search cases score 100% on the deterministic requirement checklist. DeepEval AnswerRelevancy is run locally with Ollama when CPU permits. These diagnostic cases are not independently validated travel ground truth."),
 ("Demo flow","Search a five-day beach, sightseeing, and food request. Review similar profiles and category ratings; compare Priority 1–3 destination ideas with their category-evidence scores; choose one, then enter budget and traveler details to continue the itinerary."),
 ("Challenges and learnings","The dataset provides attraction-category averages, not written trip stories or city ratings. Keep category evidence distinct from curated destination matches and live place lookup."),
 ("Next steps","Add a licensed destination-linked review corpus and verified price sources. Have travel experts review the benchmark, validate hosted-provider outputs, and test speech UX across browsers.")]
slides.extend([
 ("Technology appendix | Application foundation","Python and pandas clean the local dataset. Streamlit provides the interactive demo. FastAPI serves typed HTTP endpoints; Pydantic validates requests; Uvicorn runs the API. This all-Python stack speeds capstone development. A separate React frontend or larger Django stack would add setup the local demo does not need."),
 ("Technology appendix | Hybrid retrieval","BM25 handles exact words; Sentence Transformers creates compact local semantic vectors; ChromaDB persists those vectors. Reciprocal Rank Fusion combines rankings with different score scales. An optional CrossEncoder reranks candidates but is skipped in the quick path because it adds model startup and compute. Keyword-only and vector-only search each miss useful matches."),
 ("Technology appendix | Workflow and generation","A transparent rule-based classifier extracts known interests and trip fields without training labels. LangGraph makes the sequential understand → classify → retrieve → plan → validate workflow explicit. The deterministic offline planner is reproducible. Optional OpenAI-compatible, Gemini, and OpenAI providers can improve itinerary wording, but bring latency, key, cost, and factuality risks."),
 ("Technology appendix | Places and evaluation","OpenStreetMap is the no-key source for map listings; Google Places is optional for venue ratings and photos but needs an enabled, billed API key. DeepEval and an Ollama judge support authored diagnostics; pytest covers repeatable code checks. ReportLab and python-pptx generate submission documents. Neither evaluation scores nor category averages replace human-validated destination ground truth.")
])
prs=Presentation();prs.slide_width=Inches(13.333);prs.slide_height=Inches(7.5)
bg=RGBColor(11,17,24); mint_rgb=RGBColor(125,224,196); white=RGBColor(237,242,246); muted=RGBColor(157,174,185)
for idx,(title,body) in enumerate(slides):
    slide=prs.slides.add_slide(prs.slide_layouts[6]);fill=slide.background.fill;fill.solid();fill.fore_color.rgb=bg
    # Simple, editable typographic composition that matches the app. No fabricated metrics or charts.
    bar=slide.shapes.add_shape(1, Inches(.7), Inches(.68), Inches(.11), Inches(.48));bar.fill.solid();bar.fill.fore_color.rgb=mint_rgb;bar.line.fill.background()
    tx=slide.shapes.add_textbox(Inches(1.0), Inches(.62), Inches(11.5), Inches(.8));p=tx.text_frame.paragraphs[0];p.text=title;p.font.name="Aptos Display";p.font.size=Pt(34 if idx else 42);p.font.bold=True;p.font.color.rgb=white
    bodybox=slide.shapes.add_textbox(Inches(1.02), Inches(1.85), Inches(10.8), Inches(4.5));tf=bodybox.text_frame;tf.word_wrap=True
    for j,line in enumerate(body.split("\n")):
        p=tf.paragraphs[0] if j==0 else tf.add_paragraph();p.text=line;p.font.name="Aptos";p.font.size=Pt(23 if idx==0 else 21);p.font.color.rgb=mint_rgb if idx==0 else muted;p.space_after=Pt(20);p.level=0
    foot=slide.shapes.add_textbox(Inches(1.02), Inches(7.02), Inches(10), Inches(.2));p=foot.text_frame.paragraphs[0];p.text=f"VOYAGE AI     /     {idx+1:02d}";p.font.name="Aptos Mono";p.font.size=Pt(9);p.font.color.rgb=muted
prs.save(ROOT/"presentation/Project_Presentation.pptx")

# PDF companion to the editable presentation deck (landscape 16:9 pages).
from reportlab.pdfbase.pdfmetrics import stringWidth
presentation_dir=ROOT/"presentation"; presentation_dir.mkdir(parents=True,exist_ok=True)
deck_pdf=canvas.Canvas(str(presentation_dir/"Project_Presentation.pdf"),pagesize=(960,540))
deck_pdf.setTitle("TravelGenie AI Project Presentation")
for idx,(title,body) in enumerate(slides):
    deck_pdf.setFillColorRGB(.043,.067,.094);deck_pdf.rect(0,0,960,540,fill=1,stroke=0)
    deck_pdf.setFillColorRGB(.49,.88,.77);deck_pdf.roundRect(62,424,8,50,3,fill=1,stroke=0)
    deck_pdf.setFillColorRGB(.93,.95,.97);deck_pdf.setFont("Helvetica-Bold",31 if idx else 38)
    deck_pdf.drawString(90,437,title)
    deck_pdf.setFillColorRGB(.62,.68,.72)
    y=365
    for raw_line in body.split("\n"):
        words=raw_line.split();wrapped=[];current=""
        for word in words:
            candidate=(current+" "+word).strip()
            if stringWidth(candidate,"Helvetica",19)>790 and current:
                wrapped.append(current);current=word
            else:current=candidate
        if current:wrapped.append(current)
        for line in wrapped:
            deck_pdf.setFont("Helvetica",19);deck_pdf.drawString(92,y,line);y-=29
        y-=16
    deck_pdf.setStrokeColorRGB(.20,.29,.35);deck_pdf.line(62,49,898,49)
    deck_pdf.setFillColorRGB(.62,.68,.72);deck_pdf.setFont("Helvetica",9)
    deck_pdf.drawString(62,30,f"TRAVELGENIE AI   /   {idx+1:02d}   ·   CAPSTONE PROJECT")
    deck_pdf.showPage()
deck_pdf.save()
make_pdf(ROOT/"presentation/Presenter_Script.pdf",md_to_story(ROOT/"presentation/Presenter_Script.md"))
print(f"Generated PDF/PPT deliverables from {stats['rows']} cleaned rows.")
