# TravelGenie AI — Presenter Script and Technology Rationale

## How to present

The first 16 slides form the main capstone talk (about 8–10 minutes). Slides 17–20 are a technical appendix for questions. Speak naturally; the text below is a guide, not a script to read word for word.

## Main talk: slide-by-slide speaker notes

### Slide 1 — TravelGenie AI

“Hello. Our project is TravelGenie AI, a travel preference search and planning assistant. A traveler describes the kind of trip they want in ordinary language. The system retrieves similar rating profiles, explains the category-rating evidence, suggests destination ideas, and then continues into the existing itinerary workflow after the traveler chooses a destination.”

“The project is designed to run locally. Its core search and planning path does not require a paid language model or a Google Maps key.”

### Slide 2 — The planning problem

“Travelers often know what they enjoy before they know where to go. Searching manually across reviews, hotel pages, and attraction lists takes time. A generic itinerary can also miss the traveler’s priorities.”

“Our first stage focuses on preference discovery. We keep trip logistics for the second stage, after the traveler chooses a destination idea.”

### Slide 3 — Business need

“The goal is to reduce search effort and make recommendations explainable. Instead of only returning a city name, we show which place categories similar traveler profiles rated highly.”

“That explanation matters because our ratings are category-level evidence. We do not turn them into claims that a particular city, hotel, or restaurant received those ratings.”

### Slide 4 — A preference-aware recommender

“The traveler enters a natural-language request. The query is mapped to the dataset’s documented categories, similar profiles are retrieved, and category averages are summarized. We then show up to three ranked destination ideas using curated interest tags and the matched category ratings.”

“The priority score is evidence for matched categories. It is not a historical rating of a destination. Once the traveler picks an idea, the existing planning flow collects relationship, party size, trip length, and budget.”

### Slide 5 — What the dataset contains

“We use the UCI Travel Review Ratings dataset, with 5,456 traveler profiles and 24 average ratings for attraction categories. The CSV does not contain review text, named destinations, trip narratives, or prices. We restore category meanings from the UCI documentation.”

“We clean numeric values, treat zero sentinels and invalid values as missing, preserve missingness, and report dataset statistics. This lets us use the real evidence without overstating what it says.”

### Slide 6 — System architecture

“The implementation uses a Streamlit interface, a FastAPI service, a profile retrieval pipeline, and a persistent ChromaDB vector index. BM25 and dense semantic retrieval are combined before category-rating evidence and destination ideas are prepared.”

“After a destination is chosen, the existing itinerary path can use the deterministic offline planner and optional live place lookup. Each part has a clear boundary, so the user interface does not need to know the details of the retrieval implementation.”

### Slide 7 — From ratings to evidence

“The dataset’s category IDs are not self-explanatory, so we use the official mapping. For example, Category 3 means beaches, Category 6 means museums, and Category 9 means restaurants. A natural-language interest can therefore be connected to the right rating dimensions.”

“The mapping is explicit configuration rather than a model guessing what an anonymous column means. That is simpler to audit and safer for evidence.”

### Slide 8 — Hybrid profile retrieval

“We use two complementary search methods. BM25 finds exact words and category labels. Sentence Transformer embeddings can find related wording even when the query and profile use different phrases. Reciprocal rank fusion combines the ranked lists; category ratings then help prioritize profiles that match the requested interests.”

“A vector-only search can miss exact category terms; keyword-only search can miss semantic similarity. Combining them is a practical middle ground for this small, locally indexed corpus.”

### Slide 9 — Planning workflow

“The search-first path does not make the traveler provide a budget before showing preference evidence. It first retrieves profiles and produces priority-ranked destination ideas. The traveler then selects one and enters trip length, group size, relationship, and budget in the established planning flow.”

“The system can identify whether the entered budget is roughly budget-oriented or premium using a simple per-person-per-day rule, but it cannot prove affordability because the ratings data contains no prices.”

### Slide 10 — Guardrails and provider fallback

“Pydantic validates API request fields and ranges. The query guardrails reject overly long or suspicious inputs. The normal fast itinerary path is deterministic. If optional hosted generation is enabled, the provider manager tries configured services and falls back to the offline planner if they are unavailable.”

“That fallback keeps local demonstrations usable and avoids pretending an unavailable model produced an answer. API keys stay in the local environment file and are not part of the deliverables.”

### Slide 11 — Itinerary and budget

“After destination selection, the planner creates a day-by-day outline and checks that the number of days matches the request. It clearly marks price feasibility as unknown. That is preferable to inventing hotel or transport costs that are absent from the dataset.”

“Named stays and food can be looked up separately. OpenStreetMap is the no-key option and supplies map listings; Google Places is optional and can return ratings and photos when the API is enabled and configured.”

### Slide 12 — Two-stage travel studio

“The Streamlit home page supports preference search first and opens the trip dialog after a destination choice. FastAPI keeps search and planning behind a stable HTTP interface. This separation also lets us exercise the service independently from the UI.”

“The interface shows the evidence source and keeps destination-tag matching distinct from category ratings.”

### Slide 13 — Evaluation approach

“We have API and data-pipeline checks, plus a small project-authored DeepEval diagnostic set. The recent four-case run scored 100 percent on the deterministic requirement checklist and AnswerRelevancy. That is evidence that the outputs matched those four authored expectations; it is not proof of general travel quality or an official project grade.”

“G-Eval did not finish within the local timeout, so we do not report a G-Eval score. We need a larger independently reviewed benchmark for a strong quality claim.”

### Slide 14 — Demo flow

“I’ll enter a five-day request for beaches, sightseeing, and local food. We can inspect the retrieved traveler profiles and category ratings, then compare the Priority 1–3 destination ideas. The displayed score is based on matching categories, not a rating of each city. I’ll choose one destination and continue into the trip details.”

### Slide 15 — Challenges and learnings

“The biggest data challenge is that the source is a matrix of category averages, not a destination review corpus. That constrains what the system can answer. Our main design lesson is to preserve provenance: similarity evidence, category scores, curated destination matches, and live place data are different things.”

“A destination-linked review dataset and verified costs would enable stronger city comparisons and budget recommendations.”

### Slide 16 — Next steps

“Next we would add a licensed destination-linked dataset with clear ratings and prices, expand and independently validate the evaluation set, and gather expert review of the itinerary recommendations. We would also measure user experience and retrieval quality on more than four examples.”

“Thank you. I’m happy to explain the architecture and technology decisions.”

## Technical appendix: optional slide speaker notes

### Slide 17 — Application foundation

“The app is written in Python so the data pipeline, API, retrieval and interface can share the same models and utilities. pandas handles the dataset transformations. Streamlit lets us build an interactive demo without a separate frontend build. FastAPI and Pydantic provide documented, validated endpoints, and Uvicorn runs them as an ASGI service. React or Django could be appropriate for a larger product, but would add another application stack or framework features this local prototype does not need.”

### Slide 18 — Hybrid retrieval

“BM25 handles exact words. Sentence Transformers produces local semantic vectors, and ChromaDB stores and searches those vectors. Reciprocal Rank Fusion combines the independent rankings. This is more robust than either lexical-only or vector-only retrieval, while remaining explainable. A CrossEncoder is available for reranking but skipped in the fast search path because model startup increases latency.”

### Slide 19 — Workflow and generation

“The classifier is rules-based because the project has no labeled training set for intent classification. LangGraph keeps the sequential steps and their state explicit. The default itinerary is deterministic so a demo can run without keys or a network dependency. Optional OpenAI-compatible, Gemini and OpenAI calls can improve the wording, but add cost, latency, credentials and the need to check generated claims. This graph has workflow nodes; it is not a multi-agent debate system.”

### Slide 20 — Places and evaluation

“OpenStreetMap is the no-key option for live mapped places, while Google Places is an optional paid-capable route for ratings and photos. DeepEval provides LLM-assisted evaluation; Ollama can run the judge locally. pytest covers code behavior. ReportLab and python-pptx generate the submission PDFs and editable slides. Each tool has a distinct role, and none makes our small authored evaluation set equivalent to human-validated destination truth.”

## Technical appendix: technology decisions

### Python

Python is the implementation language for the data pipeline, retrieval services, API, workflow, and Streamlit app. Using one language avoids a separate integration layer between data science and application code and gives the project access to mature ML and web libraries. A JavaScript/TypeScript backend or Java service could also work, but would require rebuilding or wrapping the Python embedding and retrieval pipeline. Python is a project trade-off, not the only possible choice.

### pandas

pandas reads the CSV, discovers columns, cleans numeric ratings, calculates missingness and summary statistics, and writes processed files. It fits a dataset of this size and makes tabular transformations easy to inspect. SQL would be stronger for multi-user transactional data; Spark would add unnecessary distributed infrastructure for 5,456 rows; Polars could be faster but is not needed at this scale.

### NumPy

NumPy is listed in the Python environment as a numerical foundation used by the scientific and embedding ecosystem. The project’s own source modules do not directly import NumPy, so it should be described as a supporting dependency, not a core application component.

### Streamlit

Streamlit renders the interactive search, trip setup, results, and itinerary pages directly from Python. It lets a small team build and demonstrate a usable data application quickly. React or Vue would provide more control over a production-grade frontend, but they require a separate frontend build, state management, and API client. Streamlit is appropriate for this local capstone demo; it is not claimed to be the best choice for every production product.

### FastAPI, Pydantic, and Uvicorn

FastAPI exposes typed HTTP endpoints and interactive OpenAPI documentation. Pydantic validates request models, lengths, numeric ranges, and required fields. Uvicorn runs the ASGI app locally. Flask could serve APIs too, but would need more manual schema and API-documentation wiring. Django REST Framework is useful when the application needs Django’s larger user, database, and admin stack; this project does not. FastAPI’s validation and generated docs suit this service-oriented capstone.

### pandas profiles and JSONL

The cleaned tabular file remains easy to inspect as CSV. Per-traveler profiles are written as JSON Lines so they can be loaded incrementally and retain nested category ratings. A relational database would be useful for updates, concurrent users, and more structured reporting, but is heavier than needed for a local static corpus.

### BM25 (`rank-bm25`)

BM25 is the lexical retrieval component. It rewards exact terms and is a useful baseline for category names and concrete words in the query. It needs no trained language model and works locally. It cannot understand synonyms by itself, which is why it is paired with dense retrieval. A database full-text search engine could replace it at larger scale, but would add service and indexing overhead here.

### Sentence Transformers and `all-MiniLM-L6-v2`

Sentence Transformers creates dense vectors for profile documents and queries. The selected MiniLM model is compact enough for local use and avoids a mandatory hosted embedding bill or API key. Larger embedding models may improve retrieval on difficult language, but use more memory and time. Hosted embeddings can simplify model management and may perform better, but require credentials, network access, cost controls, and a privacy decision. Ollama and Gemini embedding paths are optional alternatives in the code.

### ChromaDB

ChromaDB persists profile vectors locally and retrieves semantically nearby records. This avoids an external vector database service for a single-machine capstone. A flat in-memory cosine search would be simpler at this dataset size but would have to recompute or reload the index each run. PostgreSQL with pgvector, Qdrant, or Pinecone could suit a larger or shared deployment; they introduce database setup, operational work, or hosted-service dependencies not needed for the local evaluation.

### Reciprocal rank fusion and optional cross-encoder

Reciprocal Rank Fusion combines independent BM25 and dense rankings without assuming their raw scores use the same scale. A weighted raw-score sum is another option, but score calibration is harder. A cross-encoder can rerank candidates by jointly reading query and profile text; it is optional because it adds model loading time and compute. For quick first searches, the app skips it.

### Rule-based intent classification

The classifier maps explicit words to interests, group type, pace, and some budget context. It is deterministic, cheap, inspectable, and does not require labeled training data. A supervised classifier could learn richer patterns but needs representative labeled examples and ongoing evaluation. An LLM could interpret ambiguous requests more flexibly, but adds latency, cost, provider failures, and a risk of inventing fields. The current classifier is intentionally transparent; its limitations include vocabulary and phrase coverage.

### LangGraph

LangGraph represents the planning workflow as stateful nodes: understand the request, classify preferences, retrieve profiles, plan, and validate duration/budget claims. It makes ordering and state handoff explicit and allows a node to be replaced or extended later. A plain Python function chain would be simpler for a fixed linear path; LangGraph is useful when demonstrating an extensible agent workflow. This implementation is a sequential graph, not a set of autonomous agents negotiating with one another.

### Deterministic planner and optional LLM providers

The deterministic planner is the default because it works offline, returns predictable structured results, and does not depend on keys. Optional text generation supports an OpenAI-compatible endpoint, Gemini, and OpenAI with fallback behavior. LLM generation can make itinerary text more natural, but may be slower, cost money, vary between runs, and produce unsupported facts. We keep the deterministic path as the reliable baseline and validate generated output before accepting it.

### OpenStreetMap and optional Google Places

The no-key place lookup uses OpenStreetMap geocoding and Overpass for mapped stays, food, and attractions. This keeps access free for a local demonstration and provides map links, but coverage, ratings, and photos are limited; public endpoints also have usage policies and can throttle requests. Google Places can return ratings, rating counts, and photos, but requires an enabled API, billing, and a restricted key, and can incur charges. It is optional and falls back to OpenStreetMap. Neither source supplies the historical traveler-to-destination linkage missing from the core ratings CSV.

### DeepEval, local Ollama judge, and pytest

DeepEval runs authored recommendation checks and optional LLM-based evaluation. A local Ollama judge avoids sending evaluation data to a hosted service and avoids per-call API charges, but can be slow on CPU; a hosted judge is a configurable alternative. The current benchmark is small and authored by the project, so scores are diagnostics rather than independent evidence of real-world quality. pytest is used for repeatable checks of cleaning, retrieval, guardrails, and API routes; it does not replace relevance evaluation with representative human-labeled queries.

### ReportLab and python-pptx

ReportLab generates PDF documentation and the architecture diagram programmatically. python-pptx creates an editable PowerPoint deck. They keep submission artifacts reproducible from the project source. Manually editing each export would make updates slower and prone to drift. These packages are for deliverable generation, not runtime travel recommendations.

### python-dotenv and environment configuration

python-dotenv reads local configuration such as provider choice and API keys from `.env`. This separates secrets and machine-specific settings from source code. Environment variables managed by a deployment platform are an alternative for hosted environments. The `.env` file must remain local and must never be committed.

## “Why not just use an LLM?”

“An LLM can phrase an answer, but it cannot recover missing destination labels or prices from this dataset. Retrieval gives us traceable rating evidence; explicit mappings make category meaning inspectable; validation and a deterministic fallback make the demo reproducible. We use hosted generation only as an optional planning enhancement, not as a substitute for evidence.”

## “Why are you showing destination ratings if the data has no city scores?”

“The score shown beside a destination is an average of the similar travelers’ ratings for categories that match the destination’s curated tags. It is a category-evidence score used to rank ideas, not a historical destination rating. A true destination comparison needs a dataset linking travelers or reviews to named destinations.”

## “What would you change for production?”

“I would license destination-linked reviews and price data, validate recommendations against a larger human-reviewed benchmark, add authentication and rate limiting, monitor retrieval and provider failures, and move persistent data to an operational database if multiple users need concurrent updates. I would also review map-provider terms, privacy, API-key restrictions, and cost before deployment.”
