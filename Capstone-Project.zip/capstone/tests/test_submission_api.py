"""Smoke coverage for the submission-facing API route family."""
from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_submission_api_index_and_destination_boundary():
    assert client.get("/").json()["name"] == "TravelGenie AI"
    result = client.get("/api/travel/destinations")
    assert result.status_code == 200
    assert result.json()["destinations"] == []

def test_submission_plan_asks_for_missing_destination():
    response = client.post("/api/travel/plan", json={"query":"Plan three relaxed days for two","duration_days":3,"travelers":2})
    assert response.status_code == 200
    assert response.json()["status"] == "needs_destination"

def test_submission_routes_are_documented():
    schema = client.get("/openapi.json").json()
    for path in ("/api/travel/plan", "/api/travel/search", "/api/travel/feedback", "/api/travel/destinations"):
        assert path in schema["paths"]
