"""Hybrid retrieval over destination-linked travel experiences when a labeled corpus is supplied."""
from __future__ import annotations

import json
import math
import threading
from pathlib import Path
from typing import Any

from rank_bm25 import BM25Okapi

from src.data_pipeline import PROCESSED
from src.retrieval import tokens

EXPERIENCE_PATH = PROCESSED / "travel_experiences.jsonl"
_lock = threading.Lock()
_index: dict[str, Any] = {}


def load_experiences(path: Path = EXPERIENCE_PATH) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(item, dict) or not item.get("destination") or not item.get("summary"):
            continue
        records.append(item)
    return records


def _filtered(records: list[dict[str, Any]], destination: str | None, travel_type: str | None,
              min_rating: float | None, max_budget: float | None) -> list[dict[str, Any]]:
    subset = records
    if destination:
        needle = destination.casefold().strip()
        subset = [r for r in subset if needle in str(r.get("destination", "")).casefold()]
    if travel_type:
        wanted = _normalize_travel_type(travel_type)
        subset = [r for r in subset if _normalize_travel_type(r.get("travel_type")) == wanted]
    if min_rating is not None:
        subset = [r for r in subset if _number(r.get("rating")) is not None and _number(r.get("rating")) >= min_rating]
    if max_budget is not None:
        subset = [r for r in subset if _number(r.get("budget")) is not None and _number(r.get("budget")) <= max_budget]
    return subset


def _number(value: Any) -> float | None:
    try:
        return float(value) if value is not None and str(value).strip() else None
    except (TypeError, ValueError):
        return None


def _normalize_travel_type(value: Any) -> str:
    text = str(value or "").casefold().strip()
    aliases = {
        "couples": "couple", "romantic": "couple", "honeymoon": "couple",
        "families": "family", "family trip": "family", "friends group": "friends",
        "group of friends": "friends", "solo travel": "solo", "business travel": "business",
    }
    return aliases.get(text, text)


def _record_text(record: dict[str, Any]) -> str:
    activities = record.get("activities", [])
    if isinstance(activities, list):
        activities = ", ".join(str(value) for value in activities)
    return " ".join(str(value) for value in (
        record.get("destination", ""), record.get("travel_type", ""), activities,
        record.get("summary", ""), record.get("traveler_group", ""),
    ) if value)


def _dense_scores(query: str, records: list[dict[str, Any]]) -> list[float] | None:
    """Use the configured embedding provider; cache corpus vectors until the file changes."""
    try:
        from src.rag.embeddings import get_embedding_provider
        path = EXPERIENCE_PATH
        signature = (str(path.resolve()), path.stat().st_mtime_ns, path.stat().st_size)
        with _lock:
            if _index.get("signature") != signature:
                docs = [_record_text(record) for record in records]
                embeddings = get_embedding_provider().embed(docs) if docs else []
                _index.update(signature=signature, embeddings=embeddings)
            doc_vectors = _index.get("embeddings", [])
        query_vector = get_embedding_provider().embed([query])[0]
        return [sum(float(a) * float(b) for a, b in zip(query_vector, vector)) for vector in doc_vectors]
    except Exception:
        return None


def search_experiences(query: str, *, destination: str | None = None, travel_type: str | None = None,
                       min_rating: float | None = None, max_budget: float | None = None,
                       top_k: int = 8) -> dict[str, Any]:
    """Filter destination records first, then rank them with keyword and optional vector similarity."""
    all_records = load_experiences()
    filtered = _filtered(all_records, destination, travel_type, min_rating, max_budget)
    filter_requested = any(value is not None for value in (destination, travel_type, min_rating, max_budget))
    if not filtered:
        return {
            "results": [], "total_experiences": len(all_records), "filters_applied": {
                "destination": destination, "travel_type": travel_type,
                "min_rating": min_rating, "max_budget": max_budget,
            },
            "status": "no_matching_experiences" if all_records else "experience_dataset_missing",
            "message": "No destination-linked experience records have been loaded. Import a reviewed travel-experience CSV to enable destination, travel type, rating, and budget filters." if not all_records else "No experience records matched these filters.",
        }
    docs = [_record_text(record) for record in filtered]
    query_tokens = tokens(query)
    bm25 = BM25Okapi([tokens(doc) for doc in docs])
    lexical = [float(score) for score in bm25.get_scores(query_tokens)]
    dense_all = _dense_scores(query, all_records)
    dense_by_object = {id(record): dense_all[i] for i, record in enumerate(all_records)} if dense_all else {}
    dense = [dense_by_object.get(id(record), 0.0) for record in filtered] if dense_all else [0.0] * len(filtered)

    def normalize(values: list[float]) -> list[float]:
        low, high = min(values, default=0), max(values, default=0)
        return [(value - low) / (high - low) if high > low else 0.0 for value in values]

    lexical_norm, dense_norm = normalize(lexical), normalize(dense)
    semantic_enabled = dense_all is not None
    ranked = []
    for i, record in enumerate(filtered):
        score = 0.4 * lexical_norm[i] + 0.6 * dense_norm[i] if semantic_enabled else lexical_norm[i]
        ranked.append((score, i))
    ranked.sort(reverse=True)
    results = []
    for score, i in ranked[:top_k]:
        results.append({**filtered[i], "retrieval_score": round(score, 5), "evidence": _record_text(filtered[i])})
    return {
        "results": results, "total_experiences": len(all_records), "matched_experiences": len(filtered),
        "filters_applied": {"destination": destination, "travel_type": travel_type, "min_rating": min_rating, "max_budget": max_budget},
        "status": "ok", "retrieval_method": "BM25 + configured embeddings" if semantic_enabled else "BM25 (embedding provider unavailable)",
    }
