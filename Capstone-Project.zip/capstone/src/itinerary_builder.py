"""Build a named, map-grounded day plan from already fetched place listings."""
from __future__ import annotations

from typing import Any


def _rank_sights(entries: list[dict[str, Any]], interests: list[str], travel_type: str) -> list[dict[str, Any]]:
    focus = " ".join(interests).casefold()
    group_preferences = {
        "couple": ("viewpoint", "garden", "historic", "museum", "gallery", "beach", "scenic", "waterfront"),
        "family": ("zoo", "aquarium", "theme park", "park", "garden", "museum", "beach", "attraction"),
        "friends": ("theme park", "beach", "viewpoint", "attraction", "arcade", "bowling", "market", "adventure"),
        "solo": ("museum", "gallery", "historic", "market", "garden", "viewpoint", "attraction"),
    }
    group_terms = group_preferences.get(str(travel_type or "").casefold(), ())

    def score(place: dict[str, Any]) -> int:
        category = str(place.get("category", "")).casefold()
        text = f"{place.get('name', '')} {place.get('description', '')} {category}".casefold()
        value = 0
        if "museum" in category or "museum" in text:
            value += 8
        if any(term in category for term in ("attraction", "viewpoint", "heritage")):
            value += 6
        if any(term in category for term in ("historic", "temple", "monument", "palace")):
            value += 5
        if any(term in category for term in ("park", "garden", "nature", "waterfall")):
            value += 4
        if any(term in focus for term in ("nature", "outdoor", "adventure")) and any(term in text for term in ("park", "garden", "nature", "viewpoint", "waterfall", "peak")):
            value += 4
        if any(term in focus for term in ("culture", "history", "art")) and any(term in text for term in ("museum", "historic", "temple", "palace", "gallery", "heritage")):
            value += 4
        value += sum(4 for term in group_terms if term in text)
        return value

    return sorted(entries, key=lambda place: (-score(place), str(place.get("name", "")).casefold()))


def build_named_itinerary(
    place_data: dict[str, Any], destination: str, days: int,
    interests: list[str], travel_type: str,
    day_trip_city: str | None = None,
) -> list[dict[str, Any]]:
    """Choose distinct mapped food and activity stops for each day.

    Listings remain map facts only: this function does not infer popularity,
    user ratings, opening hours, availability, or price feasibility.
    """
    primary = place_data.get(destination, {})
    if primary.get("error") or (not primary.get("sights") and not primary.get("food")):
        return []
    city_usage: dict[str, set[str]] = {}
    food_usage: dict[str, set[str]] = {}

    def take(entries: list[dict[str, Any]], used: set[str], prefer: str | None = None) -> dict[str, Any] | None:
        ordered = _rank_sights(entries, interests, travel_type)
        if prefer:
            preferred = [p for p in ordered if prefer in str(p.get("category", "")).casefold() or prefer in str(p.get("name", "")).casefold()]
            ordered = preferred + [p for p in ordered if p not in preferred]
        selected = next((p for p in ordered if p.get("id") not in used), None)
        if selected:
            used.add(selected.get("id", selected.get("name", "")))
        return selected

    def take_food(data: dict[str, Any], used: set[str], prefer_cafe: bool = False) -> dict[str, Any] | None:
        foods = list(data.get("food", []))
        if prefer_cafe:
            foods.sort(key=lambda p: (0 if "cafe" in str(p.get("category", "")).casefold() else 1, str(p.get("name", "")).casefold()))
        selected = next((p for p in foods if p.get("id") not in used), None)
        if selected:
            used.add(selected.get("id", selected.get("name", "")))
        return selected

    plan: list[dict[str, Any]] = []
    for day in range(1, int(days) + 1):
        day_trip = bool(day_trip_city and day == 2)
        city = day_trip_city if day_trip else destination
        data = place_data.get(city, {})
        city_usage.setdefault(city, set())
        food_usage.setdefault(city, set())
        if data.get("error") or (not data.get("sights") and not data.get("food")):
            plan.append({"day": day, "location": city, "day_trip": day_trip,
                         "morning": [{"text": f"No mapped named places were returned for {city}. Try searching again or choose another destination."}],
                         "afternoon": [], "evening": []})
            continue
        breakfast = take_food(data, food_usage[city], prefer_cafe=True)
        lunch = take_food(data, food_usage[city])
        dinner = take_food(data, food_usage[city])
        museum = take(data.get("sights", []), city_usage[city], prefer="museum")
        other_sight = take(data.get("sights", []), city_usage[city])
        shop = take(data.get("shopping", []), city_usage[city])
        evening_preference = {"couple": "cinema", "family": "cinema", "friends": "arcade", "solo": "arts centre"}.get(str(travel_type or "").casefold())
        late_activity = take(data.get("evening", []), city_usage[city], prefer=evening_preference)
        if not late_activity:
            late_activity = take(data.get("sights", []), city_usage[city], prefer="park")
        morning = []
        if day_trip:
            morning.append({"text": f"Start early and confirm current transport and journey time before setting out for {city}."})
        morning.append({"action": "Breakfast at", "place": breakfast} if breakfast else {"text": f"No named cafe is mapped in {city}; choose a breakfast stop near your route."})
        morning.append({"action": "Then visit", "place": museum or other_sight} if museum or other_sight else {"text": f"No named sights are currently mapped in {city}."})
        afternoon = [
            {"action": "Lunch at", "place": lunch} if lunch else {"text": f"No named restaurant is mapped for lunch in {city}."},
            {"action": "Explore", "place": shop or take(data.get("sights", []), city_usage[city])} if shop or data.get("sights") else {"text": "No second named stop was found."},
        ]
        evening = [
            {"action": "Dinner at", "place": dinner} if dinner else {"text": f"No named dinner venue is mapped in {city}."},
            {"action": "Then try", "place": late_activity} if late_activity else {"text": "No named game or evening venue is mapped; keep the evening flexible."},
        ]
        plan.append({"day": day, "location": city, "day_trip": day_trip, "morning": morning, "afternoon": afternoon, "evening": evening})
    return plan
