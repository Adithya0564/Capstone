"""Evaluation utilities; metrics require real question, reference, and judged output data."""
from __future__ import annotations
from typing import Any

def retrieval_coverage(results:list[dict[str,Any]], relevant_user_ids:set[str])->float|None:
    if not relevant_user_ids:return None
    retrieved={r.get("user_id") for r in results}
    return len(retrieved & relevant_user_ids)/len(relevant_user_ids)

def ragas_available()->bool:
    try: import ragas  # noqa: F401
    except ImportError:return False
    return True

def deepeval_available()->bool:
    try: import deepeval  # noqa: F401
    except ImportError:return False
    return True
