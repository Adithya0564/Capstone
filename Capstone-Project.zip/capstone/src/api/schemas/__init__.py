"""Pydantic request and response models for HTTP consumers."""
