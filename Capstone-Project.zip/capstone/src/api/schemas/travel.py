"""Public travel API models."""
from typing import Any
from pydantic import BaseModel, Field

class TravelPlanResponse(BaseModel):
    status: str
    destination: str | None = None
    duration_days: int | None = None
    itinerary: list[dict[str, Any]] = Field(default_factory=list)
    explanation: str | None = None
    warnings: list[str] = Field(default_factory=list)

class SearchResponse(BaseModel):
    results: list[dict[str, Any]]
    data_scope: str
