"""ASGI compatibility entry point for ``uvicorn src.api.main:app``."""
from src.main import app

__all__ = ["app"]
