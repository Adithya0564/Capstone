"""Submission-facing /api/travel routes, backed by the existing services."""
from __future__ import annotations
from typing import Any
from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/travel", tags=["Travel planning"])

class PlanRequest(BaseModel):
    query: str = Field(min_length=8, max_length=2000, examples=["Plan 4 relaxed days in Goa for two, with food and beaches"])
    destination: str | None = None
    duration_days: int | None = Field(default=None, ge=1, le=30)
    budget: float | None = Field(default=None, gt=0)
    currency: str = "INR"
    travelers: int = Field(default=1, ge=1, le=20)
    travel_type: str | None = None
    interests: list[str] = Field(default_factory=list, max_length=12)
    preferences: dict[str, Any] = Field(default_factory=dict)
    special_requirements: str | None = Field(default=None, max_length=1000)

class SearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=2000)
    destination: str | None = None
    travel_type: str | None = Field(default=None, max_length=40)
    min_rating: float | None = Field(default=None, ge=0, le=5)
    max_budget: float | None = Field(default=None, ge=0)
    filters: dict[str, Any] = Field(default_factory=dict)
    top_k: int = Field(default=8, ge=1, le=50)

class FeedbackRequest(BaseModel):
    user_query: str = Field(min_length=2, max_length=2000)
    rating: int = Field(ge=1, le=5)
    comment: str | None = Field(default=None, max_length=1000)
    accepted_categories: list[str] = Field(default_factory=list, max_length=24)

class PlacesRequest(BaseModel):
    destination: str = Field(min_length=2, max_length=160)
    multi_stop: bool = False

class AttractionsRequest(BaseModel):
    destination: str = Field(min_length=2, max_length=160)
    group_type: str = Field(pattern="^(couple|family|friends)$")

class TripPlacesRequest(BaseModel):
    destinations: list[str] = Field(min_length=1, max_length=3)

@router.get("/")
def api_root():
    return {"name": "Voyage AI", "docs": "/docs", "routes": ["/api/travel/plan", "/api/travel/search", "/api/travel/recommendations", "/api/travel/itinerary", "/api/travel/places", "/api/travel/attractions", "/api/travel/trip-places", "/api/travel/feedback", "/api/travel/destinations"]}

@router.post("/plan")
def plan(request: PlanRequest):
    from src.main import itinerary
    from src.planner import TravelRequest as InternalTravelRequest
    payload=request.model_dump()
    payload["group_size"]=payload.pop("travelers")
    context=[]
    if payload.get("travel_type"): context.append(f"Travel type: {payload['travel_type']}")
    if payload.get("preferences"): context.append(f"Preferences: {payload['preferences']}")
    if payload.get("special_requirements"): context.append(f"Special requirements: {payload['special_requirements']}")
    if context:
        context_text="\n".join(context)
        payload["query"]=(payload["query"][:max(0, 1999-len(context_text))]+"\n"+context_text)[:2000]
    allowed={"query","destination","duration_days","budget","currency","group_size","interests","travel_type"}
    return itinerary(InternalTravelRequest(**{k:v for k,v in payload.items() if k in allowed}))

@router.post("/itinerary")
def itinerary_route(request: PlanRequest):
    return plan(request)

@router.post("/places")
def places_route(request: PlacesRequest):
    from src.services.google_places_service import GooglePlacesError, search_stays_and_food
    from src.services.osm_places_service import OSMPlacesError
    from fastapi import HTTPException

    try:
        return search_stays_and_food(request.destination.strip(), request.multi_stop)
    except (GooglePlacesError, OSMPlacesError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

@router.post("/attractions")
def attractions_route(request: AttractionsRequest):
    from src.services.osm_places_service import OSMPlacesError, search_osm_attractions
    from fastapi import HTTPException

    try:
        return search_osm_attractions(request.destination.strip(), request.group_type)
    except OSMPlacesError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

@router.post("/trip-places")
def trip_places_route(request: TripPlacesRequest):
    from src.services.osm_places_service import OSMPlacesError, search_osm_trip_places

    results = {}
    for destination in request.destinations:
        normalized = destination.strip()
        if len(normalized) < 2:
            continue
        try:
            results[normalized] = search_osm_trip_places(normalized)
        except OSMPlacesError as exc:
            results[normalized] = {"error": str(exc), "sights": [], "food": [], "shopping": [], "evening": []}
    return {"results": results, "attribution": "© OpenStreetMap contributors"}

@router.post("/search")
def search(request: SearchRequest):
    from src.main import profiles
    from src.retrieval import retrieve
    from src.experience_retrieval import search_experiences
    profile_results = retrieve(
        request.query, profiles(), request.top_k,
        min_average=request.filters.get("min_average_rating"),
        max_average=request.filters.get("max_average_rating"),
    )
    min_rating = request.min_rating
    max_budget = request.max_budget
    experiences = search_experiences(
        request.query, destination=request.destination, travel_type=request.travel_type,
        min_rating=min_rating, max_budget=max_budget, top_k=request.top_k,
    )
    metadata_filter_requested = any(value is not None for value in (request.destination, request.travel_type, min_rating, max_budget))
    return {
        "results": experiences["results"] if metadata_filter_requested else profile_results,
        "similar_travelers": profile_results,
        "experience_search": experiences,
        "destination_filter_applied": bool(request.destination and experiences.get("total_experiences")),
        "metadata_filters_applied": experiences.get("filters_applied", {}),
        "data_scope": "Anonymous rating profiles support similarity search; destination, travel type, rating, and budget filters use the separate reviewed travel-experience corpus.",
    }

@router.post("/recommendations")
def recommendations(request: SearchRequest):
    return search(request)

@router.post("/feedback")
def feedback_route(request: FeedbackRequest):
    from src.main import feedback
    from src.main import Feedback
    return feedback(Feedback(**request.model_dump()))

@router.get("/destinations")
def destinations():
    from src.experience_retrieval import load_experiences
    values = sorted({str(row["destination"]).strip() for row in load_experiences() if str(row.get("destination", "")).strip()})
    if values:
        return {"destinations": values, "source": "imported travel experiences"}
    return {"destinations": [], "message": "The supplied rating-profile dataset contains no destination names. Import reviewed travel-experience records to populate this list."}
