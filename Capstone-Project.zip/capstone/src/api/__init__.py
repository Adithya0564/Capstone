"""Versioned HTTP API package."""
