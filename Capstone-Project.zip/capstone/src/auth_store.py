"""Local account and per-user chat persistence for the Streamlit app."""
from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any

DB_PATH = Path(os.getenv("TRAVELGENIE_AUTH_DB", "data/processed/travelgenie.sqlite3"))
PASSWORD_ITERATIONS = 600_000
LOCK_SECONDS = 15 * 60
MAX_FAILED_LOGINS = 5


class AuthError(ValueError):
    """Expected account-flow error safe to show in the UI."""


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


@contextmanager
def _db():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with _db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            name TEXT NOT NULL,
            password_salt BLOB NOT NULL,
            password_hash BLOB NOT NULL,
            role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
            verified INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL,
            failed_logins INTEGER NOT NULL DEFAULT 0,
            locked_until REAL
        );
        CREATE TABLE IF NOT EXISTS email_tokens (
            token_hash TEXT PRIMARY KEY,
            user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at REAL NOT NULL,
            used INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS conversations (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS messages (
            id TEXT PRIMARY KEY,
            conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
            user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            role TEXT NOT NULL CHECK(role IN ('user','assistant')),
            content TEXT NOT NULL,
            created_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_conversations_user_updated ON conversations(user_id, updated_at DESC);
        CREATE INDEX IF NOT EXISTS idx_messages_conversation_created ON messages(conversation_id, created_at);
        """)


def _password_digest(password: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS)


def _admin_emails() -> set[str]:
    return {item.strip().casefold() for item in os.getenv("ADMIN_EMAILS", "").split(",") if item.strip()}


def issue_verification_token(user_id: str) -> str:
    token = secrets.token_urlsafe(32)
    with _db() as conn:
        conn.execute("UPDATE email_tokens SET used=1 WHERE user_id=? AND used=0", (user_id,))
        conn.execute("INSERT INTO email_tokens(token_hash,user_id,expires_at) VALUES(?,?,?)",
                     (hashlib.sha256(token.encode()).hexdigest(), user_id, time.time() + 24 * 60 * 60))
    return token


def register_user(name: str, email: str, password: str) -> tuple[str, str]:
    init_db()
    name, email = name.strip(), email.strip().casefold()
    if not name or len(name) > 120:
        raise AuthError("Enter your name (up to 120 characters).")
    if len(email) > 254 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise AuthError("Enter a valid email address.")
    if len(password) < 10 or len(password) > 256:
        raise AuthError("Use a password between 10 and 256 characters.")
    user_id = str(uuid.uuid4())
    salt = secrets.token_bytes(16)
    digest = _password_digest(password, salt)
    role = "admin" if email in _admin_emails() else "user"
    try:
        with _db() as conn:
            conn.execute("INSERT INTO users(id,email,name,password_salt,password_hash,role,created_at) VALUES(?,?,?,?,?,?,?)",
                         (user_id, email, name, salt, digest, role, time.time()))
    except sqlite3.IntegrityError as exc:
        raise AuthError("An account with this email already exists. Try signing in or resend confirmation.") from exc
    return user_id, issue_verification_token(user_id)


def resend_verification(email: str) -> tuple[str, str] | None:
    init_db()
    with _db() as conn:
        row = conn.execute("SELECT id,verified FROM users WHERE email=? COLLATE NOCASE", (email.strip(),)).fetchone()
    if not row or row["verified"]:
        return None
    return row["id"], issue_verification_token(row["id"])


def verify_email(token: str) -> dict[str, Any] | None:
    init_db()
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    with _db() as conn:
        row = conn.execute("""
            SELECT u.id,u.email,u.name,u.role,t.token_hash
            FROM email_tokens t JOIN users u ON u.id=t.user_id
            WHERE t.token_hash=? AND t.used=0 AND t.expires_at>=?
        """, (token_hash, time.time())).fetchone()
        if not row:
            return None
        conn.execute("UPDATE email_tokens SET used=1 WHERE token_hash=?", (token_hash,))
        conn.execute("UPDATE users SET verified=1 WHERE id=?", (row["id"],))
        return {"id": row["id"], "email": row["email"], "name": row["name"], "role": row["role"]}


def login_user(email: str, password: str) -> dict[str, Any]:
    init_db()
    email = email.strip().casefold()
    now = time.time()
    result = None
    error = None
    with _db() as conn:
        row = conn.execute("SELECT * FROM users WHERE email=? COLLATE NOCASE", (email,)).fetchone()
        if not row:
            # Equalize unknown-account work with a password hash calculation.
            _password_digest(password, b"TravelGenieSalt!")
            error = "Email or password is incorrect."
        elif row["locked_until"] and row["locked_until"] > now:
            error = "Too many failed attempts. Try again in 15 minutes."
        else:
            correct = hmac.compare_digest(_password_digest(password, row["password_salt"]), row["password_hash"])
            if not correct:
                failures = row["failed_logins"] + 1
                locked_until = now + LOCK_SECONDS if failures >= MAX_FAILED_LOGINS else None
                conn.execute("UPDATE users SET failed_logins=?,locked_until=? WHERE id=?", (failures, locked_until, row["id"]))
                error = "Email or password is incorrect."
            elif not row["verified"]:
                error = "Please confirm your email before signing in. Use Resend confirmation if needed."
            else:
                role = "admin" if email in _admin_emails() else row["role"]
                conn.execute("UPDATE users SET failed_logins=0,locked_until=NULL,role=? WHERE id=?", (role, row["id"]))
                result = {"id": row["id"], "email": row["email"], "name": row["name"], "role": role}
    if error:
        raise AuthError(error)
    return result


def get_user(user_id: str) -> dict[str, Any] | None:
    init_db()
    with _db() as conn:
        row = conn.execute("SELECT id,email,name,role,verified FROM users WHERE id=?", (user_id,)).fetchone()
    if not row or not row["verified"]:
        return None
    role = "admin" if row["email"].casefold() in _admin_emails() else row["role"]
    if role == "admin" and row["role"] != "admin":
        with _db() as conn:
            conn.execute("UPDATE users SET role='admin' WHERE id=?", (row["id"],))
    return {"id": row["id"], "email": row["email"], "name": row["name"], "role": role}


def get_pending_user(user_id: str) -> dict[str, Any] | None:
    init_db()
    with _db() as conn:
        row = conn.execute("SELECT id,email,name FROM users WHERE id=? AND verified=0", (user_id,)).fetchone()
    return dict(row) if row else None


def create_conversation(user_id: str, title: str = "New conversation") -> str:
    init_db()
    conversation_id = str(uuid.uuid4())
    now = time.time()
    with _db() as conn:
        conn.execute("INSERT INTO conversations(id,user_id,title,created_at,updated_at) VALUES(?,?,?,?,?)",
                     (conversation_id, user_id, title.strip()[:100] or "New conversation", now, now))
    return conversation_id


def list_conversations(user_id: str) -> list[dict[str, Any]]:
    init_db()
    with _db() as conn:
        rows = conn.execute("SELECT id,title,created_at,updated_at FROM conversations WHERE user_id=? ORDER BY updated_at DESC", (user_id,)).fetchall()
    return [dict(row) for row in rows]


def add_message(user_id: str, conversation_id: str, role: str, content: str) -> None:
    if role not in {"user", "assistant"} or not content.strip() or len(content) > 20_000:
        raise AuthError("This chat message is invalid or too long.")
    init_db()
    now = time.time()
    with _db() as conn:
        exists = conn.execute("SELECT 1 FROM conversations WHERE id=? AND user_id=?", (conversation_id, user_id)).fetchone()
        if not exists:
            raise AuthError("That conversation is unavailable.")
        conn.execute("INSERT INTO messages(id,conversation_id,user_id,role,content,created_at) VALUES(?,?,?,?,?,?)",
                     (str(uuid.uuid4()), conversation_id, user_id, role, content.strip(), now))
        conn.execute("UPDATE conversations SET updated_at=? WHERE id=? AND user_id=?", (now, conversation_id, user_id))
        if role == "user":
            conn.execute("UPDATE conversations SET title=? WHERE id=? AND user_id=? AND title='New conversation'",
                         (content.strip()[:90], conversation_id, user_id))


def get_messages(user_id: str, conversation_id: str) -> list[dict[str, Any]]:
    init_db()
    with _db() as conn:
        rows = conn.execute("SELECT role,content,created_at FROM messages WHERE user_id=? AND conversation_id=? ORDER BY created_at",
                            (user_id, conversation_id)).fetchall()
    return [dict(row) for row in rows]


def admin_summary() -> dict[str, Any]:
    init_db()
    with _db() as conn:
        totals = conn.execute("""
            SELECT (SELECT COUNT(*) FROM users) AS users,
                   (SELECT COUNT(*) FROM users WHERE verified=1) AS verified_users,
                   (SELECT COUNT(*) FROM conversations) AS conversations,
                   (SELECT COUNT(*) FROM messages) AS messages
        """).fetchone()
        users = conn.execute("""
            SELECT u.id,u.name,u.email,u.role,u.verified,u.created_at,
                   (SELECT COUNT(*) FROM conversations c WHERE c.user_id=u.id) AS conversations,
                   (SELECT COUNT(*) FROM messages m WHERE m.user_id=u.id) AS messages
            FROM users u ORDER BY u.created_at DESC
        """).fetchall()
        recent = conn.execute("""
            SELECT c.updated_at,u.email,COUNT(m.id) AS message_count
            FROM conversations c JOIN users u ON u.id=c.user_id
            LEFT JOIN messages m ON m.conversation_id=c.id
            GROUP BY c.id ORDER BY c.updated_at DESC LIMIT 30
        """).fetchall()
    return {"totals": dict(totals), "users": [dict(row) for row in users], "recent_conversations": [dict(row) for row in recent]}

