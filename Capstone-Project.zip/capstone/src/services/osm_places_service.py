"""Small, user-triggered OpenStreetMap lookups for a local travel planner."""
from __future__ import annotations

import threading
import time
from typing import Any

import requests

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URL = "https://overpass-api.de/api/interpreter"
USER_AGENT = "TravelGenieCapstone/1.0 (local user-requested place search)"
_lock = threading.Lock()
_last_geocode_at = 0.0
_cache: dict[tuple[str, bool], tuple[float, dict[str, Any]]] = {}
_attraction_cache: dict[tuple[str, str], tuple[float, dict[str, Any]]] = {}
_trip_place_cache: dict[str, tuple[float, dict[str, Any]]] = {}
_CACHE_TTL_SECONDS = 3600
_CACHE_MAX_ENTRIES = 64


class OSMPlacesError(RuntimeError):
    """Raised when a public OpenStreetMap service is unavailable."""


def _geocode(destination: str) -> tuple[float, float] | None:
    global _last_geocode_at
    # The public Nominatim service requires no more than one request per second.
    with _lock:
        wait = 1.0 - (time.monotonic() - _last_geocode_at)
        if wait > 0:
            time.sleep(wait)
        try:
            response = requests.get(
                NOMINATIM_URL,
                params={"q": destination, "format": "jsonv2", "limit": 1},
                headers={"User-Agent": USER_AGENT},
                timeout=15,
            )
            response.raise_for_status()
            results = response.json()
        except (requests.RequestException, ValueError) as exc:
            raise OSMPlacesError("OpenStreetMap geocoding is temporarily unavailable.") from exc
        finally:
            _last_geocode_at = time.monotonic()
    if not results:
        return None
    try:
        return float(results[0]["lat"]), float(results[0]["lon"])
    except (KeyError, TypeError, ValueError, IndexError):
        return None


def _address(tags: dict[str, str]) -> str | None:
    full = tags.get("addr:full")
    if full:
        return full
    parts = [
        " ".join(part for part in (tags.get("addr:housenumber"), tags.get("addr:street")) if part),
        tags.get("addr:city") or tags.get("addr:suburb"),
        tags.get("addr:country"),
    ]
    value = ", ".join(part for part in parts if part)
    return value or None


def _query_stop(destination: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    point = _geocode(destination)
    if point is None:
        return [], []
    lat, lon = point
    query = f"""[out:json][timeout:20];
(
  nwr(around:10000,{lat},{lon})[tourism~"^(hotel|hostel|guest_house|motel|apartment|resort)$"];
)->.stays;
(
  nwr(around:10000,{lat},{lon})[amenity~"^(restaurant|cafe|fast_food)$"];
)->.food;
.stays out center 12;
.food out center 12;
"""
    try:
        response = requests.post(
            OVERPASS_URL,
            data={"data": query},
            headers={"User-Agent": USER_AGENT},
            timeout=30,
        )
        response.raise_for_status()
        elements = response.json().get("elements", [])
    except (requests.RequestException, ValueError) as exc:
        raise OSMPlacesError("OpenStreetMap place search is busy. Please try again shortly.") from exc

    stays: list[dict[str, Any]] = []
    food: list[dict[str, Any]] = []
    for element in elements:
        tags = element.get("tags") or {}
        name = tags.get("name")
        if not name:
            continue
        kind = element.get("type")
        osm_id = element.get("id")
        if not kind or not osm_id:
            continue
        center = element.get("center") or element
        item = {
            "id": f"{kind}/{osm_id}",
            "name": name,
            "address": _address(tags),
            "category": tags.get("tourism") or tags.get("amenity"),
            "cuisine": tags.get("cuisine"),
            "stars": tags.get("stars"),
            "price_range": tags.get("price_range"),
            "price_level": tags.get("price_level"),
            "website": tags.get("website"),
            "maps_url": f"https://www.openstreetmap.org/{kind}/{osm_id}",
            "latitude": center.get("lat"),
            "longitude": center.get("lon"),
        }
        (stays if tags.get("tourism") else food).append(item)
    return stays[:12], food[:12]


def search_osm_stays_and_food(destination: str, multi_stop: bool = False) -> dict[str, Any]:
    """Return nearby OSM listings with one-hour in-memory caching to limit public API load."""
    stops = [destination]
    if multi_stop:
        stops = [part.strip() for part in destination.split(",") if part.strip()][:4] or [destination]
    all_stays: list[dict[str, Any]] = []
    all_food: list[dict[str, Any]] = []
    notices = []
    for stop in stops:
        key = (stop.casefold(), False)
        with _lock:
            cached = _cache.get(key)
            if cached and cached[0] > time.monotonic():
                stays, food = cached[1]["stays"], cached[1]["food"]
            else:
                cached = None
        if cached is None:
            stays, food = _query_stop(stop)
            with _lock:
                if len(_cache) >= _CACHE_MAX_ENTRIES:
                    oldest = min(_cache, key=lambda cache_key: _cache[cache_key][0])
                    _cache.pop(oldest, None)
                _cache[key] = (
                    time.monotonic() + _CACHE_TTL_SECONDS,
                    {"stays": stays, "food": food},
                )
        if not stays and not food:
            notices.append(f"No tagged stays or food listings were found for {stop}.")
        for place in stays:
            all_stays.append({**place, "stop": stop if multi_stop else None})
        for place in food:
            all_food.append({**place, "stop": stop if multi_stop else None})
    return {
        "configured": True,
        "source": "OpenStreetMap",
        "attribution": "© OpenStreetMap contributors",
        "attribution_url": "https://www.openstreetmap.org/copyright",
        "notice": "Free community map data. OpenStreetMap does not provide Google ratings or venue photos.",
        "search_policy_url": "https://operations.osmfoundation.org/policies/nominatim/",
        "search_policy": "Searches run only when requested. The public geocoder is limited to one request per second and may throttle use.",
        "stays": all_stays,
        "food": all_food,
        "empty_notice": " ".join(notices),
    }


def search_osm_attractions(destination: str, group_type: str = "friends") -> dict[str, Any]:
    """Find named tourist sights in OSM and prioritize them for the traveling group."""
    group_type = group_type.casefold().strip()
    if group_type not in {"couple", "family", "friends"}:
        group_type = "friends"
    key = (destination.casefold().strip(), group_type)
    with _lock:
        cached = _attraction_cache.get(key)
        if cached and cached[0] > time.monotonic():
            return cached[1]

    point = _geocode(destination)
    if point is None:
        return {"source": "OpenStreetMap", "destination": destination, "group_type": group_type, "places": [], "notice": f"Could not find {destination} on the map."}
    lat, lon = point
    query = f"""[out:json][timeout:20];
(
  nwr(around:12000,{lat},{lon})[tourism~"^(attraction|museum|gallery|theme_park|zoo|aquarium|viewpoint|artwork|heritage)$"];
  nwr(around:12000,{lat},{lon})[historic];
  nwr(around:12000,{lat},{lon})[leisure~"^(park|garden|nature_reserve)$"];
  nwr(around:12000,{lat},{lon})[natural~"^(beach|peak|cave|waterfall)$"];
);
out center 80;
"""
    try:
        response = requests.post(
            OVERPASS_URL,
            data={"data": query},
            headers={"User-Agent": USER_AGENT},
            timeout=35,
        )
        response.raise_for_status()
        elements = response.json().get("elements", [])
    except (requests.RequestException, ValueError) as exc:
        raise OSMPlacesError("OpenStreetMap sights are temporarily unavailable. Please try again shortly.") from exc

    preferences = {
        "couple": {"viewpoint": 5, "garden": 4, "historic": 4, "museum": 3, "beach": 3, "attraction": 2, "park": 2, "gallery": 3},
        "family": {"zoo": 6, "aquarium": 6, "theme_park": 6, "park": 5, "museum": 4, "beach": 4, "attraction": 3, "garden": 3},
        "friends": {"theme_park": 5, "beach": 5, "viewpoint": 4, "attraction": 4, "historic": 3, "museum": 2, "park": 2, "gallery": 2},
    }[group_type]
    found: dict[str, dict[str, Any]] = {}
    for element in elements:
        tags = element.get("tags") or {}
        name = tags.get("name")
        kind = element.get("type")
        osm_id = element.get("id")
        if not name or not kind or not osm_id:
            continue
        category = tags.get("tourism") or tags.get("historic") or tags.get("leisure") or tags.get("natural") or "sight"
        tag_values = {
            tags.get("tourism"), tags.get("historic"), tags.get("leisure"), tags.get("natural"),
        }
        score = max((preferences.get(value, 0) for value in tag_values if value), default=0)
        if tags.get("historic"):
            score = max(score, preferences.get("historic", 0))
        found[f"{kind}/{osm_id}"] = {
            "id": f"{kind}/{osm_id}",
            "name": name,
            "category": category.replace("_", " ").title(),
            "description": tags.get("description") or tags.get("short_description"),
            "address": _address(tags),
            "website": tags.get("website"),
            "wikipedia": tags.get("wikipedia"),
            "maps_url": f"https://www.openstreetmap.org/{kind}/{osm_id}",
            "_score": score or 1,
        }
    places = sorted(found.values(), key=lambda item: (-item["_score"], item["name"].casefold()))[:24]
    for place in places:
        place.pop("_score", None)
    result = {
        "source": "OpenStreetMap",
        "destination": destination,
        "group_type": group_type,
        "places": places,
        "notice": "Popular mapped sights, ordered for your group type. OpenStreetMap does not provide popularity rankings, reviews, or venue photos.",
        "attribution": "© OpenStreetMap contributors",
        "attribution_url": "https://www.openstreetmap.org/copyright",
    }
    with _lock:
        _attraction_cache[key] = (time.monotonic() + _CACHE_TTL_SECONDS, result)
    return result


def search_osm_trip_places(destination: str) -> dict[str, Any]:
    """Collect named food, sights, shopping, and evening activities in one map query."""
    cache_key = destination.casefold().strip()
    with _lock:
        cached = _trip_place_cache.get(cache_key)
        if cached and cached[0] > time.monotonic():
            return cached[1]
    point = _geocode(destination)
    if point is None:
        return {"source": "OpenStreetMap", "destination": destination, "sights": [], "food": [], "shopping": [], "evening": [], "notice": f"Could not find {destination} on the map."}
    lat, lon = point
    query = (
        f"[out:json][timeout:25];(" 
        f"nwr(around:14000,{lat},{lon})[tourism~\"^(attraction|museum|gallery|theme_park|zoo|aquarium|viewpoint|artwork|heritage)$\"];"
        f"nwr(around:14000,{lat},{lon})[historic];"
        f"nwr(around:14000,{lat},{lon})[leisure~\"^(park|garden|nature_reserve|bowling_alley|amusement_arcade|escape_game|water_park)$\"];"
        f"nwr(around:14000,{lat},{lon})[natural~\"^(beach|peak|cave|waterfall)$\"];"
        f"nwr(around:14000,{lat},{lon})[shop~\"^(mall|department_store)$\"];"
        f"nwr(around:14000,{lat},{lon})[amenity~\"^(restaurant|cafe|fast_food|cinema|bowling_alley|nightclub|arts_centre)$\"];"
        f");out center 160;"
    )
    try:
        response = requests.post(OVERPASS_URL, data={"data": query}, headers={"User-Agent": USER_AGENT}, timeout=40)
        response.raise_for_status()
        elements = response.json().get("elements", [])
    except (requests.RequestException, ValueError) as exc:
        raise OSMPlacesError("Named places are temporarily unavailable from OpenStreetMap. Please try again shortly.") from exc

    collected: dict[str, list[dict[str, Any]]] = {"sights": [], "food": [], "shopping": [], "evening": []}
    seen: set[str] = set()
    for element in elements:
        tags = element.get("tags") or {}
        name, kind, osm_id = tags.get("name"), element.get("type"), element.get("id")
        if not name or not kind or not osm_id:
            continue
        unique_id = f"{kind}/{osm_id}"
        if unique_id in seen:
            continue
        seen.add(unique_id)
        tourism, historic = tags.get("tourism"), tags.get("historic")
        leisure, natural, shop, amenity = tags.get("leisure"), tags.get("natural"), tags.get("shop"), tags.get("amenity")
        category = tourism or historic or leisure or natural or shop or amenity or "sight"
        place = {
            "id": unique_id, "name": name, "category": category.replace("_", " ").title(),
            "description": tags.get("description") or tags.get("short_description"),
            "address": _address(tags), "cuisine": tags.get("cuisine"),
            "stars": tags.get("stars"), "price_range": tags.get("price_range"),
            "website": tags.get("website"), "maps_url": f"https://www.openstreetmap.org/{kind}/{osm_id}",
        }
        if amenity in {"restaurant", "cafe", "fast_food"}:
            collected["food"].append(place)
        elif shop in {"mall", "department_store"}:
            collected["shopping"].append(place)
        elif amenity in {"cinema", "bowling_alley", "nightclub", "arts_centre"} or leisure in {"bowling_alley", "amusement_arcade", "escape_game"}:
            collected["evening"].append(place)
        else:
            collected["sights"].append(place)
    for entries in collected.values():
        entries.sort(key=lambda item: item["name"].casefold())
    result = {
        "source": "OpenStreetMap", "destination": destination,
        **{key: entries[:40] for key, entries in collected.items()},
        "notice": "Named stops come from OpenStreetMap. Opening hours, availability, popularity, and prices may be missing or out of date; confirm before visiting.",
        "attribution": "© OpenStreetMap contributors",
        "attribution_url": "https://www.openstreetmap.org/copyright",
    }
    with _lock:
        _trip_place_cache[cache_key] = (time.monotonic() + _CACHE_TTL_SECONDS, result)
    return result
