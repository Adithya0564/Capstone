"""Application service abstractions."""
