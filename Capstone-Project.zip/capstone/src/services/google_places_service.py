"""Provider selection for live stay and food suggestions.

OpenStreetMap is the no-key default. Google Places can be selected explicitly;
Google content remains live-only and is never saved by this service.
"""
from __future__ import annotations

import os
from typing import Any

import requests

PLACES_SEARCH_URL = "https://places.googleapis.com/v1/places:searchText"
PLACES_MEDIA_URL = "https://places.googleapis.com/v1/{}"
FIELD_MASK = ",".join(
    (
        "places.id",
        "places.displayName",
        "places.formattedAddress",
        "places.rating",
        "places.userRatingCount",
        "places.googleMapsUri",
        "places.photos",
        "places.attributions",
    )
)


class GooglePlacesError(RuntimeError):
    """Raised when Google Places is configured but the live lookup fails."""


def _photo_uri(photo: dict[str, Any], api_key: str) -> str | None:
    name = photo.get("name")
    if not name:
        return None
    try:
        response = requests.get(
            PLACES_MEDIA_URL.format(name),
            params={"maxWidthPx": 480, "maxHeightPx": 320, "skipHttpRedirect": "true"},
            headers={"X-Goog-Api-Key": api_key},
            timeout=12,
        )
        response.raise_for_status()
        return response.json().get("photoUri")
    except (requests.RequestException, ValueError):
        return None


def _search_places(destination: str, kind: str, api_key: str) -> list[dict[str, Any]]:
    query, place_type = {
        "stays": (f"hotels and places to stay in {destination}", "hotel"),
        "food": (f"restaurants and local food in {destination}", "restaurant"),
    }[kind]
    response = requests.post(
        PLACES_SEARCH_URL,
        json={"textQuery": query, "includedType": place_type, "strictTypeFiltering": True, "pageSize": 4},
        headers={
            "Content-Type": "application/json",
            "X-Goog-Api-Key": api_key,
            "X-Goog-FieldMask": FIELD_MASK,
        },
        timeout=15,
    )
    try:
        response.raise_for_status()
    except requests.RequestException as exc:
        try:
            error_data = response.json().get("error", {})
        except ValueError:
            error_data = {}
        google_status = error_data.get("status")
        google_message = error_data.get("message")
        reason = f" {google_status}: {google_message}" if google_status or google_message else ""
        raise GooglePlacesError(
            f"Google Places returned HTTP {response.status_code}.{reason} Check that Places API (New) is enabled, billing is active, and this key is allowed to call it."
        ) from exc
    try:
        raw_places = response.json().get("places", [])
    except ValueError as exc:
        raise GooglePlacesError("Google Places returned an unreadable response.") from exc

    places = []
    for place in raw_places[:4]:
        photos = place.get("photos") or []
        photo = photos[0] if photos else {}
        places.append(
            {
                "id": place.get("id"),
                "name": (place.get("displayName") or {}).get("text", "Place"),
                "address": place.get("formattedAddress"),
                "rating": place.get("rating"),
                "rating_count": place.get("userRatingCount"),
                "maps_url": place.get("googleMapsUri"),
                "photo_url": _photo_uri(photo, api_key) if photo else None,
                "photo_attributions": photo.get("authorAttributions", []),
                "attributions": place.get("attributions", []),
            }
        )
    return places


def search_stays_and_food(destination: str, multi_stop: bool = False) -> dict[str, Any]:
    """Use OSM by default; fall back to it if the optional Google key is rejected."""
    from src.services.osm_places_service import search_osm_stays_and_food

    provider = os.getenv("PLACES_PROVIDER", "openstreetmap").strip().lower()
    if provider != "google":
        return search_osm_stays_and_food(destination, multi_stop)
    api_key = os.getenv("GOOGLE_MAPS_API_KEY", "").strip()
    if not api_key:
        result = search_osm_stays_and_food(destination, multi_stop)
        result["notice"] = "No Google key is configured; showing free OpenStreetMap listings without venue ratings or photos."
        return result
    stops = [destination]
    if multi_stop:
        stops = [stop.strip() for stop in destination.split(",") if stop.strip()][:4] or [destination]
    stays, food = [], []
    try:
        for stop in stops:
            for place in _search_places(stop, "stays", api_key):
                place["stop"] = stop if multi_stop else None
                stays.append(place)
            for place in _search_places(stop, "food", api_key):
                place["stop"] = stop if multi_stop else None
                food.append(place)
        return {"configured": True, "source": "Google Maps", "attribution": "Google Maps", "stays": stays, "food": food}
    except GooglePlacesError as exc:
        result = search_osm_stays_and_food(destination, multi_stop)
        result["notice"] = f"Google Places was unavailable ({exc}). Showing free OpenStreetMap listings; ratings and venue photos are not included."
        return result
