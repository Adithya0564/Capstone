"""Provider-neutral hosted text generation service."""
from src.llm.provider_manager import generate, provider_status

class LLMService:
    """Generate text through configured OpenAI-compatible or legacy providers."""
    def generate(self, prompt: str) -> tuple[str | None, str]:
        return generate(prompt)

    def status(self) -> list[dict]:
        return provider_status()
