"""Compact LangGraph workflow for extraction, profile retrieval, and planning."""
from __future__ import annotations
import os
from typing import Any, TypedDict
from src.planner import TravelRequest, classify_preferences, extract_request, deterministic_plan
from src.retrieval import retrieve

class PlanState(TypedDict, total=False):
    request: TravelRequest
    profiles: list[dict[str, Any]]
    parsed: dict[str, Any]
    preference_classification: dict[str, Any]
    evidence: list[dict[str, Any]]
    result: dict[str, Any]
    fast: bool

def build_graph():
    from langgraph.graph import StateGraph, START, END
    graph=StateGraph(PlanState)
    def understand(s): return {"parsed":extract_request(s["request"].query)}
    def classify(s):
        req=s["request"]
        return {"preference_classification":classify_preferences(
            req.query, interests=req.interests, travel_type=req.travel_type,
            group_size=req.group_size, budget=req.budget, duration_days=req.duration_days,
            currency=req.currency,
        )}
    def retrieve_profiles(s):
        q=s["request"].query
        return {"evidence":retrieve(q,s["profiles"],8,fast=s.get("fast",False))}
    def plan(s):
        req=s["request"]
        # Explicit fields take precedence; parsed fields fill omissions only.
        parsed={**s.get("parsed",{}),**req.model_dump(exclude={"query"},exclude_none=True),"query":req.query}
        result=deterministic_plan(TravelRequest(**parsed),s.get("evidence",[]))
        result["preference_classification"]=s.get("preference_classification",result.get("preference_classification",{}))
        return {"result":result}
    def critic(s):
        result=s["result"]
        if result.get("status")!="ready":return {"result":result}
        req=s["request"];expected=req.duration_days or 1
        revisions=max(0,min(2,int(os.getenv("MAX_ITINERARY_REVISIONS","2"))))
        for _ in range(revisions):
            if len(result.get("itinerary",[]))==expected:break
            result=deterministic_plan(req,result.get("similar_travelers",[]))
        duration_ok=len(result.get("itinerary",[]))==expected
        result["validation"]={
            "duration_feasible":duration_ok,
            "budget_feasible":None,
            "budget_reason":"No destination cost data is available." if req.budget else "No budget was supplied.",
            "dataset_grounding":"Anonymous category ratings only.",
            "suitability_prediction":"Unavailable without labeled trip outcomes.",
            "critic_flags":[] if duration_ok else ["Duration does not match the requested day count."],
        }
        return {"result":result}
    graph.add_node("query_understanding",understand)
    graph.add_node("travel_preference_classifier",classify)
    graph.add_node("profile_retrieval",retrieve_profiles)
    graph.add_node("itinerary_planning",plan)
    graph.add_node("duration_budget_critic",critic)
    graph.add_edge(START,"query_understanding");graph.add_edge("query_understanding","travel_preference_classifier")
    graph.add_edge("travel_preference_classifier","profile_retrieval")
    graph.add_edge("profile_retrieval","itinerary_planning");graph.add_edge("itinerary_planning","duration_budget_critic");graph.add_edge("duration_budget_critic",END)
    return graph.compile()

def execute(request:TravelRequest,profiles:list[dict[str,Any]],fast:bool=False)->dict[str,Any]:
    try:
        return build_graph().invoke({"request":request,"profiles":profiles,"fast":fast})["result"]
    except ImportError:
        found=retrieve(request.query,profiles,8,fast=fast)
        return deterministic_plan(request,found)
