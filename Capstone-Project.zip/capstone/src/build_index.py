"""Build the persistent Chroma vector index: python -m src.build_index"""
import logging
from src.data_pipeline import run_pipeline,read_profiles
from src.rag.vector_store import build
logging.basicConfig(level=logging.INFO)
def main():
    run_pipeline(); count=build(read_profiles()); print(f"Indexed {count} traveler profiles in Chroma.")
if __name__=="__main__":main()
