"""Environment-backed settings with safe defaults."""
from dataclasses import dataclass
import os

@dataclass(frozen=True)
class Settings:
    llm_api_key: str = os.getenv("LLM_API_KEY", "")
    llm_model: str = os.getenv("LLM_MODEL", "")
    llm_base_url: str = os.getenv("LLM_BASE_URL", "")
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    vector_db_path: str = os.getenv("VECTOR_DB_PATH", "./data/chroma")
    top_k: int = int(os.getenv("TOP_K", "8"))
    request_timeout: int = int(os.getenv("REQUEST_TIMEOUT", "30"))

settings = Settings()
