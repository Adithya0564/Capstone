"""Honest destination planning and provider-based itinerary generation."""
from __future__ import annotations
import os, re
from typing import Any
from pydantic import BaseModel, Field

class TravelRequest(BaseModel):
    query: str = Field(min_length=8, max_length=2000)
    destination: str | None = None
    duration_days: int | None = Field(default=None, ge=1, le=30)
    budget: float | None = Field(default=None, gt=0)
    currency: str = "INR"
    group_size: int = Field(default=1, ge=1, le=20)
    interests: list[str] = Field(default_factory=list, max_length=12)
    pace: str | None = None
    travel_type: str | None = Field(default=None, max_length=40)


_INTEREST_ALIASES = {
    "Food": ("food", "restaurant", "cafe", "café", "dining", "local cuisine", "street food"),
    "Culture": ("culture", "cultural", "history", "historic", "museum", "temple", "art", "heritage"),
    "Nature": ("nature", "park", "garden", "wildlife", "outdoors", "scenic", "waterfall"),
    "Adventure": ("adventure", "hiking", "trek", "water sports", "zipline", "cycling", "climbing"),
    "Beaches": ("beach", "beaches", "coast", "island", "snorkel", "diving"),
    "Shopping": ("shopping", "market", "mall", "boutique"),
    "Nightlife": ("nightlife", "club", "bar", "live music", "late night"),
    "Relaxation": ("relax", "relaxed", "relaxing", "spa", "quiet", "slow pace"),
}


def classify_preferences(query: str, *, interests: list[str] | None = None,
                         travel_type: str | None = None, group_size: int = 1,
                         budget: float | None = None, duration_days: int | None = None,
                         currency: str = "INR") -> dict[str, Any]:
    """Rule-based preference-classification node with explicit provenance per field."""
    text = query.casefold()
    detected = []
    for label, aliases in _INTEREST_ALIASES.items():
        if any(re.search(rf"(?<!\w){re.escape(alias)}(?!\w)", text) for alias in aliases):
            detected.append(label)
    normalized = []
    for value in (interests or []):
        value_text = str(value).casefold().strip()
        label = next((name for name, aliases in _INTEREST_ALIASES.items() if value_text == name.casefold() or any(value_text == alias for alias in aliases)), str(value).strip().title())
        if label and label not in normalized:
            normalized.append(label)
    for label in detected:
        if label not in normalized:
            normalized.append(label)

    explicit_type = (travel_type or "").strip()
    if explicit_type:
        party_type, party_source = explicit_type.title(), "request field"
    elif re.search(r"\b(couple|partner|honeymoon|romantic)\b", text):
        party_type, party_source = "Couple", "query terms"
    elif re.search(r"\b(family|families|kids|children|child)\b", text):
        party_type, party_source = "Family", "query terms"
    elif re.search(r"\b(friends|friend group|group of friends)\b", text):
        party_type, party_source = "Friends", "query terms"
    elif re.search(r"\b(solo|alone|by myself)\b", text):
        party_type, party_source = "Solo", "query terms"
    elif group_size > 1:
        party_type, party_source = "Group (relationship unspecified)", "traveler count"
    else:
        party_type, party_source = "Solo or unspecified", "traveler count"

    if re.search(r"\b(relax|relaxed|relaxing|slow|quiet|unhurried)\b", text):
        pace = "relaxed"
    elif re.search(r"\b(packed|busy|as much as possible|fast-paced)\b", text):
        pace = "packed"
    else:
        pace = "balanced"

    budget_tier = "unknown"
    per_person_day = None
    if budget and duration_days and group_size > 0 and currency.upper() == "INR":
        per_person_day = float(budget) / duration_days / group_size
        budget_tier = "premium" if per_person_day >= 8000 else "budget-friendly"
    return {
        "travel_type": party_type,
        "travel_type_source": party_source,
        "interests": normalized,
        "interests_source": "request fields and keyword rules",
        "pace": pace,
        "budget_tier": budget_tier,
        "budget_per_person_per_day": round(per_person_day, 2) if per_person_day is not None else None,
        "budget_tier_basis": "User-entered INR total divided by trip days and traveler count; this is not a price-feasibility prediction.",
        "classification_method": "transparent rule-based classification; no trained classifier is supplied",
    }

def guard_input(query: str) -> None:
    if not query or len(query.strip()) < 8:
        raise ValueError("Please describe your trip in at least 8 characters.")
    if len(query) > 2000: raise ValueError("Please keep the trip request under 2,000 characters.")
    if re.search(r"(?i)(ignore (all )?(previous|system) instructions|reveal (the )?(system prompt|api key)|sk-[A-Za-z0-9]{16,})", query):
        raise ValueError("That request contains content the travel planner cannot process.")

def extract_request(text: str) -> dict[str, Any]:
    days = re.search(r"\b(\d{1,2})\s*(?:day|days|night|nights)\b", text, re.I)
    budget = re.search(r"(?:₹|INR\s*)\s*([\d,]+)|\b(?:budget(?: of)?|under|within)\s*(?:₹|INR\s*)?([\d,]+)", text, re.I)
    dur = int(days.group(1)) if days else None
    amt = next((x for x in budget.groups() if x), None) if budget else None
    budget_value = float(amt.replace(",", "")) if amt else None
    classified = classify_preferences(text, budget=budget_value, duration_days=dur,
                                      group_size=2 if re.search(r"\b(two|couple|2 people|for 2)\b", text, re.I) else 1,
                                      currency="INR" if "₹" in text or "INR" in text.upper() else "unspecified")
    return {"duration_days": dur, "budget": budget_value,
            "currency": "INR" if "₹" in text or "INR" in text.upper() else "unspecified",
            "group_size": 2 if re.search(r"\b(two|couple|2 people|for 2)\b", text, re.I) else 1,
            "interests": classified["interests"], "pace": classified["pace"],
            "travel_type": classified["travel_type"] if classified["travel_type"] not in {"Solo or unspecified", "Group (relationship unspecified)"} else None}

def deterministic_plan(request: TravelRequest, retrieval: list[dict[str, Any]]) -> dict[str, Any]:
    days = request.duration_days or 1
    preference_classification = classify_preferences(
        request.query, interests=request.interests, travel_type=request.travel_type,
        group_size=request.group_size, budget=request.budget, duration_days=days, currency=request.currency,
    )
    category_count = len((retrieval[0].get("category_ratings") or {})) if retrieval else 0
    dataset_notice = (
        f"The supplied Travel Review Ratings dataset has {category_count} mapped attraction categories. "
        "Its per-traveler category averages can inform preference matching, but it has no trip narratives, named venues, or destination-level ratings."
        if category_count else
        "The supplied ratings dataset contains per-traveler attraction-category averages, but no trip narratives or destination-level ratings."
    )
    if not request.destination:
        trip_summary = [f"{days} day(s)"]
        if request.travel_type:
            trip_summary.append(request.travel_type.casefold())
        if request.group_size:
            trip_summary.append(f"{request.group_size} traveler(s)")
        if request.budget:
            trip_summary.append(f"{request.currency} {request.budget:,.0f} total")
        if preference_classification["interests"]:
            trip_summary.append("interests: " + ", ".join(preference_classification["interests"]))
        message = (
            f"I have your trip details ({' · '.join(trip_summary)}). Which destination should I plan for? "
            "I won't guess a location; the rating profiles do not identify destination-level experiences."
        )
        return {"status":"needs_destination", "message":message, "provider":"Offline Recommendation Engine", "similar_travelers": retrieval, "dataset_evidence": [dataset_notice], "preference_classification": preference_classification}
    # Generate a flexible structure from user-provided constraints, never claim live place facts.
    interests=request.interests or preference_classification["interests"]
    pace=request.pace or preference_classification["pace"]
    group_guidance = {
        "couple": "Prioritize scenic viewpoints, gardens, and relaxed shared experiences.",
        "family": "Prioritize family-friendly parks, museums, gardens, and attractions.",
        "friends": "Prioritize shared activities, markets, and lively group experiences.",
        "solo": "Prioritize walkable sights and flexible stops suited to independent travel.",
    }.get(str(request.travel_type or "").casefold(), "")
    itinerary=[]
    day_shapes=[
        ("get oriented near your stay", "keep the first outing short and easy", "choose a relaxed nearby dinner"),
        ("start with a locally recommended walk or district", "spend a longer block on your main interest", "try a different dining area"),
        ("make one main outing the focus", "leave a flexible rest or weather-change window", "choose a low-key evening activity"),
        ("visit a different area from the earlier days", "plan a second activity around your interests", "leave time for an unhurried meal"),
        ("revisit the part of town you enjoyed most", "choose a lighter alternative or a final activity", "keep the evening flexible before departure"),
    ]
    for day in range(1,days+1):
        morning,afternoon,evening=day_shapes[(day-1)%len(day_shapes)]
        focus=interests[(day-1)%len(interests)] if interests else "your chosen interests"
        itinerary.append({"day":day,
            "morning":f"Day {day}: {morning} in {request.destination}; include {focus} if it fits. Verify places and hours locally.",
            "afternoon":f"{afternoon.capitalize()}, paced for a {pace} trip with {request.group_size} traveler(s). {group_guidance}".strip(),
            "evening":f"{evening.capitalize()}; check current local details before choosing a venue."})
    budget = request.budget
    feasibility = "Unknown: the ratings dataset contains no travel prices. Check current lodging, transport, meals, and activity costs against your budget." if budget else "Add a budget. Cost feasibility remains unknown until current local prices are checked."
    return {"status":"ready", "destination":request.destination, "duration_days":days, "itinerary":itinerary,
            "budget_assessment":feasibility, "budget":budget, "provider":"Offline Recommendation Engine",
            "explanation":"The itinerary uses your stated destination and interests. Mapped category averages can provide preference evidence, but the dataset has no destination-level records or named past trips.",
            "similar_travelers":retrieval, "dataset_evidence":[dataset_notice],
            "preference_classification":preference_classification,
            "preference_score":round(sum((p["retrieval_score"] for p in retrieval[:3]))/max(1,min(3,len(retrieval))),4),
            "preference_score_basis":"Hybrid profile retrieval score, not a supervised itinerary suitability prediction."}
