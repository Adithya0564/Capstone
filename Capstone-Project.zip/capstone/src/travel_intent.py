"""Map natural-language travel interests to documented review-rating categories."""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=1)
def category_labels() -> dict[str, str]:
    path = ROOT / "config" / "category_mapping.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    return {
        f"category_{number.group(0)}": str(value["name"])
        for label, value in data.items()
        if (number := re.search(r"\d+", label))
    }


INTEREST_GROUPS: dict[str, tuple[str, ...]] = {
    "beaches": ("category_3",),
    "sightseeing": (
        "category_1", "category_4", "category_5", "category_6", "category_8",
        "category_15", "category_22", "category_23", "category_24",
    ),
    "local food": ("category_9", "category_12", "category_14", "category_19", "category_21"),
    "nightlife": ("category_10", "category_16"),
    "relaxation": ("category_2", "category_4", "category_20", "category_24"),
    "shopping": ("category_7",),
    "swimming": ("category_17",),
    "fitness": ("category_18",),
}

ALIASES = {
    "beaches": ("beach", "beaches", "coast", "coastline", "shore", "island", "seaside"),
    "sightseeing": ("sightseeing", "sight seeing", "sights", "landmarks", "attractions", "historic sites", "culture"),
    "local food": ("local food", "food", "cuisine", "dining", "restaurants", "restaurant", "eat", "cafes", "cafe"),
    "nightlife": ("nightlife", "night life", "bars", "pubs", "clubs", "dance clubs"),
    "relaxation": ("relaxation", "relaxing", "relax", "spa", "wellness", "quiet getaway"),
    "shopping": ("shopping", "malls", "mall", "markets"),
    "swimming": ("swimming", "pool", "pools"),
    "fitness": ("fitness", "gym", "gyms", "workout"),
}


def requested_categories(query: str) -> list[str]:
    """Return documented category IDs relevant to terms in the user's query."""
    text = re.sub(r"[^a-z0-9]+", " ", query.casefold()).strip()
    selected: list[str] = []

    def phrase_pattern(value: str) -> str:
        normalized = re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()
        return rf"\b{re.escape(normalized)}\b"

    def add(category_ids: tuple[str, ...] | list[str]) -> None:
        for category_id in category_ids:
            if category_id not in selected:
                selected.append(category_id)

    # Expand only explicit, documented preference groups.
    for group, aliases in ALIASES.items():
        if any(re.search(phrase_pattern(alias), text) for alias in aliases):
            add(INTEREST_GROUPS[group])

    # The lodging dimension has no broad interest group, but is useful for
    # accommodation questions and maps directly to UCI Category 13.
    if re.search(r"\b(hotel|hotels|lodging|lodgings|accommodation|accommodations|stay|stays)\b", text):
        add(["category_13"])

    # Also accept a literal mapped category, e.g. "viewpoints" or "bakeries".
    for category_id, label in category_labels().items():
        normalized = re.sub(r"[^a-z0-9]+", " ", label.casefold()).strip()
        if normalized and re.search(rf"\b{re.escape(normalized)}\b", text) and category_id not in selected:
            selected.append(category_id)

    return selected


def parse_duration_days(query: str) -> int | None:
    match = re.search(r"\b(\d{1,2})\s*[- ]?\s*(?:day|days|night|nights)\b", query, re.I)
    if match:
        return int(match.group(1))
    number_words = {
        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
        "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    }
    word_pattern = "|".join(number_words)
    word_match = re.search(rf"\b({word_pattern})\s*[- ]?\s*(?:day|days|night|nights)\b", query, re.I)
    return number_words[word_match.group(1).casefold()] if word_match else None


def matched_interests(query: str) -> list[str]:
    text = re.sub(r"[^a-z0-9]+", " ", query.casefold()).strip()
    result = []
    for group, aliases in ALIASES.items():
        if any(re.search(rf"\b{re.escape(re.sub('[^a-z0-9]+', ' ', alias.casefold()).strip())}\b", text) for alias in aliases):
            result.append(group)
    labels = category_labels()
    mapped_sightseeing = {"churches", "parks", "theatres", "museums", "zoos", "art galleries", "viewpoints", "monuments", "gardens"}
    mapped_food = {"restaurants", "burger/pizza shops", "juice bars", "bakeries", "cafes"}
    for label in labels.values():
        normalized = re.sub(r"[^a-z0-9]+", " ", label.casefold()).strip()
        if normalized and re.search(rf"\b{re.escape(normalized)}\b", text):
            if label in mapped_sightseeing and "sightseeing" not in result:
                result.append("sightseeing")
            if label in mapped_food and "local food" not in result:
                result.append("local food")
    return result
