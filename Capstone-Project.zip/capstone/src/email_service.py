"""SMTP confirmation and welcome emails; uses only standard-library modules."""
from __future__ import annotations

import os
import smtplib
from html import escape
from email.message import EmailMessage
from urllib.parse import urlencode


class EmailConfigurationError(RuntimeError):
    """Email transport is not configured or could not deliver a message."""


def _send(to_email: str, subject: str, text: str, html: str) -> None:
    host = os.getenv("SMTP_HOST", "").strip()
    sender = os.getenv("SMTP_FROM", "").strip()
    if not host or not sender:
        raise EmailConfigurationError("Email delivery is not configured. Set SMTP_HOST and SMTP_FROM in .env.")
    port = int(os.getenv("SMTP_PORT", "587"))
    username = os.getenv("SMTP_USER", "").strip()
    password = os.getenv("SMTP_PASSWORD", "")
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = to_email
    message.set_content(text)
    message.add_alternative(html, subtype="html")
    try:
        with smtplib.SMTP(host, port, timeout=20) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
            if username:
                smtp.login(username, password)
            smtp.send_message(message)
    except (OSError, smtplib.SMTPException) as exc:
        raise EmailConfigurationError("The confirmation email could not be sent. Check SMTP settings and try again.") from exc


def send_confirmation(to_email: str, name: str, token: str) -> None:
    base = os.getenv("APP_PUBLIC_URL", "http://localhost:8501").rstrip("/")
    url = f"{base}/?{urlencode({'verify': token})}"
    safe_name = escape(name)
    _send(
        to_email,
        "Confirm your TravelGenie AI account",
        f"Hi {name},\n\nConfirm your TravelGenie AI account using this link (valid for 24 hours):\n{url}\n\nIf you did not request this, you can ignore this email.",
        f"<p>Hi {safe_name},</p><p>Confirm your TravelGenie AI account (link valid for 24 hours):</p>"
        f"<p><a href=\"{url}\">Confirm my email</a></p><p>If you did not request this, ignore this email.</p>",
    )


def send_welcome(to_email: str, name: str) -> None:
    safe_name = escape(name)
    _send(
        to_email,
        "You’re signed up for TravelGenie AI",
        f"Hi {name},\n\nYou’re now signed up for TravelGenie AI. Sign in to explore traveler ratings, discover destination ideas, and plan a trip.\n\nHappy travels,\nTravelGenie AI",
        f"<p>Hi {safe_name},</p><p>You’re now signed up for TravelGenie AI.</p>"
        "<p>Sign in to explore traveler ratings, discover destination ideas, and plan a trip.</p>"
        "<p>Happy travels,<br>TravelGenie AI</p>",
    )
