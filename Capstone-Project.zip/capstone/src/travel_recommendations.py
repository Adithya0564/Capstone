"""Turn natural-language travel interests into rating evidence and destination ideas."""
from __future__ import annotations

from typing import Any

from src.retrieval import retrieve
from src.travel_intent import category_labels, matched_interests, parse_duration_days, requested_categories
from src.travel_intent import INTEREST_GROUPS

DESTINATION_CATALOG = [
    {"name": "Goa", "country": "India", "tags": ["beaches", "local food", "sightseeing", "nightlife", "relaxation"]},
    {"name": "Bali", "country": "Indonesia", "tags": ["beaches", "local food", "sightseeing", "relaxation"]},
    {"name": "Kyoto", "country": "Japan", "tags": ["sightseeing", "local food", "relaxation", "shopping"]},
    {"name": "Dubai", "country": "UAE", "tags": ["sightseeing", "local food", "shopping", "relaxation"]},
]

DATASET_SCOPE = (
    "The supplied Travel Review Ratings data contains average ratings by traveler and place category. "
    "It does not include review text, past itinerary summaries or trip narratives, trip duration, or destination-level ratings. "
    "The retrieved evidence therefore shows similar rating profiles and category preferences, not specific past trips."
)


def recommend_from_query(query: str, profiles: list[dict[str, Any]], top_k: int = 5,
                         *, fast: bool = False) -> dict[str, Any]:
    """Retrieve rating profiles for a query and explain the category evidence."""
    interest_groups = matched_interests(query)
    category_ids = requested_categories(query)
    labels = category_labels()
    profile_results = retrieve(query, profiles, top_k=top_k, fast=fast, use_reranker=False)

    category_evidence = []
    for category_id in category_ids:
        ratings = [
            float(result["category_ratings"][category_id])
            for result in profile_results
            if result.get("category_ratings", {}).get(category_id) is not None
        ]
        category_evidence.append({
            "category_id": category_id,
            "category": labels.get(category_id, category_id),
            "similar_profile_average": round(sum(ratings) / len(ratings), 2) if ratings else None,
            "profiles_with_rating": len(ratings),
            "profiles_above_4": sum(rating >= 4 for rating in ratings),
        })
    category_evidence.sort(key=lambda row: (row["similar_profile_average"] is None,
                                           -(row["similar_profile_average"] or 0), row["category"]))

    interest_highlights = []
    evidence_by_id = {item["category_id"]: item for item in category_evidence}
    for interest in interest_groups:
        ranked = [evidence_by_id[category_id] for category_id in INTEREST_GROUPS.get(interest, ())
                  if category_id in evidence_by_id and evidence_by_id[category_id]["similar_profile_average"] is not None]
        ranked.sort(key=lambda row: (-row["similar_profile_average"], row["category"]))
        interest_highlights.append({
            "interest": interest,
            "top_categories": ranked[:3],
            "category_count": len(ranked),
        })

    similar_profiles = []
    for index, profile in enumerate(profile_results, start=1):
        ratings = profile.get("category_ratings", {})
        profile_evidence = [
            {"category": labels.get(category_id, category_id), "rating": ratings[category_id]}
            for category_id in category_ids
            if ratings.get(category_id) is not None
        ]
        profile_evidence.sort(key=lambda row: (-row["rating"], row["category"]))
        similar_profiles.append({
            "profile_label": f"Similar traveler {index}",
            "similarity_score": profile.get("retrieval_score"),
            "average_rating": profile.get("average_rating"),
            "matched_category_ratings": profile_evidence,
            "highly_rated_categories": [
                {"category": labels.get(item["category"], item["category"]), "rating": item["rating"]}
                for item in profile.get("top_categories", [])
            ],
        })

    # Category ratings can support destination *ideas* via the curated catalog's
    # interest tags. They are not destination ratings; preserve that distinction
    # in the API fields and in the UI labels.
    category_interest = {
        category_id: interest
        for interest, category_ids in INTEREST_GROUPS.items()
        for category_id in category_ids
    }
    profile_category_means: dict[str, float] = {}
    for category_id in labels:
        values = [float(profile.get("category_ratings", {}).get(category_id))
                  for profile in profile_results
                  if profile.get("category_ratings", {}).get(category_id) is not None]
        if values:
            profile_category_means[category_id] = sum(values) / len(values)

    asks_recommendation = any(term in query.casefold() for term in (
        "recommend", "which options", "what options", "where should", "suggest", "limited budget",
        "which destination", "between destinations", "destination received", "compare destinations",
    ))
    if not interest_groups and asks_recommendation:
        inferred = {}
        for category_id, rating in profile_category_means.items():
            interest = category_interest.get(category_id)
            if interest:
                inferred.setdefault(interest, []).append(rating)
        interest_groups = sorted(inferred, key=lambda interest: (-sum(inferred[interest]) / len(inferred[interest]), interest))[:3]

    destinations = []
    explicit_destinations = [place for place in DESTINATION_CATALOG
                              if place["name"].casefold() in query.casefold()]
    candidate_places = explicit_destinations or DESTINATION_CATALOG
    for place in candidate_places:
        matched = [tag for tag in interest_groups if tag in place["tags"]]
        if not matched:
            continue
        matching_category_ids = [category_id for category_id, interest in category_interest.items()
                                 if interest in matched and category_id in profile_category_means]
        matching_ratings = [profile_category_means[category_id] for category_id in matching_category_ids]
        destinations.append({
            **place,
            "matched_interests": matched,
            "matched_categories": [labels[category_id] for category_id in matching_category_ids],
            "match_count": len(matched),
            "match_percent": round(len(matched) / len(interest_groups) * 100) if interest_groups else 0,
            "similar_traveler_category_rating": round(sum(matching_ratings) / len(matching_ratings), 2) if matching_ratings else None,
            "rating_basis": "average rating of matched attraction categories across retrieved similar traveler profiles; not a destination rating",
            "match_basis": "curated destination interest tags",
        })
    destinations.sort(key=lambda row: (
        -row["match_count"],
        -(row["similar_traveler_category_rating"] if row["similar_traveler_category_rating"] is not None else -1),
        row["name"],
    ))
    for priority, place in enumerate(destinations[:3], start=1):
        place["priority"] = priority
    destinations = destinations[:3]

    # Answer the common capstone questions directly, while keeping claims within
    # what the anonymous category-rating data can actually support.
    query_lower = query.casefold()
    asks_destination_comparison = any(term in query_lower for term in (
        "which destination", "compare destinations", "between destinations",
        "destination received", "destination has better", "destination rated better",
    ))
    asks_budget = any(term in query_lower for term in (
        "budget", "affordable", "cheap", "low cost", "limited budget",
    ))
    asks_experience = any(term in query_lower for term in (
        "experience", "rated highly", "highly rated", "rated well", "similar travelers",
    ))

    # Destination ratings are absent from the rating-profile dataset. Never
    # convert interest-tag overlap into a fabricated rating or winning city.
    if asks_destination_comparison:
        answer_kind = "destination_comparison_unavailable"
        answer = (
            "I can compare the ratings of similar travelers for the requested place categories, "
            "but this dataset does not link ratings to destinations, so it cannot identify a "
            "destination with better ratings. Destination ideas below are ranked by curated "
            "interest overlap, not traveler ratings."
        )
    elif asks_budget:
        answer_kind = "budget_recommendation_limited"
        lodging = evidence_by_id.get("category_13")
        all_category_means = []
        for category_id, label in labels.items():
            values = [float(profile.get("category_ratings", {}).get(category_id))
                      for profile in profile_results
                      if profile.get("category_ratings", {}).get(category_id) is not None]
            if values and category_id != "category_13":
                all_category_means.append((label, sum(values) / len(values)))
        all_category_means.sort(key=lambda item: (-item[1], item[0]))
        if lodging is not None and lodging["similar_profile_average"] is not None:
            answer = (
                f"Similar travelers rated hotels/other lodgings {lodging['similar_profile_average']:.2f}/5 "
                f"on average ({lodging['profiles_with_rating']} profiles). "
            )
        else:
            answer = "The retrieved profiles do not provide lodging ratings for this request. "
        if all_category_means:
            strongest = ", ".join(f"{label} ({score:.2f}/5)" for label, score in all_category_means[:3])
            answer += f"Their highest-rated activity categories were {strongest}. "
        answer += (
            "The data has no hotel names, individual prices, or trip budgets, so I cannot verify "
            "which accommodation or activity is affordable. Ranked destinations below are ideas "
            "matched to categories these travelers rated well; the displayed scores are category "
            "averages, not destination ratings. Check current prices separately."
        )
    else:
        answer_kind = "similar_traveler_experience" if asks_experience or interest_groups else "rating_profile_search"
        rated_categories = [item for item in category_evidence if item["similar_profile_average"] is not None]
        if interest_highlights:
            group_summaries = []
            for group in interest_highlights:
                top = group.get("top_categories", [])
                if top:
                    ratings = ", ".join(
                        f"{item['category']} ({item['similar_profile_average']:.2f}/5)"
                        for item in top[:3]
                    )
                    group_summaries.append(f"{group['interest']}: {ratings}")
            if group_summaries:
                answer = (
                    f"Among {len(profile_results)} similar traveler profiles, the highest recorded "
                    "ratings for your priorities are " + "; ".join(group_summaries) + ". "
                    "These are place-category averages, not written reviews or ratings for specific past trips. "
                    "The source does not record travel experiences or link ratings to destinations. "
                    "Ranked destination ideas use curated interest matches; they are not destination ratings."
                )
            else:
                answer = "I found similar rating profiles, but they have no usable ratings for the requested categories."
        elif rated_categories:
            strongest = sorted(rated_categories, key=lambda item: -item["similar_profile_average"])[:3]
            highlights = ", ".join(
                f"{item['category']} ({item['similar_profile_average']:.2f}/5)" for item in strongest
            )
            answer = (
                f"Among {len(profile_results)} similar traveler profiles, the strongest recorded "
                f"ratings for your requested categories are: {highlights}. These are category "
                "ratings, not ratings for a named destination or a specific past itinerary."
            )
        else:
            answer = (
                "I found similar rating profiles, but no usable ratings for the requested categories. "
                "Try specifying interests such as beaches, sightseeing, food, lodging, or shopping."
            )

    return {
        "status": "ok" if profile_results else "no_matches",
        "query": query,
        "duration_days": parse_duration_days(query),
        "matched_interests": interest_groups,
        "matched_categories": category_evidence,
        "interest_highlights": interest_highlights,
        "similar_profiles": similar_profiles,
        "destination_suggestions": destinations,
        "answer": answer,
        "answer_kind": answer_kind,
        "dataset_scope": DATASET_SCOPE,
        "profile_retrieval_method": (profile_results[0].get("dense_method") if profile_results else None),
        "profile_reranker": (profile_results[0].get("reranker_method") if profile_results else None),
    }
