"""Hosted model selection and fallback. Model IDs can be discovered from credentials."""
from __future__ import annotations
import logging, os
from typing import Any

log=logging.getLogger(__name__)

def _generation_temperature() -> float:
    """Read a shared generation temperature, defaulting to restrained variation."""
    try:
        value = float(os.getenv("LLM_TEMPERATURE", "0.3"))
    except (TypeError, ValueError):
        log.warning("Invalid LLM_TEMPERATURE; using 0.3")
        return 0.3
    if not 0.0 <= value <= 2.0:
        log.warning("LLM_TEMPERATURE must be between 0 and 2; using 0.3")
        return 0.3
    return value

def _gemini_client():
    from google import genai
    from google.genai import types
    timeout=int(os.getenv("REQUEST_TIMEOUT","30"))*1000
    return genai.Client(api_key=os.environ["GEMINI_API_KEY"],http_options=types.HttpOptions(timeout=timeout))

def _resolve_gemini_model(client)->str:
    configured=os.getenv("GEMINI_MODEL","").strip()
    if configured:return configured
    available=[]
    for item in client.models.list():
        name=getattr(item,"name","") or ""
        actions=getattr(item,"supported_actions",None) or []
        if name and "generateContent" in actions and "embedding" not in name.lower():
            available.append(name.removeprefix("models/"))
    if not available:raise RuntimeError("No generative text model is available to this Gemini credential")
    available.sort(key=lambda x:("flash" not in x.lower(),x))
    return available[0]

def _resolve_openai_model(client)->str:
    configured=os.getenv("OPENAI_MODEL","").strip()
    if configured:return configured
    blocked=("embedding","transcribe","audio","realtime","moderation","image","search","tts","whisper")
    available=[x.id for x in client.models.list().data if x.id.lower().startswith("gpt-") and not any(t in x.id.lower() for t in blocked)]
    if not available:raise RuntimeError("No candidate text generation model is available to this OpenAI credential")
    available.sort(key=lambda x:("mini" not in x.lower(),x))
    return available[0]

def generate(prompt:str)->tuple[str|None,str]:
    # Generic OpenAI-compatible endpoint (OpenRouter, vLLM gateway, etc.)
    # takes precedence when configured; legacy providers remain supported.
    temperature = _generation_temperature()
    if os.getenv("LLM_API_KEY") and os.getenv("LLM_MODEL"):
        try:
            from openai import OpenAI
            client=OpenAI(api_key=os.environ["LLM_API_KEY"],base_url=os.getenv("LLM_BASE_URL") or None,
                          timeout=int(os.getenv("REQUEST_TIMEOUT","30")),max_retries=int(os.getenv("MAX_RETRIES","2")))
            response=client.chat.completions.create(model=os.environ["LLM_MODEL"],messages=[{"role":"user","content":prompt}],temperature=temperature)
            content=response.choices[0].message.content
            if content:return content,"OpenAI-compatible API"
            log.warning("Configured OpenAI-compatible endpoint returned an empty response")
        except Exception as exc:log.warning("OpenAI-compatible request failed; trying configured legacy providers (%s)",type(exc).__name__)
    if os.getenv("GEMINI_API_KEY"):
        try:
            from google.genai import types
            client=_gemini_client(); model=_resolve_gemini_model(client)
            response=client.models.generate_content(model=model,contents=prompt,
                config=types.GenerateContentConfig(temperature=temperature))
            if response.text:return response.text,"Gemini"
            log.warning("Gemini returned an empty response")
        except Exception as exc:log.warning("Gemini request failed; trying next provider (%s)",type(exc).__name__)
    if os.getenv("OPENAI_API_KEY"):
        try:
            from openai import OpenAI
            client=OpenAI(api_key=os.environ["OPENAI_API_KEY"],timeout=int(os.getenv("REQUEST_TIMEOUT","30")),max_retries=int(os.getenv("MAX_RETRIES","2")))
            model=_resolve_openai_model(client)
            response=client.responses.create(model=model,input=prompt,temperature=temperature)
            if response.output_text:return response.output_text,"OpenAI Fallback"
            log.warning("OpenAI returned an empty response")
        except Exception as exc:log.warning("OpenAI request failed; using offline planner (%s)",type(exc).__name__)
    return None,"Offline Recommendation Engine"

def provider_status()->list[dict[str,Any]]:
    return [{"provider":"OpenAI-compatible API","configured":bool(os.getenv("LLM_API_KEY") and os.getenv("LLM_MODEL")),"model":"configured" if os.getenv("LLM_MODEL") else "not configured"},
            {"provider":"Gemini","configured":bool(os.getenv("GEMINI_API_KEY")),"model":"explicit" if os.getenv("GEMINI_MODEL") else "auto-discovered when called"},
            {"provider":"OpenAI","configured":bool(os.getenv("OPENAI_API_KEY")),"model":"explicit" if os.getenv("OPENAI_MODEL") else "auto-discovered when called"},
            {"provider":"Offline Recommendation Engine","configured":True,"model":"deterministic"}]

try:
    from langsmith import traceable
    generate=traceable(name="voyage_hosted_provider_generation",run_type="llm")(generate)
except ImportError:
    pass
