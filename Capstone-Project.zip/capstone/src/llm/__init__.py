"""Optional hosted language model integrations."""
