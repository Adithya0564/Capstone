"""Import a reviewed travel-experience CSV into the searchable JSONL corpus.

Required columns: destination, travel_type, rating, budget, activities, summary.
Optional columns: experience_id, traveler_group, duration_days, currency.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

from src.experience_retrieval import EXPERIENCE_PATH

REQUIRED = {"destination", "travel_type", "rating", "budget", "activities", "summary"}


def _number(value: str, *, minimum: float, maximum: float | None = None) -> float:
    parsed = float(value)
    if parsed < minimum or maximum is not None and parsed > maximum:
        raise ValueError("value outside supported range")
    return parsed


def import_csv(source: Path, destination: Path = EXPERIENCE_PATH) -> dict[str, Any]:
    accepted = []
    rejected = []
    with source.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = {str(header or "").strip().casefold() for header in (reader.fieldnames or [])}
        missing = REQUIRED - headers
        if missing:
            raise ValueError(f"CSV is missing required columns: {', '.join(sorted(missing))}")
        for row_number, raw in enumerate(reader, start=2):
            row = {str(key or "").strip().casefold(): str(value or "").strip() for key, value in raw.items()}
            try:
                destination_name = row["destination"]
                travel_type = row["travel_type"].casefold()
                summary = row["summary"]
                rating = _number(row["rating"], minimum=0, maximum=5)
                budget = _number(row["budget"], minimum=0)
                if not destination_name or not travel_type or not summary:
                    raise ValueError("destination, travel_type, and summary are required")
                activities = [value.strip() for value in row["activities"].replace("|", ";").split(";") if value.strip()]
                if not activities:
                    raise ValueError("at least one activity is required")
                accepted.append({
                    "experience_id": row.get("experience_id") or f"row-{row_number}",
                    "destination": destination_name,
                    "travel_type": travel_type,
                    "rating": rating,
                    "budget": budget,
                    "currency": row.get("currency") or "INR",
                    "activities": activities,
                    "summary": summary,
                    "traveler_group": row.get("traveler_group") or travel_type,
                    "duration_days": int(row["duration_days"]) if row.get("duration_days") else None,
                    "source_row": row_number,
                })
            except (KeyError, TypeError, ValueError) as exc:
                rejected.append({"row": row_number, "reason": str(exc)})
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_suffix(destination.suffix + ".tmp")
    temp.write_text("".join(json.dumps(record, ensure_ascii=False) + "\n" for record in accepted), encoding="utf-8")
    temp.replace(destination)
    return {"accepted": len(accepted), "rejected": rejected, "path": str(destination)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path", type=Path)
    args = parser.parse_args()
    print(json.dumps(import_csv(args.csv_path), indent=2))


if __name__ == "__main__":
    main()
