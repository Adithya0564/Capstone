"""Optional cross-encoder reranking over a small hybrid-retrieval candidate set."""
from __future__ import annotations
import os
from functools import lru_cache
from typing import Sequence

@lru_cache(maxsize=1)
def _model():
    from sentence_transformers import CrossEncoder
    model_name=os.getenv("RERANKER_MODEL", "").strip()
    if not model_name:return None
    return CrossEncoder(model_name, max_length=512)

def rerank(query:str,documents:Sequence[str])->list[float]|None:
    try:
        model=_model()
        if model is None:return None
        return [float(x) for x in model.predict([(query,doc) for doc in documents],show_progress_bar=False)]
    except Exception:
        return None
