"""Retrieval augmented generation components."""
