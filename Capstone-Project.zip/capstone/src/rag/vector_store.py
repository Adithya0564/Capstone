"""Persistent Chroma profile index. Failures leave lexical retrieval available."""
from __future__ import annotations
import os
import json
import logging
from pathlib import Path
from typing import Any
from src.retrieval import document
from src.rag.embeddings import get_embedding_provider
log=logging.getLogger(__name__)

def build(profiles:list[dict[str,Any]])->int:
    import chromadb
    path=Path(os.getenv("VECTOR_DB_PATH","./data/chroma")); path.mkdir(parents=True,exist_ok=True)
    client=chromadb.PersistentClient(path=str(path))
    # Resolve the embedder before replacing the persisted collection. If local
    # model loading fails, the existing index remains intact.
    embedder=get_embedding_provider()
    try:client.delete_collection("traveler_profiles")
    except Exception:pass
    collection=client.create_collection("traveler_profiles",metadata={
        "hnsw:space":"cosine", "expected_count":len(profiles), "build_status":"building"
    })
    batch=128
    for start in range(0,len(profiles),batch):
        block=profiles[start:start+batch]; docs=[document(p) for p in block]
        vectors=embedder.embed(docs)
        collection.add(ids=[p["user_id"] for p in block],documents=docs,embeddings=vectors,
                       metadatas=[{"average_rating":p["average_rating"],"preference_strength":p["preference_strength"],"rated_category_count":p["rated_category_count"],"top_categories":json.dumps(p["top_categories"])} for p in block])
        log.info("Indexed profiles %s/%s",min(start+batch,len(profiles)),len(profiles))
    collection.modify(metadata={"expected_count":len(profiles), "build_status":"complete"})
    return collection.count()

def semantic_results(text:str,top_k:int=32)->list[dict[str,Any]]:
    import chromadb
    path=Path(os.getenv("VECTOR_DB_PATH","./data/chroma"))
    if not path.exists():return []
    client=chromadb.PersistentClient(path=str(path))
    try:col=client.get_collection("traveler_profiles")
    except Exception:return []
    if col.metadata.get("build_status") != "complete" or col.count() != col.metadata.get("expected_count"):
        return []
    vector=get_embedding_provider().embed([text])[0]
    result=col.query(query_embeddings=[vector],n_results=min(top_k,col.count()),include=["metadatas","distances"])
    return [{"user_id":uid,"distance":dist,"metadata":meta} for uid,dist,meta in zip(result["ids"][0],result["distances"][0],result["metadatas"][0])]

def query(text:str,top_k:int=20)->list[dict[str,Any]]:
    import chromadb
    path=Path(os.getenv("VECTOR_DB_PATH","./data/chroma"))
    if not path.exists():return []
    client=chromadb.PersistentClient(path=str(path)); col=client.get_collection("traveler_profiles")
    vector=get_embedding_provider().embed([text])[0]
    result=col.query(query_embeddings=[vector],n_results=top_k,include=["metadatas","distances"])
    return [{"user_id":uid,"distance":dist,"metadata":meta} for uid,dist,meta in zip(result["ids"][0],result["distances"][0],result["metadatas"][0])]
