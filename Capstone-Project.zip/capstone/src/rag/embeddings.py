"""Configurable embedding providers for profile documents."""
from __future__ import annotations
import os
import json
import urllib.request
import urllib.error
from functools import lru_cache
from abc import ABC, abstractmethod
from typing import Sequence

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

class EmbeddingProvider(ABC):
    @abstractmethod
    def embed(self, texts: Sequence[str]) -> list[list[float]]: ...

class GeminiEmbeddingProvider(EmbeddingProvider):
    def __init__(self):
        from google import genai
        self.client=genai.Client(api_key=os.environ["GEMINI_API_KEY"])
        self.model=os.environ.get("EMBEDDING_MODEL") or "gemini-embedding-001"
    def embed(self,texts:Sequence[str])->list[list[float]]:
        out=[]
        for text in texts:
            r=self.client.models.embed_content(model=self.model,contents=text)
            out.append(list(r.embeddings[0].values))
        return out

class LocalEmbeddingProvider(EmbeddingProvider):
    """Sentence Transformers embedder. This is an embedding model, not a local LLM."""
    def __init__(self):
        from sentence_transformers import SentenceTransformer
        self.model=SentenceTransformer(os.environ.get("EMBEDDING_MODEL") or "sentence-transformers/all-MiniLM-L6-v2")
    def embed(self,texts:Sequence[str])->list[list[float]]:
        return self.model.encode(list(texts),normalize_embeddings=True,show_progress_bar=False).tolist()

class OllamaEmbeddingProvider(EmbeddingProvider):
    """Use an already-running local Ollama embedding model via its HTTP API."""
    def __init__(self):
        self.base_url=os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
        self.model=os.getenv("OLLAMA_EMBEDDING_MODEL", "nomic-embed-text")
    def embed(self,texts:Sequence[str])->list[list[float]]:
        vectors=[]
        # Moderate batches reduce HTTP overhead while keeping local memory use predictable.
        for start in range(0,len(texts),64):
            payload=json.dumps({"model":self.model,"input":list(texts[start:start+64])}).encode("utf-8")
            request=urllib.request.Request(self.base_url+"/api/embed",data=payload,headers={"Content-Type":"application/json"},method="POST")
            with urllib.request.urlopen(request,timeout=180) as response:
                result=json.loads(response.read().decode("utf-8"))
            vectors.extend(result["embeddings"])
        return vectors

@lru_cache(maxsize=1)
def get_embedding_provider()->EmbeddingProvider:
    kind=os.getenv("EMBEDDING_PROVIDER","local").lower()
    if kind=="ollama":
        return OllamaEmbeddingProvider()
    if kind=="gemini" and os.getenv("GEMINI_API_KEY"):
        try:return GeminiEmbeddingProvider()
        except Exception:pass
    try:
        return LocalEmbeddingProvider()
    except Exception as local_error:
        # The local Ollama route avoids paid API keys and commonly survives
        # Python dependency/version conflicts in Sentence Transformers.
        try:
            provider=OllamaEmbeddingProvider()
            provider.embed(["embedding provider health check"])
            return provider
        except Exception:
            raise RuntimeError("Could not initialize Sentence Transformers or the configured local Ollama embedding model") from local_error
