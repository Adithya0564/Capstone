"""Grounded hybrid profile retrieval with BM25-style lexical and vector ranking."""
from __future__ import annotations
import math
import re
from collections import Counter
from typing import Any
from rank_bm25 import BM25Okapi
from src.travel_intent import category_labels, requested_categories

TOKEN = re.compile(r"[a-z0-9_]+", re.I)

def document(profile: dict[str, Any]) -> str:
    labels = category_labels()
    def named(item: dict[str, Any]) -> str:
        key = str(item["category"])
        return f"{labels.get(key, key)} {item['rating']}"
    top = profile["top_categories"]
    low = profile["low_categories"]
    all_ratings = ", ".join(
        f"{labels.get(category, category)} {rating}"
        for category, rating in profile["category_ratings"].items() if rating is not None
    )
    return (f"Traveler {profile['user_id']}; average rating {profile['average_rating']}. "
            f"Attraction category ratings: {all_ratings}. "
            f"Highest rated: " + ", ".join(named(x) for x in top) +
            ". Lowest rated: " + ", ".join(named(x) for x in low) +
            f". Preference strength {profile['preference_strength']}.")

def tokens(text: str) -> list[str]:
    normalized=re.sub(r"(?i)\bcategory\s+(\d+)\b",r"category_\1",text)
    return [x.lower() for x in TOKEN.findall(normalized)]

def _cosine(a: Counter, b: Counter) -> float:
    dot = sum(v * b.get(k, 0) for k, v in a.items())
    na = math.sqrt(sum(v*v for v in a.values())); nb = math.sqrt(sum(v*v for v in b.values()))
    return dot / (na * nb) if na and nb else 0.0

def retrieve(query: str, profiles: list[dict[str, Any]], top_k: int = 8, semantic_weight: float = .65, keyword_weight: float = .35,
             min_average: float | None = None, max_average: float | None = None, fast: bool = False,
             use_reranker: bool | None = None) -> list[dict[str, Any]]:
    if not profiles: return []
    docs = [document(p) for p in profiles]
    q = Counter(tokens(query))
    tokenized = [tokens(d) for d in docs]
    doc_tokens = [Counter(d) for d in tokenized]
    lexical_raw = BM25Okapi(tokenized).get_scores(list(q)).tolist()
    dense_raw = [_cosine(q, d) for d in doc_tokens]
    dense_method = "sparse_fallback"
    if not fast:
        try:
            from src.rag.vector_store import semantic_results
            semantic = semantic_results(query, top_k=min(len(profiles), max(top_k * 4, 32)))
            if semantic:
                rank = {item["user_id"]: n for n, item in enumerate(semantic)}
                dense_raw = [1 / (1 + rank.get(p["user_id"], len(semantic))) for p in profiles]
                dense_method = "chromadb_embeddings"
        except Exception:
            pass
    def norm(scores: list[float]) -> list[float]:
        low=min(scores,default=0); high=max(scores,default=0)
        return [(s-low)/(high-low) if high>low else 0.0 for s in scores]
    lexical, dense = norm(lexical_raw), norm(dense_raw)
    # RRF uses each independent ranked list, then cross-reranks on query token coverage.
    order_l = sorted(range(len(profiles)), key=lambda i: lexical[i], reverse=True)
    order_d = sorted(range(len(profiles)), key=lambda i: dense[i], reverse=True)
    rank_l = {i: n for n, i in enumerate(order_l)}; rank_d = {i: n for n, i in enumerate(order_d)}
    candidates = []
    requested = requested_categories(query)
    requested.extend(
        f"category_{number}" for number in re.findall(r"(?i)\bcategory\s+(\d+)\b", query)
        if f"category_{number}" not in requested
    )
    for i, p in enumerate(profiles):
        avg = p["average_rating"]
        if min_average is not None and avg < min_average: continue
        if max_average is not None and avg > max_average: continue
        rrf = keyword_weight / (60 + rank_l[i]) + semantic_weight / (60 + rank_d[i])
        query_hits = sum(1 for t in q if t in doc_tokens[i]) / max(1, len(q))
        preference_match=(sum((p.get("category_ratings",{}).get(c) or 0)/5 for c in requested)/len(requested)) if requested else 0.0
        score = .45 * rrf + .20 * dense[i] + .15 * query_hits + .20 * preference_match
        candidates.append((score, i, rrf))
    candidates.sort(reverse=True)
    # Rerank only the highest hybrid-retrieval candidates. Cross-encoder failure leaves RRF order usable.
    pool=candidates[:min(len(candidates),max(top_k*4,32))]
    from src.rag.reranker import rerank
    reranker_enabled = not fast if use_reranker is None else use_reranker
    cross_scores=rerank(query,[docs[i] for _,i,_ in pool]) if reranker_enabled else None
    base_values=[score for score,_,_ in pool]
    def scale(values):
        low=min(values,default=0);high=max(values,default=0)
        return [(x-low)/(high-low) if high>low else 0.0 for x in values]
    base_scaled=scale(base_values)
    if cross_scores is not None:
        rerank_scaled=scale(cross_scores)
        if requested:
            preference=[sum((profiles[i].get("category_ratings",{}).get(c) or 0)/5 for c in requested)/len(requested) for _,i,_ in pool]
            final=[(.20*rerank_scaled[j]+.30*base_scaled[j]+.50*preference[j],pool[j][1],pool[j][2]) for j in range(len(pool))]
        else:
            final=[(.35*rerank_scaled[j]+.65*base_scaled[j],pool[j][1],pool[j][2]) for j in range(len(pool))]
        reranker_method="cross_encoder"
    else:
        final=[(base_scaled[j],pool[j][1],pool[j][2]) for j in range(len(pool))]
        reranker_method="fast_hybrid_score" if fast else ("hybrid_score_fallback" if reranker_enabled else "not_requested")
    final.sort(reverse=True)
    # Interest ratings boost relevant profiles; category ratings never become city ratings.
    output = []
    for score, i, rrf in final[:top_k]:
        p = profiles[i]
        output.append({**p, "retrieval_score": round(score, 5), "rrf_score": round(rrf, 6), "dense_method": dense_method,"reranker_method":reranker_method, "evidence": document(p)})
    return output
