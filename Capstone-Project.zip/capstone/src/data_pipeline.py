"""Inspect, clean, and build profiles from UCI's documented travel-rating categories."""
from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/google_review_ratings.csv"
PROCESSED = ROOT / "data/processed"


def category_columns(columns: list[str]) -> list[str]:
    found = []
    for name in columns:
        match = re.fullmatch(r"Category\s+(\d+)", str(name).strip(), re.I)
        if match:
            found.append((int(match.group(1)), name))
    return [name for _, name in sorted(found)]


def load_and_clean(path: Path = RAW) -> tuple[pd.DataFrame, dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}. Place google_review_ratings.csv under data/raw/.")
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    original_columns = [str(c).strip() for c in frame.columns]
    frame.columns = original_columns
    empty_columns = [c for c in frame if frame[c].astype(str).str.strip().eq("").all()]
    unnamed_columns = [c for c in frame.columns if re.fullmatch(r"Unnamed:\s*\d+", c, re.I)]
    unnamed_nonempty = {c: int(frame[c].astype(str).str.strip().ne("").sum()) for c in unnamed_columns}
    frame = frame.drop(columns=empty_columns)
    frame = frame.loc[:, [c not in unnamed_columns for c in frame.columns]]
    frame.columns = [re.sub(r"\s+", "_", c.strip()).lower() for c in frame.columns]
    if "user" not in frame.columns:
        raise ValueError("Required user identifier column was not detected.")
    cats = [c for c in frame.columns if re.fullmatch(r"category_\d+", c)]
    if not cats:
        raise ValueError("No Category N columns detected in the supplied dataset.")
    for col in cats:
        raw = frame[col].astype(str).str.strip()
        numeric = pd.to_numeric(raw.replace("", pd.NA), errors="coerce")
        invalid = raw.ne("") & numeric.isna()
        # UCI documents this dataset's rating scale as 1–5. In the supplied
        # export, 0 is used as an unrated/sentinel value; keep it missing rather
        # than letting it depress traveler means and interest evidence.
        out_of_range = numeric.notna() & ~numeric.between(1, 5)
        numeric = numeric.mask(out_of_range)
        frame[col] = numeric
        frame.attrs.setdefault("invalid_values", {})[col] = int(invalid.sum() + out_of_range.sum())
    frame["user"] = frame["user"].astype(str).str.strip()
    duplicate_ids = int(frame["user"].duplicated(keep=False).sum())
    duplicate_rows = int(frame.duplicated(subset=["user"], keep="first").sum())
    if duplicate_rows:
        frame = frame.drop_duplicates(subset=["user"], keep="first")
    valid_rows = frame["user"].ne("")
    frame = frame.loc[valid_rows].reset_index(drop=True)
    stats = {
        "dataset_name": path.name, "source_file": path.name,
        "rows_raw": int(len(pd.read_csv(path, dtype=str, keep_default_na=False))),
        "rows": int(len(frame)), "columns_raw": len(original_columns),
        "columns": list(frame.columns), "category_columns": cats,
        "empty_columns_removed": empty_columns,
        "unnamed_columns_removed": unnamed_nonempty,
        "unassigned_unnamed_values": sum(unnamed_nonempty.values()),
        "duplicate_user_rows_removed": duplicate_rows,
        "duplicate_user_records": duplicate_ids,
        "missing_by_category": {c: {"count": int(frame[c].isna().sum()), "percent": round(float(frame[c].isna().mean() * 100), 3)} for c in cats},
        "invalid_value_counts": frame.attrs.get("invalid_values", {}),
        "category_statistics": {}
    }
    for c in cats:
        s = frame[c].dropna()
        stats["category_statistics"][c] = {
            "dtype": "numeric", "missing_count": int(frame[c].isna().sum()),
            "missing_percent": round(float(frame[c].isna().mean() * 100), 3),
            "min": None if s.empty else float(s.min()), "max": None if s.empty else float(s.max()),
            "mean": None if s.empty else float(s.mean()), "median": None if s.empty else float(s.median()),
            "std": None if len(s) < 2 else float(s.std()), "unique_values": int(s.nunique())
        }
    return frame, stats


def create_profiles(frame: pd.DataFrame, stats: dict[str, Any]) -> list[dict[str, Any]]:
    cats = stats["category_columns"]
    result = []
    for _, row in frame.iterrows():
        values = {c: (None if pd.isna(row[c]) else float(row[c])) for c in cats}
        observed = {c: v for c, v in values.items() if v is not None}
        if not observed:
            continue
        ranked = sorted(observed.items(), key=lambda item: (-item[1], item[0]))
        avg = sum(observed.values()) / len(observed)
        variance = sum((v - avg) ** 2 for v in observed.values()) / len(observed)
        strength = min(1.0, math.sqrt(variance) / 2.5)
        vector = [values[c] for c in cats]
        result.append({
            "user_id": str(row["user"]), "category_ratings": values,
            "average_rating": round(avg, 4), "median_rating": round(float(pd.Series(list(observed.values())).median()), 4),
            "top_categories": [{"category": k, "rating": round(v, 3)} for k, v in ranked[:5]],
            "low_categories": [{"category": k, "rating": round(v, 3)} for k, v in ranked[-5:]],
            "rating_distribution": {str(i): sum(1 for v in observed.values() if int(v) == i) for i in range(6)},
            "preference_vector": vector,
            "normalized_preference_vector": [None if x is None else round(x / 5, 4) for x in vector],
            "preference_strength": round(strength, 4), "rated_category_count": len(observed)
        })
    return result


def run_pipeline(path: Path = RAW) -> dict[str, Any]:
    PROCESSED.mkdir(parents=True, exist_ok=True)
    frame, stats = load_and_clean(path)
    mapping_path=ROOT/"config/category_mapping.json"
    try:
        mapping=json.loads(mapping_path.read_text(encoding="utf-8")) if mapping_path.exists() else {}
    except (json.JSONDecodeError,OSError):
        mapping={}
    for col in stats["category_columns"]:
        number=col.removeprefix("category_")
        display=f"Category {number}"
        mapping.setdefault(display,{"name":col,"description":f"Anonymous rating dimension {display}; semantic meaning is not supplied."})
    mapping_path.parent.mkdir(parents=True,exist_ok=True)
    mapping_path.write_text(json.dumps(mapping,indent=2),encoding="utf-8")
    frame.to_csv(PROCESSED / "cleaned_reviews.csv", index=False)
    profiles = create_profiles(frame, stats)
    with (PROCESSED / "traveler_profiles.jsonl").open("w", encoding="utf-8") as f:
        for profile in profiles:
            f.write(json.dumps(profile, ensure_ascii=False) + "\n")
    stats["profile_count"] = len(profiles)
    (PROCESSED / "dataset_statistics.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    return stats


def read_profiles() -> list[dict[str, Any]]:
    path = PROCESSED / "traveler_profiles.jsonl"
    if not path.exists():
        run_pipeline()
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]

if __name__ == "__main__":
    print(json.dumps(run_pipeline(), indent=2))
