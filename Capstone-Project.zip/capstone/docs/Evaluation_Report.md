# Evaluation Report

Run date: 2026-10-10. This report summarizes reproducible diagnostic evaluation, not a capstone grade. The seven example queries and their expected responses are authored for the project and have not been independently reviewed by a travel-domain expert.

## Current evaluation results

| Metric | Mean | Cases | What it measures |
|---|---:|---:|---|
| DeepEval RequirementChecklist | 100.00% | 7 | Literal checks for response behavior, content, and required caveats |
| RAGAS SemanticSimilarity | 73.45% | 7 | Embedding similarity between the actual user-facing answer and authored reference |
| DeepEval AnswerRelevancy / GEval | Not rerun | — | LLM judge calls previously exceeded local time limits; no current score claimed |

The deterministic checklist report is [`evaluation/deepeval_requirement_scores.json`](../evaluation/deepeval_requirement_scores.json). It checks all seven authored cases, including the three capstone question types: similar experiences, destination comparison, and limited-budget choices. The checks require limitation disclosures and ranked destination suggestions where appropriate. Re-run with:

```powershell
.venv\Scripts\python.exe -m evaluation.deepeval_evaluation --checklist-only --output evaluation/deepeval_requirement_scores.json
```

RAGAS 0.4.3 `SemanticSimilarity` compared the actual recommendation answer, category-rating evidence, and destination suggestions to the authored expected response. Per-case scores were 83.04%, 70.27%, 69.18%, 72.65%, 72.06%, 70.32%, and 76.60%. The score is not faithfulness, factuality, retrieval precision/recall, recommendation quality, or traveler satisfaction. It is stored in [`evaluation/ragas_scores.json`](../evaluation/ragas_scores.json) and can be reproduced without a hosted judge:

```powershell
.venv\Scripts\python.exe -m evaluation.ragas_evaluation --semantic-only
```

Do not average these two metrics into a single project score: they measure different properties and one is a deterministic checklist. A 100% checklist does not imply 100% travel recommendation accuracy. No LLM-judged RAGAS result is reported; a prior local Ollama RAGAS attempt timed out.

## Changes prompted by evaluation

- Evaluators now include the planner's actual answer text and ranked destination suggestions instead of scoring a partial summary that previously omitted the answer.
- Destination-comparison questions without stated interests infer candidate interests from the retrieved profiles, then provide a curated, ranked shortlist while clearly saying the data cannot establish city-level ratings.
- Destination ordering now prioritizes how many stated interests a destination covers, then uses category-level rating evidence as a tie-breaker.
- The checklist includes budget and destination-comparison caveats, plus checks for all three ranked options.

## Retrieval and API evidence

- The supplied UCI dataset has 5,456 traveler profiles and 24 attraction-category average ratings. The documented category names are restored from `config/category_mapping.json`.
- The recommendation flow uses hybrid traveler-profile retrieval and shows category ratings from those retrieved profiles. Dataset values do not record city, venue, itinerary, duration, or price.
- The destination shortlist is based on a curated interest-tag catalog. Similar-profile category ratings can be displayed as supporting evidence, but are not destination ratings.
- Stays, food, and other named places use a separate live map-provider path; it is not historic review evidence in this dataset.

## Limits that affect the project grade

- The input data cannot support a factual comparison of destination ratings, named historically reviewed experiences, or budget feasibility. Do not describe the shortlist as destination ratings or claim affordability.
- The local experience-corpus importer supports real reviewed trip records, but no such corpus is supplied or imported. The template is not a dataset.
- The current 100% checklist and 73.45% semantic-similarity score use seven project-authored cases. Independent human-labeled examples and a functioning LLM judge are still needed for a credible quality score.
- Consequently, the evaluation scores are not a promise or estimate that an external reviewer will award more than 90/100.
