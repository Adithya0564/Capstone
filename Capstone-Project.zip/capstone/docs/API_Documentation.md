# API Documentation

Base URL: `http://127.0.0.1:8000`. OpenAPI is served at `/docs`. All JSON bodies use UTF-8. FastAPI validation errors use HTTP 422; unexpected provider exceptions are caught and never returned as stack traces.

## `GET /health`

Purpose: service and local data readiness, configured provider names, and tracing state. No request body.

Response schema: `status: string`, `dataset_present: boolean`, `profiles_ready: boolean`, `providers: array<{provider: string, configured: boolean, model: string}>`, `langsmith_tracing: boolean`.

Example response:

```json
{"status":"ok","dataset_present":true,"profiles_ready":true,"providers":[{"provider":"Gemini","configured":false,"model":"auto-discovered when called"},{"provider":"OpenAI","configured":false,"model":"auto-discovered when called"},{"provider":"Offline Recommendation Engine","configured":true,"model":"deterministic"}],"langsmith_tracing":false}
```

Errors: 200 while service is up. This endpoint does not validate remote provider credentials.

## `GET /dataset/stats`

Purpose: return computed dataset schema and numeric statistics. No request body. Response includes cleaned and original row/column counts, detected category columns, excluded unnamed columns, duplicate counts, missingness, invalid value counts, and per-category descriptive statistics.

Example response excerpt from the supplied CSV:

```json
{"dataset_name":"google_review_ratings.csv","rows_raw":5456,"rows":5456,"columns_raw":26,"category_columns_count":24,"unassigned_unnamed_values":2,"duplicate_user_rows_removed":0,"rating_range":[0.0,5.0]}
```

The live response includes these summary fields along with the full category names and per-category statistics. Error: 503 if the CSV is missing or corrupt.

## `POST /recommendations/search`

Purpose: primary natural-language travel-interest search. Maps the query to UCI's documented attraction categories, retrieves similar traveler rating profiles using BM25 plus dense embeddings and reciprocal rank fusion, summarizes the retrieved profiles' ratings for matched categories, and returns curated interest-matched destination ideas.

Request schema: `query: string (2-2000 chars)`, `top_k: integer (1-50, default 8)`, optional `min_average_rating` and `max_average_rating` profile-average filters. Trip length is parsed from the query for display but is not a filter because the dataset has no trip-duration field.

Example request:

```json
{"query":"A 5-day trip focused on beaches, sightseeing, and local food","top_k":5}
```

The response includes `duration_days`, `matched_interests`, `matched_categories`, `interest_highlights`, `similar_profiles`, `destination_suggestions`, and `dataset_scope`. `interest_highlights` summarizes the top rated categories for each stated interest and includes the number of similar profiles with recorded values. A null category average means the retrieved profiles had no recorded values; it is never shown as a zero rating. The UI puts full profile-level evidence in an optional expander. Destination suggestions contain matched interests and a `match_basis` indicating curated tags rather than dataset-derived destination ratings.

Example response excerpt:

```json
{
  "status": "ok",
  "duration_days": 5,
  "matched_interests": ["beaches", "sightseeing", "local food"],
  "matched_categories": [
    {"category_id": "category_3", "category": "beaches", "similar_profile_average": 2.56, "profiles_with_rating": 5, "profiles_above_4": 0}
  ],
  "interest_highlights": [
    {"interest": "beaches", "top_categories": [{"category": "beaches", "similar_profile_average": 2.56, "profiles_with_rating": 5}], "category_count": 1},
    {"interest": "sightseeing", "top_categories": [{"category": "monuments", "similar_profile_average": 5.0, "profiles_with_rating": 3}, {"category": "viewpoints", "similar_profile_average": 5.0, "profiles_with_rating": 4}, {"category": "parks", "similar_profile_average": 4.55, "profiles_with_rating": 5}], "category_count": 9},
    {"interest": "local food", "top_categories": [{"category": "bakeries", "similar_profile_average": 5.0, "profiles_with_rating": 1}, {"category": "restaurants", "similar_profile_average": 3.59, "profiles_with_rating": 5}, {"category": "juice bars", "similar_profile_average": 3.2, "profiles_with_rating": 2}], "category_count": 5}
  ],
  "destination_suggestions": [
    {"name": "Bali", "country": "Indonesia", "matched_interests": ["beaches", "sightseeing", "local food"], "match_count": 3, "match_percent": 100, "match_basis": "curated interest tags; not destination ratings from the dataset"},
    {"name": "Goa", "country": "India", "matched_interests": ["beaches", "sightseeing", "local food"], "match_count": 3, "match_percent": 100, "match_basis": "curated interest tags; not destination ratings from the dataset"}
  ]
}
```

`dataset_scope` explains that the source contains per-traveler category averages, not written reviews, historical itineraries, duration, or destination-level ratings. Destination ideas use a curated tag catalog and must not be described as destinations that similar travelers rated highly. The rating profiles and individual values come from the supplied CSV.

The separate `/api/travel/search` route retains optional filters over imported historical trip records. Import a reviewed CSV using `python -m src.import_experiences path\to\reviewed_trips.csv`; it is not the primary UCI rating-profile search. Errors: 422 for invalid fields; 503 if profile data cannot be loaded.

## `POST /itinerary`

Purpose: validate a trip request, classify the selected group and interests, retrieve rating profiles, request a destination if absent, and generate a day-by-day outline. The default fast path is deterministic and offline. Set `FAST_ITINERARY_MODE=false` to opt into hosted generation through the configured OpenAI-compatible, Gemini, and OpenAI provider chain; provider output is accepted only after structural validation.

Request schema for `POST /itinerary`: `query: string (8-2000 chars, required)`, `destination: string|null`, `duration_days: integer|null (1-30)`, `budget: positive number|null`, `currency: string` (default INR), `group_size: integer (1-20)`, `interests: string[]` (max 12), `pace: string|null`, and `travel_type: string|null`. The `/api/travel/plan` and `/api/travel/itinerary` request schema uses `travelers` for group size and also accepts `travel_type`, `preferences`, and `special_requirements`.

Example request:

```json
{"query":"Plan three relaxed days for two with local food","duration_days":3,"group_size":2,"travel_type":"Couple","interests":["local food"]}
```

For this request, the endpoint returns `status: "needs_destination"` and asks which destination to plan. Responses include `preference_classification`, which labels extracted interests, selected traveler group, pace, and a rough budget tier when the required INR inputs are present. The rating categories can be used as preference evidence, but they do not provide destination or specific-venue ratings. When `LLM_JUDGE_ENABLED=true`, `llm_judge_validation` calls the configured provider and adds latency. The critic checks requested duration and reports budget feasibility as unknown because no destination cost data is supplied. Errors: 422 for schema/guardrail validation; 503 if profile data is unavailable.

## `POST /feedback`

Purpose: append explicit feedback to local JSONL storage. No automatic source-profile mutation.

Request schema: `user_query: string (2-2000 chars)`, `rating: integer (1-5)`, `comment: string|null (max 1000 chars)`, `accepted_categories: string[] (max 24)`.

Example request:

```json
{"user_query":"Plan a quiet weekend","rating":4,"comment":"More time for rest","accepted_categories":[]}
```

Response schema and example: `{"recorded":true,"message":"Feedback saved locally and can be used in future preference analysis."}`. Errors: 422 for invalid fields.

## `GET /observability/summary`

Purpose: local feedback count and the current logging/tracing configuration. No request body.

Response schema: `feedback_records: integer`, `trace_backend: string`, `llm_calls: string`.

Example response: `{"feedback_records":0,"trace_backend":"standard application logs","llm_calls":"provider result is returned per request"}`. Error: 200 even when there are no feedback records.
# Submission route family

The same backend also exposes the following compatibility routes under `/api/travel`:

| Method | Path | Behavior |
|---|---|---|
| GET | `/api/travel/` | API name and route index. |
| POST | `/api/travel/plan` | Complete request, query extraction, profile retrieval, and itinerary draft. Accepts `travelers` as the group-size field. |
| POST | `/api/travel/itinerary` | Alias for plan. |
| POST | `/api/travel/places` | Live stay and food lookups. Uses OpenStreetMap by default (no key; names, available addresses and map links, no ratings/photos). Set `PLACES_PROVIDER=google` to use Google Places when configured; Google results include ratings/photos and are not stored by the application. |
| POST | `/api/travel/attractions` | Live mapped sights ordered for couple, family, or friends. |
| POST | `/api/travel/trip-places` | Named food, sights, shopping, and evening activities used to assemble place-specific itineraries. |
| POST | `/api/travel/search` | Hybrid anonymous-profile search, plus destination/travel-type/rating/budget filters over imported trip records. |
| POST | `/api/travel/recommendations` | Alias for hybrid profile search. |
| POST | `/api/travel/feedback` | Store explicit feedback locally as JSONL. |
| GET | `/api/travel/destinations` | Returns destinations from the imported trip corpus, or an explanation when that corpus is empty. |

Example plan body:

```json
{"query":"Plan 4 relaxed days in Goa for two, with food and beaches","destination":"Goa","duration_days":4,"budget":30000,"travelers":2,"interests":["food","beaches"]}
```

The supplied CSV still has no destination-linked history or place prices. OSM endpoints provide current map listings, not historic ratings or verified price suitability. Destination, travel-type, rating, and budget metadata filters apply to the separate imported travel-experience corpus and return no records until reviewed data is loaded.
