# Sample Test Cases

| Case | Input | Expected behavior |
|---|---|---|
| Beach, sightseeing, food | 5-day trip with beaches, sightseeing, local food | Retrieve similar profiles, show ratings for mapped categories, and offer curated interest-matched destination ideas. |
| Museums and monuments | Interested in museums and monuments | Match UCI categories 6 and 23, show similar profiles' actual values. |
| Food preferences | Restaurants, cafes, juice bars | Match UCI categories 9, 21, and 14 and summarize returned ratings. |
| Destination selection | Choose Goa after discovery | Open the existing form for days, budget, party size, and relationship. |
| Missing planning destination | Start the itinerary planner with no destination | Ask for destination rather than inventing one. |
| Invalid short query | `hi` | Return HTTP 422 with a useful validation message. |

## DeepEval benchmark

The seven authored examples in `evaluation/evaluation_dataset.json` cover the three representative question types (similar experiences, destination comparison, and limited-budget options) plus additional interest-search cases. Run `python -m evaluation.deepeval_evaluation` after installing `requirements-evaluation.txt` and starting Ollama with the configured `DEEPEVAL_MODEL`. The local model's Answer Relevancy and G-Eval scores are diagnostic only. The deterministic checklist run is `.venv\Scripts\python.exe -m evaluation.deepeval_evaluation --checklist-only --output evaluation/deepeval_requirement_scores.json`. Neither metric is a grade or validated measure of traveler satisfaction.

