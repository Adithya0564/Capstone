# Design Document

## Objective

Demonstrate preference-aware travel recommendations over real traveler rating profiles. The supplied CSV is UCI Travel Review Ratings (dataset 485); its 24 category labels are officially documented and restored in the application.

## Data and profiles

Cleaning discovers the user key and category columns dynamically, normalizes number strings, converts values outside UCI's documented 1–5 rating scale to missing with counts, reports missingness and descriptive statistics, and retains the first duplicate user ID. Each profile has an observed numeric vector, normalized vector, mean/median, top and low categories, rating distribution, and dispersion-based preference strength.

## Retrieval architecture

Profile documents contain the UCI-defined category labels and observed per-user averages. Chroma embeddings support dense semantic search; BM25 adds exact category keyword matching; reciprocal rank fusion combines both lists. Query parsing expands stated interests such as sightseeing and local food to documented category IDs, and profile ratings for those categories influence ranking. The main experience-search route skips the optional cross-encoder to keep the first UI search responsive. A cross-encoder remains available on other retrieval paths.

The source contains rating vectors, not reviews, named trips, dates, or destinations. Search therefore returns similar traveler rating profiles and category-level evidence. Destination ideas are sorted against curated interest tags and are not presented as destination ratings. A separate optional JSONL corpus accepts reviewed trip records and supports BM25/embedding ranking plus destination, travel-type, minimum-rating, and maximum-budget filters.

## Planning and providers

The main Streamlit journey first searches preferences, displays retrieved profile evidence, and offers curated interest-matched destination ideas. After a choice, the existing trip dialog collects duration, budget, group size, and relationship; the itinerary page can then request live named OSM stops. Pydantic validation, guardrails, LangGraph planning, provider fallback, and budget limitations remain in the existing itinerary path.

## API, interface, and feedback

FastAPI exposes health, stats, hybrid recommendation search, itinerary, feedback, observability summary, and a compatible `/api/travel` route family. Streamlit calls the recommendation API first and renders category ratings from retrieved profiles. Explicit feedback is appended to local JSONL for later analysis; it does not silently mutate source profiles and there is not yet an automated feedback-learning loop.

## Evaluation and operational decisions

The repository includes a DeepEval/LLM-as-judge runner and labeled retrieval coverage helper. The diagnostic benchmark contains project-authored expectation statements; it is not independently human-validated travel-quality ground truth. DeepEval uses the local Ollama model by default and writes actual per-case metric scores and reasons to `evaluation/deepeval_scores.json`. The optional online itinerary judge is disabled by default. Logs use Python logging. Browser speech input and read-aloud depend on supported browser APIs. Verified historic destination knowledge still needs an external source.

## Trade-offs and next work

The default Sentence Transformers embedding model keeps vector indexing local and avoids a hosted embedding key. Ollama and Gemini embeddings remain configurable alternatives. A verified attraction/pricing provider, labeled benchmark, robust async provider retries, and broader browser speech testing are future additions.
