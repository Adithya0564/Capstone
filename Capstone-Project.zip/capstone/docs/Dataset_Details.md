# Dataset Details

## Source and purpose

- Dataset: **Travel Review Ratings** (UCI Machine Learning Repository dataset 485).
- Source: [UCI Travel Review Ratings](https://archive.ics.uci.edu/dataset/485/travel+review+ratings).
- DOI: `10.24432/C5C31Q`.
- License: Creative Commons Attribution 4.0 (CC BY 4.0), per UCI.
- Local source file: `data/raw/google_review_ratings.csv`.
- Format: CSV; 5,456 user profiles and 24 rating categories.
- Ratings: average Google user ratings by traveler and attraction category. UCI documents a 1–5 scale; zero sentinels found in the local CSV are counted as invalid and treated as missing.

## Category mapping

The original CSV uses generic column labels `Category 1` through `Category 24`. UCI provides their semantics, and this project restores them in `config/category_mapping.json`:

| Column | Place category |
|---|---|
| Category 1 | Churches |
| Category 2 | Resorts |
| Category 3 | Beaches |
| Category 4 | Parks |
| Category 5 | Theatres |
| Category 6 | Museums |
| Category 7 | Malls |
| Category 8 | Zoos |
| Category 9 | Restaurants |
| Category 10 | Pubs/bars |
| Category 11 | Local services |
| Category 12 | Burger/pizza shops |
| Category 13 | Hotels/other lodgings |
| Category 14 | Juice bars |
| Category 15 | Art galleries |
| Category 16 | Dance clubs |
| Category 17 | Swimming pools |
| Category 18 | Gyms |
| Category 19 | Bakeries |
| Category 20 | Beauty & spas |
| Category 21 | Cafes |
| Category 22 | Viewpoints |
| Category 23 | Monuments |
| Category 24 | Gardens |

## What this dataset supports

Each row is one traveler's average rating vector across place categories. The system can map a natural-language query (for example, beaches, sightseeing, and local food) to these documented categories, retrieve similar traveler profiles with hybrid search, and summarize the ratings those profiles gave to relevant categories.

The records are category averages, not individual review text or chronological trips. They do not include destination/city names, specific venues, travel dates, trip length, activities performed on a particular trip, traveler relationships, or prices. Therefore, the dataset cannot support claims such as “similar travelers took a five-day Goa trip” or provide a destination-level rating. Interest-matched destination ideas come from a separately curated starter catalog; they are not destination ratings from this dataset.

## Cleaning and derived fields

The pipeline retains `User` and recognized `Category N` columns, parses numeric values, preserves missingness, marks values outside UCI's 1–5 scale as missing, removes empty or unassigned unnamed columns, and keeps the first row for duplicate user IDs. In the supplied export, zeros are the dominant out-of-range value and are treated as unrated sentinels (inference from the documented scale and the CSV values). It derives each traveler's mean, median, high and low category ratings, rating distribution, preference vector, and preference strength. Derived profile identifiers are used for internal matching; the UI labels results as similar traveler profiles.

Generated files: `data/processed/cleaned_reviews.csv`, `data/processed/dataset_statistics.json`, and `data/processed/traveler_profiles.jsonl`.

## Separate trip-record corpus

`data/travel_experience_template.csv` is an optional schema for importing reviewed destination-linked trip records. It is not part of the UCI dataset and remains empty until real reviewed records are supplied. It must not be populated with made-up historical experiences.
