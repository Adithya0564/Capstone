# Voyage AI architecture

```mermaid
flowchart TD
  CSV[google_review_ratings.csv] --> CLEAN[Schema inspection and cleaning]
  CLEAN --> PROFILE[Anonymous traveler preference profiles]
  PROFILE --> CHUNK[Profile documents]
  CHUNK --> EMB[Gemini embeddings or Sentence Transformers]
  EMB --> CHROMA[(ChromaDB)]
  USER[Traveler] --> UI[Streamlit travel studio, chat and browser voice]
  UI --> API[FastAPI]
  API --> GUARD[Input validation and guardrails]
  GUARD --> QUERY[Query extraction]
  QUERY --> BM25[BM25 and lexical retrieval]
  QUERY --> DENSE[Dense vector retrieval]
  CHROMA --> DENSE
  BM25 --> RRF[Reciprocal rank fusion]
  DENSE --> RRF
  RRF --> RANK[Preference ranking and metadata filters]
  RANK --> AGENT[LangGraph workflow: extract, retrieve, plan]
  AGENT --> HOSTED[Optional Gemini then OpenAI provider chain]
  HOSTED --> PLAN[Day-by-day itinerary draft]
  AGENT -->|offline or provider unavailable| PLAN
  PLAN --> VALIDATE[Deterministic duration and budget critic]
  VALIDATE --> UI
  UI --> FEEDBACK[Explicit user feedback]
  FEEDBACK --> EVAL
  API --> LOGS[Logs and operational summary]
  RANK --> EVAL[Evaluation on labeled examples]
```

The input CSV supplies average ratings by UCI-documented attraction category, not destination-level facts. Destination ideas are curated matches to the interests extracted from the query; they are not inferred from city ratings. Specific destination evidence would require a future `TravelKnowledgeProvider`.
